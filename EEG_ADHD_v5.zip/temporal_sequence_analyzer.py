"""

=====================================================

Análisis en profundidad de patrones temporales y predicción de trayectorias
atencionales basado en literatura científica de vigilancia y ADHD.

Referencias:
- Mackworth (1948): Vigilance decrement
- Robertson et al. (1997): Sustained attention theories
- Castellanos & Tannock (2002): Time-on-task effects in ADHD
- Kuntsi & Klein (2012): Intra-individual variability
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple
from scipy import stats, signal
from sklearn.metrics import mean_squared_error, mean_absolute_error
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')


class TemporalSequenceAnalyzer:
    """
    Analizador de secuencias temporales para estudiar:
    1. Patrones de declive atencional (vigilance decrement)
    2. Capacidad de recuperación
    3. Variabilidad intra-individual
    4. Efectos de tiempo en tarea (time-on-task)
    """
    
    def __init__(self):
        """Inicializar analizador"""
        print(" TemporalSequenceAnalyzer Inicializado")
        print("   Análisis basado en teorías de vigilancia y ADHD")
    
    def analyze_vigilance_decrement(self, sequence: np.ndarray, 
                                    time_points: np.ndarray = None) -> Dict:
        """
        Analizar declive de vigilancia (Mackworth, 1948)
        
        El declive de vigilancia es la tendencia a una reducción
        en la capacidad de detección con el tiempo en tarea.
        Particularmente pronunciado en ADHD.
        
        Args:
            sequence: Secuencia de valores de atención [t1, t2, ..., tn]
            time_points: Puntos temporales (opcional)
            
        Returns:
            analysis: Diccionario con métricas de declive
        """
        n = len(sequence)
        
        if time_points is None:
            time_points = np.arange(n)
        
        # 1. Regresión lineal para detectar tendencia
        slope, intercept, r_value, p_value, std_err = stats.linregress(time_points, sequence)
        
        # 2. Comparar primer tercio vs último tercio (Warm et al., 2008)
        third = n // 3
        first_third = sequence[:third]
        last_third = sequence[-third:]
        
        decrement = np.mean(first_third) - np.mean(last_third)
        decrement_pct = (decrement / (np.mean(first_third) + 1e-10)) * 100
        
        # 3. Estadística de comparación
        t_stat, t_pvalue = stats.ttest_ind(first_third, last_third)
        
        # 4. Tasa de cambio (rate of decline)
        rate_of_decline = slope / (np.mean(sequence) + 1e-10)  # Normalizado
        
        # 5. Clasificación del patrón
        if p_value < 0.05 and slope < -0.001:
            pattern = "Declive Significativo"
            severity = "Alto" if abs(decrement_pct) > 20 else "Moderado"
        elif p_value < 0.05 and slope > 0.001:
            pattern = "Mejora Significativa"
            severity = "Compensación Activa"
        else:
            pattern = "Estable"
            severity = "Normal"
        
        analysis = {
            'slope': slope,
            'intercept': intercept,
            'r_squared': r_value**2,
            'p_value': p_value,
            'decrement_absolute': decrement,
            'decrement_percentage': decrement_pct,
            't_statistic': t_stat,
            't_pvalue': t_pvalue,
            'rate_of_decline': rate_of_decline,
            'pattern': pattern,
            'severity': severity
        }
        
        return analysis
    
    def analyze_recovery_capacity(self, sequence: np.ndarray, 
                                  threshold: float = 0.35) -> Dict:
        """
        Analizar capacidad de recuperación atencional
        
        Basado en Helps et al. (2010): Capacidad de recuperación
        tras lapsos atencionales en ADHD.
        
        Args:
            sequence: Secuencia de valores de atención
            threshold: Umbral para considerar "lapso" (< threshold)
            
        Returns:
            analysis: Diccionario con métricas de recuperación
        """
        # Identificar lapsos (valores bajo threshold)
        in_lapse = sequence < threshold
        
        # Encontrar eventos de lapso
        lapse_starts = []
        lapse_durations = []
        recovery_times = []
        recovery_magnitudes = []
        
        i = 0
        while i < len(sequence):
            if in_lapse[i]:
                # Inicio de lapso
                lapse_start = i
                lapse_value = sequence[i]
                
                # Encontrar duración del lapso
                duration = 1
                while i + duration < len(sequence) and in_lapse[i + duration]:
                    duration += 1
                
                lapse_starts.append(lapse_start)
                lapse_durations.append(duration)
                
                # Analizar recuperación si existe
                if i + duration < len(sequence):
                    # Valor post-lapso
                    recovery_value = sequence[i + duration]
                    recovery_magnitude = recovery_value - lapse_value
                    recovery_magnitudes.append(recovery_magnitude)
                    
                    # Tiempo para recuperación completa (si ocurre)
                    recovery_time = 1
                    target_value = threshold + 0.05  # Threshold + margen
                    
                    j = i + duration
                    while j < len(sequence) and sequence[j] < target_value:
                        recovery_time += 1
                        j += 1
                    
                    if j < len(sequence):
                        recovery_times.append(recovery_time)
                
                i += duration
            else:
                i += 1
        
        # Calcular estadísticas
        n_lapses = len(lapse_starts)
        
        if n_lapses > 0:
            avg_lapse_duration = np.mean(lapse_durations)
            max_lapse_duration = np.max(lapse_durations)
            
            if recovery_times:
                avg_recovery_time = np.mean(recovery_times)
                recovery_success_rate = len(recovery_times) / n_lapses
            else:
                avg_recovery_time = np.inf
                recovery_success_rate = 0.0
            
            if recovery_magnitudes:
                avg_recovery_magnitude = np.mean(recovery_magnitudes)
            else:
                avg_recovery_magnitude = 0.0
        else:
            avg_lapse_duration = 0
            max_lapse_duration = 0
            avg_recovery_time = 0
            recovery_success_rate = 1.0
            avg_recovery_magnitude = 0.0
        
        # Clasificación de capacidad de recuperación
        if recovery_success_rate > 0.75 and avg_recovery_time < 3:
            recovery_class = "Excelente"
        elif recovery_success_rate > 0.5 and avg_recovery_time < 5:
            recovery_class = "Buena"
        elif recovery_success_rate > 0.25:
            recovery_class = "Moderada"
        else:
            recovery_class = "Deficiente"
        
        analysis = {
            'n_lapses': n_lapses,
            'avg_lapse_duration': avg_lapse_duration,
            'max_lapse_duration': max_lapse_duration,
            'avg_recovery_time': avg_recovery_time,
            'recovery_success_rate': recovery_success_rate,
            'avg_recovery_magnitude': avg_recovery_magnitude,
            'recovery_classification': recovery_class,
            'lapse_frequency': n_lapses / len(sequence)  # Lapsos por ventana
        }
        
        return analysis
    
    def analyze_intra_individual_variability(self, sequence: np.ndarray) -> Dict:
        """
        Analizar variabilidad intra-individual (IIV)
        
        Basado en Kuntsi & Klein (2012): IIV como marcador cognitivo de ADHD
        La alta IIV es característica distintiva del ADHD.
        
        Args:
            sequence: Secuencia de valores de atención
            
        Returns:
            analysis: Diccionario con métricas de IIV
        """
        # 1. Desviación estándar (medida básica de IIV)
        std = np.std(sequence)
        
        # 2. Coeficiente de variación (CV = std/mean)
        # Normaliza la variabilidad por el nivel medio
        cv = std / (np.mean(sequence) + 1e-10)
        
        # 3. Diferencias sucesivas (MSSD - Mean Square Successive Difference)
        # Captura cambios locales
        successive_diffs = np.diff(sequence)
        mssd = np.mean(successive_diffs ** 2)
        
        # 4. Rango intercuartil (IQR)
        q75, q25 = np.percentile(sequence, [75, 25])
        iqr = q75 - q25
        
        # 5. Entropía aproximada (ApEn) - mide regularidad/predictibilidad
        # Adaptado de Pincus (1991)
        apen = self._approximate_entropy(sequence, m=2, r=0.2*std)
        
        # 6. Clasificación de IIV
        # Basado en percentiles de población control vs ADHD
        if cv > 0.25 or mssd > 0.01:
            iiv_class = "Alta (compatible con ADHD)"
        elif cv > 0.15 or mssd > 0.005:
            iiv_class = "Moderada"
        else:
            iiv_class = "Baja (típica de controles)"
        
        analysis = {
            'std': std,
            'coefficient_of_variation': cv,
            'mssd': mssd,
            'iqr': iqr,
            'approximate_entropy': apen,
            'iiv_classification': iiv_class
        }
        
        return analysis
    
    def _approximate_entropy(self, sequence: np.ndarray, m: int, r: float) -> float:
        """
        Calcular entropía aproximada (ApEn)
        
        Mide la regularidad de series temporales.
        Valores altos = mayor irregularidad/impredecibilidad
        
        Args:
            sequence: Serie temporal
            m: Longitud de patrón a comparar
            r: Tolerancia para similitud
            
        Returns:
            apen: Valor de entropía aproximada
        """
        N = len(sequence)
        
        def _maxdist(x_i, x_j):
            return max([abs(ua - va) for ua, va in zip(x_i, x_j)])
        
        def _phi(m):
            x = [[sequence[j] for j in range(i, i + m - 1 + 1)] 
                 for i in range(N - m + 1)]
            C = [len([1 for x_j in x if _maxdist(x_i, x_j) <= r]) / (N - m + 1.0) 
                 for x_i in x]
            return (N - m + 1.0) ** (-1) * sum(np.log(C))
        
        try:
            return abs(_phi(m + 1) - _phi(m))
        except:
            return 0.0
    
    def analyze_time_on_task_effects(self, sequence: np.ndarray, 
                                     window_size: int = 5) -> Dict:
        """
        Analizar efectos de tiempo en tarea
        
        Basado en Castellanos & Tannock (2002): Los efectos del tiempo
        en tarea son particularmente pronunciados en ADHD.
        
        Args:
            sequence: Secuencia de valores de atención
            window_size: Tamaño de ventana para promedios móviles
            
        Returns:
            analysis: Diccionario con análisis de tiempo en tarea
        """
        n = len(sequence)
        
        # 1. Dividir en bloques temporales (inicio, medio, fin)
        block_size = n // 3
        
        early_block = sequence[:block_size]
        middle_block = sequence[block_size:2*block_size]
        late_block = sequence[2*block_size:]
        
        early_mean = np.mean(early_block)
        middle_mean = np.mean(middle_block)
        late_mean = np.mean(late_block)
        
        # 2. Comparaciones estadísticas
        # Early vs Late
        t_early_late, p_early_late = stats.ttest_ind(early_block, late_block)
        
        # Early vs Middle
        t_early_middle, p_early_middle = stats.ttest_ind(early_block, middle_block)
        
        # 3. Patrón de cambio
        if p_early_late < 0.05:
            if early_mean > late_mean:
                if (early_mean - late_mean) / early_mean > 0.15:
                    pattern = "Declive Pronunciado (típico ADHD)"
                else:
                    pattern = "Declive Leve"
            else:
                pattern = "Mejora con Tiempo"
        else:
            pattern = "Estable"
        
        # 4. Calcular promedio móvil para visualizar tendencia
        moving_avg = np.convolve(sequence, np.ones(window_size)/window_size, mode='valid')
        
        # 5. Velocidad de declive (si existe)
        if len(moving_avg) > 1:
            decline_rate = (moving_avg[0] - moving_avg[-1]) / len(moving_avg)
        else:
            decline_rate = 0
        
        analysis = {
            'early_mean': early_mean,
            'middle_mean': middle_mean,
            'late_mean': late_mean,
            'early_vs_late_change': early_mean - late_mean,
            'early_vs_late_change_pct': ((early_mean - late_mean) / (early_mean + 1e-10)) * 100,
            't_statistic_early_late': t_early_late,
            'p_value_early_late': p_early_late,
            't_statistic_early_middle': t_early_middle,
            'p_value_early_middle': p_early_middle,
            'pattern': pattern,
            'decline_rate': decline_rate,
            'moving_average': moving_avg
        }
        
        return analysis


class TrajectoryPredictor:
    """
    Predictor de trayectorias atencionales usando métodos estadísticos
    """
    
    def __init__(self):
        """Inicializar predictor"""
        print(" TrajectoryPredictor Inicializado")
    
    def predict_future_trajectory(self, past_sequence: np.ndarray, 
                                  n_steps: int = 10,
                                  method: str = 'ar') -> Tuple[np.ndarray, Dict]:
        """
        Predecir trayectoria futura de atención
        
        Args:
            past_sequence: Secuencia pasada de valores de atención
            n_steps: Número de pasos a predecir
            method: 'ar' (autoregressive), 'ma' (moving average), 'trend'
            
        Returns:
            predictions: Valores predichos
            confidence: Intervalos de confianza
        """
        if method == 'ar':
            return self._predict_autoregressive(past_sequence, n_steps)
        elif method == 'trend':
            return self._predict_trend_based(past_sequence, n_steps)
        else:
            return self._predict_moving_average(past_sequence, n_steps)
    
    def _predict_autoregressive(self, sequence: np.ndarray, 
                               n_steps: int) -> Tuple[np.ndarray, Dict]:
        """
        Predicción usando modelo autorregresivo simple (AR)
        """
        # Calcular coeficientes AR usando mínimos cuadrados
        # y = a1*y[t-1] + a2*y[t-2] + ... + c
        
        n = len(sequence)
        order = min(5, n - 1)  # Orden AR
        
        # Construir matriz de features
        X = np.zeros((n - order, order))
        y = sequence[order:]
        
        for i in range(order):
            X[:, i] = sequence[order-i-1:n-i-1]
        
        # Resolver por mínimos cuadrados
        coeffs, residuals, _, _ = np.linalg.lstsq(X, y, rcond=None)
        
        # Predecir
        predictions = []
        current = sequence[-order:].tolist()
        
        for _ in range(n_steps):
            next_val = sum(c * v for c, v in zip(coeffs, current[-order:]))
            predictions.append(next_val)
            current.append(next_val)
        
        predictions = np.array(predictions)
        
        # Estimar intervalo de confianza (simplificado)
        std_residual = np.std(residuals) if len(residuals) > 0 else np.std(sequence) * 0.1
        confidence = {
            'lower': predictions - 1.96 * std_residual,
            'upper': predictions + 1.96 * std_residual
        }
        
        return predictions, confidence
    
    def _predict_trend_based(self, sequence: np.ndarray, 
                            n_steps: int) -> Tuple[np.ndarray, Dict]:
        """
        Predicción basada en tendencia lineal
        """
        n = len(sequence)
        x = np.arange(n)
        
        # Ajustar tendencia
        slope, intercept, _, _, std_err = stats.linregress(x, sequence)
        
        # Predecir
        future_x = np.arange(n, n + n_steps)
        predictions = slope * future_x + intercept
        
        # Intervalo de confianza
        confidence = {
            'lower': predictions - 1.96 * std_err * np.sqrt(1 + 1/n + (future_x - np.mean(x))**2 / np.sum((x - np.mean(x))**2)),
            'upper': predictions + 1.96 * std_err * np.sqrt(1 + 1/n + (future_x - np.mean(x))**2 / np.sum((x - np.mean(x))**2))
        }
        
        return predictions, confidence
    
    def _predict_moving_average(self, sequence: np.ndarray, 
                               n_steps: int) -> Tuple[np.ndarray, Dict]:
        """
        Predicción usando promedio móvil
        """
        window = min(5, len(sequence))
        
        # Último promedio
        last_avg = np.mean(sequence[-window:])
        std = np.std(sequence[-window:])
        
        # Predicciones (asume persistencia)
        predictions = np.ones(n_steps) * last_avg
        
        confidence = {
            'lower': predictions - 1.96 * std,
            'upper': predictions + 1.96 * std
        }
        
        return predictions, confidence


def visualize_temporal_analysis(sequence: np.ndarray, 
                                analyses: Dict,
                                save_path: str = None):
    """
    Visualizar análisis temporal completo
    """
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    
    # 1. Secuencia temporal con tendencia
    ax1 = axes[0, 0]
    time_points = np.arange(len(sequence))
    ax1.plot(time_points, sequence, 'o-', alpha=0.6, label='Atención')
    
    # Añadir línea de tendencia
    slope = analyses['vigilance']['slope']
    intercept = analyses['vigilance']['intercept']
    trend = slope * time_points + intercept
    ax1.plot(time_points, trend, 'r--', linewidth=2, label='Tendencia')
    
    ax1.axhline(y=0.35, color='orange', linestyle=':', label='Umbral Lapso')
    ax1.set_xlabel('Tiempo (ventanas)', fontsize=11)
    ax1.set_ylabel('Nivel de Atención', fontsize=11)
    ax1.set_title(f'Vigilancia: {analyses["vigilance"]["pattern"]}', fontweight='bold')
    ax1.legend()
    ax1.grid(alpha=0.3)
    
    # 2. Análisis de recuperación
    ax2 = axes[0, 1]
    recovery_data = [
        analyses['recovery']['n_lapses'],
        analyses['recovery']['avg_lapse_duration'],
        analyses['recovery']['avg_recovery_time'],
        analyses['recovery']['recovery_success_rate'] * 10  # Escalar para visualización
    ]
    labels = ['N° Lapsos', 'Duración\nLapso', 'Tiempo\nRecup.', 'Tasa Éxito\n(x10)']
    colors = ['red', 'orange', 'yellow', 'green']
    
    ax2.bar(labels, recovery_data, color=colors, alpha=0.7)
    ax2.set_title(f'Recuperación: {analyses["recovery"]["recovery_classification"]}', 
                 fontweight='bold')
    ax2.set_ylabel('Valor')
    ax2.grid(axis='y', alpha=0.3)
    
    # 3. Efectos de tiempo en tarea
    ax3 = axes[1, 0]
    block_means = [
        analyses['time_on_task']['early_mean'],
        analyses['time_on_task']['middle_mean'],
        analyses['time_on_task']['late_mean']
    ]
    block_labels = ['Inicio', 'Medio', 'Final']
    
    bars = ax3.bar(block_labels, block_means, color=['green', 'yellow', 'red'], alpha=0.7)
    ax3.set_ylabel('Atención Media', fontsize=11)
    ax3.set_title(f'Tiempo en Tarea: {analyses["time_on_task"]["pattern"]}', 
                 fontweight='bold')
    ax3.grid(axis='y', alpha=0.3)
    
    # Añadir valores sobre barras
    for bar, val in zip(bars, block_means):
        height = bar.get_height()
        ax3.text(bar.get_x() + bar.get_width()/2., height,
                f'{val:.3f}', ha='center', va='bottom', fontsize=10)
    
    # 4. Métricas de variabilidad
    ax4 = axes[1, 1]
    variability_metrics = {
        'CV': analyses['variability']['coefficient_of_variation'],
        'MSSD': analyses['variability']['mssd'] * 100,  # Escalar
        'IQR': analyses['variability']['iqr'],
        'ApEn': analyses['variability']['approximate_entropy']
    }
    
    ax4.bar(variability_metrics.keys(), variability_metrics.values(), 
           color='purple', alpha=0.7)
    ax4.set_title(f'Variabilidad: {analyses["variability"]["iiv_classification"]}',
                 fontweight='bold')
    ax4.set_ylabel('Valor de Métrica')
    ax4.grid(axis='y', alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"   Visualización guardada: {save_path}")
    else:
        plt.show()
    
    plt.close()


def analyze_subject_sequence(sequence: np.ndarray, 
                            subject_id: str = None) -> Dict:
    """
    Realizar análisis completo de secuencia temporal de un sujeto
    
    Args:
        sequence: Secuencia de valores de atención
        subject_id: ID del sujeto (opcional)
        
    Returns:
        complete_analysis: Diccionario con todos los análisis
    """
    analyzer = TemporalSequenceAnalyzer()
    
    complete_analysis = {
        'subject_id': subject_id,
        'sequence_length': len(sequence),
        'vigilance': analyzer.analyze_vigilance_decrement(sequence),
        'recovery': analyzer.analyze_recovery_capacity(sequence),
        'variability': analyzer.analyze_intra_individual_variability(sequence),
        'time_on_task': analyzer.analyze_time_on_task_effects(sequence)
    }
    
    return complete_analysis


if __name__ == "__main__":
    print("\n" + "="*80)
    print(" ANÁLISIS AVANZADO DE SECUENCIAS TEMPORALES")
    print("="*80)
    
    # Ejemplo con secuencia sintética
    np.random.seed(42)
    
    # Simular secuencia ADHD con declive
    n = 30
    baseline = 0.40
    decline = -0.01
    noise = 0.05
    
    sequence = baseline + decline * np.arange(n) + noise * np.random.randn(n)
    sequence = np.clip(sequence, 0.20, 0.50)
    
    # Análisis completo
    analysis = analyze_subject_sequence(sequence, subject_id='ejemplo_adhd')
    
    print("\nRESULTADOS DEL ANÁLISIS:")
    print(f"\n1. Vigilancia:")
    print(f"   Patrón: {analysis['vigilance']['pattern']}")
    print(f"   Severidad: {analysis['vigilance']['severity']}")
    print(f"   Declive: {analysis['vigilance']['decrement_percentage']:.1f}%")
    
    print(f"\n2. Recuperación:")
    print(f"   Clasificación: {analysis['recovery']['recovery_classification']}")
    print(f"   Lapsos: {analysis['recovery']['n_lapses']}")
    print(f"   Tasa de éxito: {analysis['recovery']['recovery_success_rate']:.2f}")
    
    print(f"\n3. Variabilidad:")
    print(f"   Clasificación: {analysis['variability']['iiv_classification']}")
    print(f"   CV: {analysis['variability']['coefficient_of_variation']:.3f}")
    
    print(f"\n4. Tiempo en Tarea:")
    print(f"   Patrón: {analysis['time_on_task']['pattern']}")
    print(f"   Cambio Early-Late: {analysis['time_on_task']['early_vs_late_change_pct']:.1f}%")
    
    # Visualizar
    visualize_temporal_analysis(sequence, analysis, save_path='temporal_analysis_example.png')
    
    print("\n Análisis completado")
