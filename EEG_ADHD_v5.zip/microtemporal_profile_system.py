"""
Módulo 6: Sistema de Clasificación y Predicción de Perfiles Microtemporales
===========================================================================

Sistema científicamente fundamentado para clasificar y predecir la evolución
temporal de estados cognitivos de atención en niños con/sin TDAH.

Fundamento Científico:
- Robertson & Manly (1999): Teoría de la variabilidad atencional en ADHD
- Tamm et al. (2012): Patrones microtemporales de fluctuación atencional
- Johnson et al. (2007): Modelo de estados de vigilancia
- Helps et al. (2010): Análisis de transiciones en ADHD
- Sergeant (2005): Modelo cognitivo-energético del TDAH

Características Principales:
1. Definición de 5 perfiles microtemporales basados en literatura
2. Clasificación con validación cruzada sujeto-wise (evita data leakage)
3. Modelo HMM para predicción de transiciones temporales
4. Análisis de patrones de recuperación atencional
5. Métricas clínicamente interpretables

"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from sklearn.model_selection import GroupKFold, cross_val_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
import joblib
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')

# Para modelo de transiciones temporales
from hmmlearn import hmm
from scipy import stats
import matplotlib.pyplot as plt
import seaborn as sns


@dataclass
class MicrotemporalProfile:
    """
    Definición de perfil microtemporal basado en literatura científica
    
    Referencias:
    - Robertson & Manly (1999): Sustained attention to response task
    - Johnson et al. (2007): Vigilance model
    """
    profile_id: int
    name: str
    description: str
    attention_range: Tuple[float, float]  # (min, max) atención media
    stability_range: Tuple[float, float]   # (min, max) estabilidad
    transition_rate_range: Tuple[float, float]  # (min, max) transiciones/min
    recovery_range: Tuple[float, float]    # (min, max) tasa recuperación
    clinical_interpretation: str


class MicrotemporalProfileDefiner:
    """
    Define perfiles microtemporales basados en literatura científica
    
    Perfiles basados en:
    - Tamm et al. (2012): Attention variability patterns
    - Helps et al. (2010): EEG microstates in ADHD
    """
    
    def __init__(self):
        """Inicializar definiciones de perfiles"""
        
        # Definir 5 perfiles microtemporales con fundamento científico
        self.profiles = {
            0: MicrotemporalProfile(
                profile_id=0,
                name="Atención Sostenida Estable",
                description="Alta atención con fluctuaciones mínimas (típico en controles)",
                attention_range=(0.40, 1.0),
                stability_range=(0.67, 1.0),      # Alta estabilidad (Helps et al., 2010)
                transition_rate_range=(0, 4),      # Pocas transiciones
                recovery_range=(0.75, 1.0),        # Recuperación rápida cuando ocurre
                clinical_interpretation="Patrón óptimo. Control atencional eficiente y sostenido."
            ),
            
            1: MicrotemporalProfile(
                profile_id=1,
                name="Fluctuación Moderada Compensada",
                description="Atención media-alta con fluctuaciones controladas",
                attention_range=(0.36, 0.44),
                stability_range=(0.33, 0.66),      # Estabilidad moderada
                transition_rate_range=(4, 12),      # Transiciones moderadas
                recovery_range=(0.50, 0.75),        # Recuperación moderada
                clinical_interpretation="Fluctuaciones presentes pero con capacidad de recuperación. "
                                       "Posible ADHD leve o estrategias compensatorias activas."
            ),
            
            2: MicrotemporalProfile(
                profile_id=2,
                name="Variabilidad Alta con Recuperación",
                description="Fluctuaciones frecuentes pero con recuperación periódica (ADHD moderado)",
                attention_range=(0.32, 0.40),
                stability_range=(0.10, 0.33),      # Baja estabilidad (Tamm et al., 2012)
                transition_rate_range=(12, 20),     # Transiciones frecuentes
                recovery_range=(0.25, 0.50),        # Recuperación lenta
                clinical_interpretation="Variabilidad atencional característica de ADHD. "
                                       "Periodos de lapso con recuperación parcial."
            ),
            
            3: MicrotemporalProfile(
                profile_id=3,
                name="Lapsos Frecuentes de Atención",
                description="Pérdidas frecuentes con recuperación limitada (ADHD marcado)",
                attention_range=(0.28, 0.36),
                stability_range=(0.05, 0.20),      # Muy baja estabilidad
                transition_rate_range=(16, 30),     # Transiciones muy frecuentes
                recovery_range=(0.10, 0.30),        # Recuperación muy lenta
                clinical_interpretation="Patrón de lapsos atencionales frecuentes. "
                                       "ADHD con dificultad significativa en vigilancia sostenida."
            ),
            
            4: MicrotemporalProfile(
                profile_id=4,
                name="Hipoactivación Sostenida",
                description="Atención baja constante con mínima variabilidad (ADHD severo/fatiga)",
                attention_range=(0.0, 0.32),
                stability_range=(0.70, 1.0),       # Paradójicamente estable pero baja
                transition_rate_range=(0, 6),       # Pocas transiciones (estancamiento)
                recovery_range=(0.0, 0.25),         # Sin recuperación efectiva
                clinical_interpretation="Hipoactivación persistente. ADHD severo o estado de fatiga extrema. "
                                       "Requiere intervención inmediata."
            )
        }
        
        print("Perfiles Microtemporales Definidos (5 perfiles)")
        print("   Basados en Robertson & Manly (1999), Tamm et al. (2012)")
        for profile in self.profiles.values():
            print(f"\n   Perfil {profile.profile_id}: {profile.name}")
            print(f"      {profile.description}")
    
    def assign_profile_expert_rules(self, features: Dict[str, float]) -> int:
        """
        Asignar perfil usando reglas expertas basadas en literatura
        
        Criterios de Tamm et al. (2012) y Johnson et al. (2007):
        1. Nivel medio de atención
        2. Estabilidad temporal
        3. Frecuencia de transiciones
        4. Capacidad de recuperación
        
        Args:
            features: Diccionario con características extraídas
            
        Returns:
            profile_id: ID del perfil asignado (0-4)
        """
        mean_att = features.get('mean_attention', 0.35)
        stability = features.get('stability', 0.5)
        transitions = features.get('transitions_per_minute', 10)
        recovery = features.get('recovery_rate', 0.5)
        
        # PRIORIDAD 1: Hipoactivación sostenida (Perfil 4)
        # Criterio: Atención muy baja pero estable (paradoja del ADHD severo)
        if mean_att < 0.32 and stability > 0.70 and transitions < 6:
            return 4
        
        # PRIORIDAD 2: Atención óptima (Perfil 0)
        # Criterio: Alta atención, alta estabilidad, pocas transiciones
        # Basado en controles de Helps et al. (2010)
        if mean_att >= 0.40 and stability >= 0.67 and transitions <= 4:
            return 0
        
        # PRIORIDAD 3: Lapsos frecuentes (Perfil 3)
        # Criterio: Atención baja-media, muy inestable, muchas transiciones
        # Patrón típico de ADHD marcado (Tamm et al., 2012)
        if mean_att < 0.36 and stability < 0.20 and transitions > 16:
            return 3
        
        # PRIORIDAD 4: Variabilidad alta (Perfil 2)
        # Criterio: Atención media-baja, inestable, transiciones frecuentes pero recuperación presente
        # ADHD moderado con estrategias compensatorias
        if 0.32 <= mean_att < 0.40 and stability < 0.33 and 12 <= transitions <= 20 and recovery >= 0.25:
            return 2
        
        # PRIORIDAD 5: Fluctuación compensada (Perfil 1)
        # Criterio: Atención media-alta, estabilidad moderada
        # ADHD leve o controles con fluctuaciones normales
        if 0.36 <= mean_att < 0.44 and 0.33 <= stability < 0.67:
            return 1
        
        # DEFAULT: Clasificar por nivel de atención si no cumple patrones claros
        if mean_att >= 0.40:
            return 0  # Alta atención
        elif mean_att >= 0.36:
            return 1  # Media-alta
        elif mean_att >= 0.32:
            return 2  # Media-baja
        else:
            return 3  # Baja atención
    
    def get_profile_description(self, profile_id: int) -> str:
        """Obtener descripción clínica del perfil"""
        if profile_id in self.profiles:
            profile = self.profiles[profile_id]
            return f"{profile.name}: {profile.clinical_interpretation}"
        return "Perfil desconocido"


class MicrotemporalProfileClassifier:
    """
    Clasificador ML de perfiles con validación cruzada sujeto-wise
    
    CORRECCIÓN CRÍTICA: Implementa validación sujeto-wise rigurosa
    para evitar data leakage identificado en versiones previas.
    """
    
    def __init__(self, base_dir: str = '../EEG_ADHD_v5'):
        """
        Inicializar clasificador
        
        Args:
            base_dir: Directorio base del proyecto
        """
        self.base_dir = Path(base_dir)
        self.models_dir = self.base_dir / 'models'
        self.results_dir = self.base_dir / 'results'
        
        self.models_dir.mkdir(parents=True, exist_ok=True)
        self.results_dir.mkdir(parents=True, exist_ok=True)
        
        # Definidor de perfiles
        self.profile_definer = MicrotemporalProfileDefiner()
        
        # Modelo (se entrenará después)
        self.model = None
        self.scaler = StandardScaler()
        
        # Features a usar (excluyendo metadata)
        self.feature_columns = None
        
        print("\nMicrotemporalProfileClassifier Inicializado")
        print(f"   Directorio base: {base_dir}")
        print(f"   Validación: Subject-wise Cross-Validation (evita data leakage)")
    
    def load_and_prepare_data(self, features_file: str) -> Tuple[pd.DataFrame, np.ndarray]:
        """
        Cargar y preparar datos con etiquetas de perfil
        
        IMPORTANTE: Asigna perfiles usando reglas expertas
        
        Args:
            features_file: Ruta al archivo CSV con características
            
        Returns:
            df: DataFrame con características
            profile_labels: Array con etiquetas de perfil
        """
        print("\nCargando características microtemporales...")
        df = pd.read_csv(features_file)
        print(f"   Datos cargados: {df.shape[0]} secuencias, {df.shape[1]} columnas")
        
        # Verificar columnas necesarias
        required_cols = ['mean_attention', 'stability', 'transitions_per_minute', 
                        'recovery_rate', 'subject_id']
        missing = [col for col in required_cols if col not in df.columns]
        if missing:
            raise ValueError(f"Faltan columnas requeridas: {missing}")
        
        # Asignar perfiles usando reglas expertas
        print("\nAsignando perfiles microtemporales (reglas expertas)...")
        profile_labels = []
        
        for idx, row in df.iterrows():
            features_dict = {
                'mean_attention': row['mean_attention'],
                'stability': row['stability'],
                'transitions_per_minute': row['transitions_per_minute'],
                'recovery_rate': row['recovery_rate']
            }
            profile = self.profile_definer.assign_profile_expert_rules(features_dict)
            profile_labels.append(profile)
        
        df['profile'] = profile_labels
        
        # Mostrar distribución de perfiles
        print("\nDistribución de Perfiles:")
        for profile_id in range(5):
            count = (df['profile'] == profile_id).sum()
            pct = count / len(df) * 100
            profile_name = self.profile_definer.profiles[profile_id].name
            print(f"   Perfil {profile_id} ({profile_name}): {count} ({pct:.1f}%)")
        
        # Analizar por diagnóstico ADHD
        if 'adhd_label' in df.columns:
            print("\nDistribución por Diagnóstico:")
            for adhd in [0, 1]:
                adhd_name = "Control" if adhd == 0 else "ADHD"
                subset = df[df['adhd_label'] == adhd]
                print(f"\n   {adhd_name} (n={len(subset)}):")
                for profile_id in range(5):
                    count = (subset['profile'] == profile_id).sum()
                    pct = count / len(subset) * 100 if len(subset) > 0 else 0
                    print(f"      Perfil {profile_id}: {count} ({pct:.1f}%)")
        
        return df, np.array(profile_labels)
    
    def train_with_subject_wise_cv(self, df: pd.DataFrame, n_folds: int = 5) -> Dict:
        """
        Entrenar con validación cruzada SUJETO-WISE (evita data leakage)
        
        CRÍTICO: Las ventanas del mismo sujeto NUNCA se dividen entre train/test
        
        Args:
            df: DataFrame con características y columna 'subject_id'
            n_folds: Número de folds para validación cruzada
            
        Returns:
            results: Diccionario con resultados de validación
        """
        print("\nEntrenando con Validación Cruzada Subject-Wise")
        print(f"   Folds: {n_folds}")
        print("     CRÍTICO: Sujetos NO se dividen entre train/test")
        
        # Seleccionar features (excluir metadata)
        exclude_cols = ['subject_id', 'adhd_label', 'profile', 'sequence_length_actual']
        self.feature_columns = [col for col in df.columns if col not in exclude_cols]
        
        print(f"\n Features seleccionadas: {len(self.feature_columns)}")
        
        X = df[self.feature_columns].values
        y = df['profile'].values
        subjects = df['subject_id'].values
        
        # Normalizar features
        X_scaled = self.scaler.fit_transform(X)
        
        # Configurar GroupKFold (agrupa por sujeto)
        gkf = GroupKFold(n_splits=n_folds)
        
        # Probar múltiples modelos
        models = {
            'XGBoost': xgb.XGBClassifier(
                n_estimators=200,
                max_depth=6,
                learning_rate=0.05,
                subsample=0.8,
                colsample_bytree=0.8,
                random_state=42,
                eval_metric='mlogloss'
            ),
            'Random Forest': RandomForestClassifier(
                n_estimators=200,
                max_depth=10,
                min_samples_split=10,
                min_samples_leaf=4,
                random_state=42,
                class_weight='balanced'
            ),
            'Gradient Boosting': GradientBoostingClassifier(
                n_estimators=150,
                max_depth=5,
                learning_rate=0.05,
                random_state=42
            )
        }
        
        results = {}
        
        for model_name, model in models.items():
            print(f"\n Evaluando {model_name}...")
            
            fold_scores = []
            fold_reports = []
            
            for fold, (train_idx, test_idx) in enumerate(gkf.split(X_scaled, y, groups=subjects)):
                X_train, X_test = X_scaled[train_idx], X_scaled[test_idx]
                y_train, y_test = y[train_idx], y[test_idx]
                
                # Verificar que no hay solapamiento de sujetos
                train_subjects = set(subjects[train_idx])
                test_subjects = set(subjects[test_idx])
                assert len(train_subjects & test_subjects) == 0, " DATA LEAKAGE DETECTADO"
                
                # Entrenar
                model.fit(X_train, y_train)
                
                # Predecir
                y_pred = model.predict(X_test)
                
                # Evaluar
                acc = accuracy_score(y_test, y_pred)
                fold_scores.append(acc)
                
                # Reporte detallado solo para último fold
                if fold == n_folds - 1:
                    report = classification_report(y_test, y_pred, 
                                                   target_names=[self.profile_definer.profiles[i].name 
                                                                for i in range(5)],
                                                   output_dict=True)
                    fold_reports.append(report)
            
            # Resultados del modelo
            mean_acc = np.mean(fold_scores)
            std_acc = np.std(fold_scores)
            
            results[model_name] = {
                'accuracy_mean': mean_acc,
                'accuracy_std': std_acc,
                'fold_scores': fold_scores,
                'last_fold_report': fold_reports[0] if fold_reports else None
            }
            
            print(f"   Accuracy: {mean_acc:.3f} ± {std_acc:.3f}")
        
        # Seleccionar mejor modelo
        best_model_name = max(results.keys(), key=lambda k: results[k]['accuracy_mean'])
        print(f"\n Mejor Modelo: {best_model_name}")
        print(f"   Accuracy: {results[best_model_name]['accuracy_mean']:.3f} ± "
              f"{results[best_model_name]['accuracy_std']:.3f}")
        
        # Entrenar modelo final con todos los datos
        self.model = models[best_model_name]
        self.model.fit(X_scaled, y)
        
        print("\n Guardando modelo entrenado...")
        self.save_model()
        
        return results
    
    def save_model(self):
        """Guardar modelo y scaler"""
        model_path = self.models_dir / 'profile_classifier.pkl'
        scaler_path = self.models_dir / 'profile_scaler.pkl'
        features_path = self.models_dir / 'profile_features.pkl'
        
        joblib.dump(self.model, model_path)
        joblib.dump(self.scaler, scaler_path)
        joblib.dump(self.feature_columns, features_path)
        
        print(f"   Modelo: {model_path}")
        print(f"   Scaler: {scaler_path}")
        print(f"   Features: {features_path}")
    
    def load_model(self):
        """Cargar modelo entrenado"""
        model_path = self.models_dir / 'profile_classifier.pkl'
        scaler_path = self.models_dir / 'profile_scaler.pkl'
        features_path = self.models_dir / 'profile_features.pkl'
        
        if not model_path.exists():
            raise FileNotFoundError(f"Modelo no encontrado: {model_path}")
        
        self.model = joblib.load(model_path)
        self.scaler = joblib.load(scaler_path)
        self.feature_columns = joblib.load(features_path)
        
        print(f"Modelo cargado: {model_path}")
    
    def predict_profile(self, features: Dict[str, float]) -> Tuple[int, Dict]:
        """
        Predecir perfil para un conjunto de características
        
        Args:
            features: Diccionario con características
            
        Returns:
            profile_id: ID del perfil predicho
            probabilities: Diccionario con probabilidades por perfil
        """
        if self.model is None:
            raise ValueError("Modelo no entrenado. Ejecute train_with_subject_wise_cv primero.")
        
        # Preparar features
        X = np.array([[features.get(col, 0) for col in self.feature_columns]])
        X_scaled = self.scaler.transform(X)
        
        # Predecir
        profile_id = self.model.predict(X_scaled)[0]
        probs = self.model.predict_proba(X_scaled)[0]
        
        probabilities = {i: float(probs[i]) for i in range(5)}
        
        return int(profile_id), probabilities


class TemporalEvolutionPredictor:
    """
    Predictor de evolución temporal usando Hidden Markov Models (HMM)
    
    Fundamento:
    - Johnson et al. (2007): Vigilance states model
    - Helps et al. (2010): EEG microstate transitions
    - Markov models para transiciones cognitivas (Bellgrove et al., 2005)
    """
    
    def __init__(self, n_states: int = 5):
        """
        Inicializar predictor HMM
        
        Args:
            n_states: Número de estados (perfiles) = 5
        """
        self.n_states = n_states
        self.hmm_model = None
        
        print(f"\n TemporalEvolutionPredictor Inicializado")
        print(f"   Modelo: Hidden Markov Model")
        print(f"   Estados: {n_states} perfiles microtemporales")
    
    def fit_hmm(self, sequences: List[np.ndarray], lengths: List[int]):
        """
        Ajustar HMM a secuencias de perfiles
        
        Args:
            sequences: Lista de secuencias de perfiles [seq1, seq2, ...]
            lengths: Longitud de cada secuencia
        """
        print("\nEntrenando Hidden Markov Model...")
        
        # Concatenar secuencias
        X = np.concatenate(sequences).reshape(-1, 1)
        
        # Crear modelo HMM
        self.hmm_model = hmm.CategoricalHMM(
            n_components=self.n_states,
            n_iter=100,
            random_state=42
        )
        
        # Entrenar
        self.hmm_model.fit(X, lengths)
        
        print("   HMM entrenado")
        print(f"\nMatriz de Transición (probabilidades):")
        self._print_transition_matrix()
    
    def _print_transition_matrix(self):
        """Imprimir matriz de transición de forma legible"""
        trans_matrix = self.hmm_model.transmat_
        
        print("\n   De/A:  ", end="")
        for i in range(self.n_states):
            print(f"P{i:1d}    ", end="")
        print()
        
        for i in range(self.n_states):
            print(f"   P{i}: ", end="")
            for j in range(self.n_states):
                print(f"{trans_matrix[i,j]:.3f}  ", end="")
            print()
    
    def predict_next_states(self, current_sequence: np.ndarray, 
                           n_steps: int = 10) -> np.ndarray:
        """
        Predecir próximos estados dado una secuencia actual
        
        Args:
            current_sequence: Secuencia actual de perfiles [t1, t2, ..., tn]
            n_steps: Número de pasos futuros a predecir
            
        Returns:
            predicted_sequence: Secuencia predicha [t(n+1), ..., t(n+n_steps)]
        """
        if self.hmm_model is None:
            raise ValueError("HMM no entrenado")
        
        # Obtener estado actual más probable
        X = current_sequence.reshape(-1, 1)
        current_state = self.hmm_model.predict(X)[-1]
        
        # Predecir estados futuros
        predicted = []
        state = current_state
        
        for _ in range(n_steps):
            # Siguiente estado más probable
            next_state = np.argmax(self.hmm_model.transmat_[state])
            predicted.append(next_state)
            state = next_state
        
        return np.array(predicted)
    
    def analyze_transition_patterns(self, sequences: List[np.ndarray]) -> Dict:
        """
        Analizar patrones de transición en las secuencias
        
        Returns:
            analysis: Diccionario con estadísticas de transiciones
        """
        print("\nAnalizando Patrones de Transición...")
        
        # Contar transiciones
        transition_counts = np.zeros((self.n_states, self.n_states))
        
        for seq in sequences:
            for i in range(len(seq) - 1):
                from_state = seq[i]
                to_state = seq[i + 1]
                transition_counts[from_state, to_state] += 1
        
        # Convertir a probabilidades
        transition_probs = transition_counts / (transition_counts.sum(axis=1, keepdims=True) + 1e-10)
        
        # Analizar recuperaciones (transición a estados mejores)
        recovery_probs = []
        for i in range(self.n_states):
            # Probabilidad de transitar a un estado mejor (menor ID = mejor perfil)
            prob_improve = transition_probs[i, :i].sum() if i > 0 else 0
            recovery_probs.append(prob_improve)
        
        # Analizar deterioros (transición a estados peores)
        deterioration_probs = []
        for i in range(self.n_states):
            # Probabilidad de transitar a un estado peor (mayor ID = peor perfil)
            prob_worsen = transition_probs[i, i+1:].sum() if i < self.n_states - 1 else 0
            deterioration_probs.append(prob_worsen)
        
        analysis = {
            'transition_matrix_empirical': transition_probs,
            'recovery_probabilities': recovery_probs,
            'deterioration_probabilities': deterioration_probs,
            'transition_counts': transition_counts
        }
        
        print("\n   Probabilidades de Recuperación por Perfil:")
        for i, prob in enumerate(recovery_probs):
            print(f"      Perfil {i} → Estados Mejores: {prob:.3f}")
        
        print("\n   Probabilidades de Deterioro por Perfil:")
        for i, prob in enumerate(deterioration_probs):
            print(f"      Perfil {i} → Estados Peores: {prob:.3f}")
        
        return analysis
    
    def save_model(self, path: str):
        """Guardar modelo HMM"""
        import pickle
        with open(path, 'wb') as f:
            pickle.dump(self.hmm_model, f)
        print(f"   HMM guardado: {path}")
    
    def load_model(self, path: str):
        """Cargar modelo HMM"""
        import pickle
        with open(path, 'rb') as f:
            self.hmm_model = pickle.load(f)
        print(f"   HMM cargado: {path}")


# ============================================================================
# FUNCIÓN PRINCIPAL DE EJECUCIÓN
# ============================================================================

def main():
    """
    Función principal para ejecutar el sistema completo
    """
    print("\n" + "="*80)
    print("SISTEMA DE PERFILES MICROTEMPORALES - PASO 6")
    print("   Clasificación y Predicción de Estados Cognitivos")
    print("="*80)
    
    # Configuración
    BASE_DIR = '../EEG_ADHD_v5'
    FEATURES_FILE = f'{BASE_DIR}/data/processed/microtemporal_features.csv'
    
    # ========================================================================
    # PASO 6.1: Clasificador de Perfiles
    # ========================================================================
    print("\n" + "="*80)
    print("PASO 6.1: CLASIFICADOR DE PERFILES MICROTEMPORALES")
    print("="*80)
    
    classifier = MicrotemporalProfileClassifier(base_dir=BASE_DIR)
    
    # Cargar y preparar datos
    df, profile_labels = classifier.load_and_prepare_data(FEATURES_FILE)
    
    # Entrenar con validación cruzada sujeto-wise
    results = classifier.train_with_subject_wise_cv(df, n_folds=5)
    
    # Guardar resultados
    results_df = pd.DataFrame([
        {
            'Model': model_name,
            'Accuracy_Mean': data['accuracy_mean'],
            'Accuracy_Std': data['accuracy_std']
        }
        for model_name, data in results.items()
    ])
    results_path = Path(BASE_DIR) / 'results' / 'profile_classification_results.csv'
    results_df.to_csv(results_path, index=False)
    print(f"\nResultados guardados: {results_path}")
    
    # ========================================================================
    # PASO 6.2: Predictor de Evolución Temporal (HMM)
    # ========================================================================
    print("\n" + "="*80)
    print("PASO 6.2: PREDICTOR DE EVOLUCIÓN TEMPORAL (HMM)")
    print("="*80)
    
    # Crear secuencias temporales por sujeto
    print("\nCreando secuencias temporales por sujeto...")
    sequences = []
    lengths = []
    
    for subject_id in df['subject_id'].unique():
        subject_data = df[df['subject_id'] == subject_id].sort_index()
        sequence = subject_data['profile'].values
        
        if len(sequence) >= 5:  # Mínimo 5 ventanas
            sequences.append(sequence)
            lengths.append(len(sequence))
    
    print(f"   Secuencias creadas: {len(sequences)}")
    print(f"   Longitud promedio: {np.mean(lengths):.1f} ventanas")
    
    # Entrenar HMM
    predictor = TemporalEvolutionPredictor(n_states=5)
    predictor.fit_hmm(sequences, lengths)
    
    # Analizar patrones de transición
    transition_analysis = predictor.analyze_transition_patterns(sequences)
    
    # Guardar HMM
    hmm_path = Path(BASE_DIR) / 'models' / 'temporal_evolution_hmm.pkl'
    predictor.save_model(str(hmm_path))
    
    # ========================================================================
    # PASO 6.3: Visualizaciones
    # ========================================================================
    print("\n" + "="*80)
    print("PASO 6.3: GENERANDO VISUALIZACIONES")
    print("="*80)
    
    # Matriz de confusión (último fold)
    best_model_name = max(results.keys(), key=lambda k: results[k]['accuracy_mean'])
    last_report = results[best_model_name]['last_fold_report']
    
    # Generar visualización de matriz de transición
    plot_transition_matrix(
        transition_analysis['transition_matrix_empirical'],
        save_path=str(Path(BASE_DIR) / 'results' / 'transition_matrix.png')
    )
    
    print("\n" + "="*80)
    print("PASO 6 COMPLETADO EXITOSAMENTE")
    print("="*80)
    print("\nArchivos generados:")
    print(f"   • Modelo clasificador: {BASE_DIR}/models/profile_classifier.pkl")
    print(f"   • Modelo HMM: {BASE_DIR}/models/temporal_evolution_hmm.pkl")
    print(f"   • Resultados: {BASE_DIR}/results/profile_classification_results.csv")
    print(f"   • Visualización: {BASE_DIR}/results/transition_matrix.png")
    
    return classifier, predictor, results, transition_analysis


def plot_transition_matrix(matrix: np.ndarray, save_path: str):
    """
    Visualizar matriz de transición de estados
    """
    profile_names = [
        "P0: Sostenida",
        "P1: Compensada", 
        "P2: Variable",
        "P3: Lapsos",
        "P4: Hipoactiva"
    ]
    
    plt.figure(figsize=(10, 8))
    sns.heatmap(matrix, annot=True, fmt='.3f', cmap='RdYlGn_r',
                xticklabels=profile_names, yticklabels=profile_names,
                cbar_kws={'label': 'Probabilidad de Transición'})
    plt.title('Matriz de Transición de Estados Microtemporales', fontsize=14, fontweight='bold')
    plt.xlabel('Estado Siguiente', fontsize=12)
    plt.ylabel('Estado Actual', fontsize=12)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"   Matriz de transición guardada: {save_path}")


if __name__ == "__main__":
    classifier, predictor, results, analysis = main()
