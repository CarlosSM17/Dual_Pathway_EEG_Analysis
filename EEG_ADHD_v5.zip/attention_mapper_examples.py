"""
Ejemplo de Uso: Mapas de Atención Temporal
===========================================

"""
import matplotlib as plt
import numpy as np
import pandas as pd
from pathlib import Path
import sys

from temporal_attention_mapper import TemporalAttentionMapper


def example_1_single_subject_map():
    """
    Ejemplo 1: Generar mapa de atención para un sujeto individual
    """
    print("\n" + "="*80)
    print("EJEMPLO 1: Mapa de Atención Individual")
    print("="*80)
    
    # Simular datos de atención temporal (en producción, cargar datos reales)
    np.random.seed(42)
    
    # Sujeto ADHD: atención más baja y variable
    n_points = 300  # 5 minutos a 1 Hz
    timestamps = np.arange(n_points)
    
    # Patrón ADHD: inicio normal, luego declive con lapsos
    attention_adhd = np.concatenate([
        np.random.normal(0.6, 0.1, 100),  # Inicio relativamente normal
        np.random.normal(0.4, 0.15, 100),  # Declive
        np.random.normal(0.35, 0.2, 100)   # Más lapsos
    ])
    attention_adhd = np.clip(attention_adhd, 0, 1)
    
    # Agregar algunos lapsos puntuales
    lapse_indices = np.random.choice(range(150, 300), 20, replace=False)
    attention_adhd[lapse_indices] = np.random.uniform(0.1, 0.25, 20)
    
    # Crear mapper
    mapper = TemporalAttentionMapper(output_dir='./example_attention_maps')
    
    # Generar mapa
    fig = mapper.create_temporal_attention_map(
        subject_id='v107',
        attention_sequence=attention_adhd,
        timestamps=timestamps,
        diagnosis='ADHD',
        save=True
    )
    
    print("\n Mapa individual generado")


def example_2_cohort_comparison():
    """
    Ejemplo 2: Análisis de segmentos discriminativos en cohorte
    """
    print("\n" + "="*80)
    print("EJEMPLO 2: Análisis de Segmentos Discriminativos")
    print("="*80)
    
    # Simular datos de cohorte
    np.random.seed(42)
    
    n_adhd = 30
    n_control = 30
    n_timepoints = 300  # 5 minutos
    
    data_list = []
    
    # Generar datos ADHD
    for subj in range(n_adhd):
        timestamps = np.arange(n_timepoints)
        
        # Patrón ADHD: declive temporal
        base_attention = 0.5 - (timestamps / n_timepoints) * 0.2  # Declive
        noise = np.random.normal(0, 0.15, n_timepoints)
        attention = np.clip(base_attention + noise, 0, 1)
        
        for t, att in zip(timestamps, attention):
            data_list.append({
                'subject_id': f'adhd_{subj:03d}',
                'time': t,
                'attention': att,
                'adhd_label': 1
            })
    
    # Generar datos Control
    for subj in range(n_control):
        timestamps = np.arange(n_timepoints)
        
        # Patrón Control: más estable
        base_attention = 0.6 - (timestamps / n_timepoints) * 0.05  # Declive leve
        noise = np.random.normal(0, 0.08, n_timepoints)
        attention = np.clip(base_attention + noise, 0, 1)
        
        for t, att in zip(timestamps, attention):
            data_list.append({
                'subject_id': f'control_{subj:03d}',
                'time': t,
                'attention': att,
                'adhd_label': 0
            })
    
    # Crear DataFrame
    data = pd.DataFrame(data_list)
    
    # Crear mapper y analizar
    mapper = TemporalAttentionMapper(output_dir='./example_attention_maps')
    
    analysis = mapper.identify_discriminative_segments(
        data=data,
        segment_duration=30  # Segmentos de 30s
    )
    
    # Visualizar
    fig = mapper.visualize_discriminative_segments(
        analysis=analysis,
        save=True
    )
    
    # Generar reporte
    report = mapper.generate_clinical_report(
        analysis=analysis,
        output_file='./example_attention_maps/clinical_report.txt'
    )
    
    print("\n Análisis de cohorte completado")
    print(f"   Segmentos discriminativos: {analysis['n_discriminative']}/{analysis['n_total_segments']}")


def example_3_load_from_eeg_data():
    """
    Ejemplo 3: Cargar datos reales del sistema EEG-ADHD
    """
    print("\n" + "="*80)
    print("EJEMPLO 3: Datos Reales del Sistema EEG-ADHD")
    print("="*80)
    
    # Ruta a features microtemporales
    features_file = Path('../EEG_ADHD_v5/data/processed/microtemporal_features.csv')
    
    if not features_file.exists():
        print(f"\n     Archivo no encontrado: {features_file}")
        print("   Ejecuta primero Fase3.py para generar features")
        return
    
    # Cargar datos
    print(f"\n Cargando datos de: {features_file}")
    df = pd.read_csv(features_file)
    
    print(f"    Datos cargados: {len(df)} secuencias")
    print(f"   Sujetos: {df['subject_id'].nunique()}")
    print(f"   Columnas: {', '.join(df.columns.tolist()[:10])}...")
    
    # Verificar columnas necesarias
    required_cols = ['subject_id', 'mean_attention']
    if not all(col in df.columns for col in required_cols):
        print(f"\n   Faltan columnas necesarias: {required_cols}")
        return
    
    # Crear mapper
    mapper = TemporalAttentionMapper(output_dir='../EEG_ADHD_v5/attention_maps')
    
    # Seleccionar muestra de sujetos
    sample_subjects = df['subject_id'].unique()
    
    print(f"\nGenerando mapas para {len(sample_subjects)} sujetos...")
    
    for subject_id in sample_subjects:
        subject_data = df[df['subject_id'] == subject_id]
        
        if len(subject_data) < 5:
            print(f"     {subject_id}: Muy pocas secuencias ({len(subject_data)})")
            continue
        
        # Extraer atención
        attention_seq = subject_data['mean_attention'].values
        timestamps = np.arange(len(attention_seq)) * 60  # Asumiendo ventanas de 60s
        
        # Determinar diagnóstico
        if 'adhd_label' in subject_data.columns:
            diagnosis = 'ADHD' if subject_data['adhd_label'].iloc[0] == 1 else 'Control'
        else:
            diagnosis = 'Unknown'
        
        # Generar mapa
        try:
            fig = mapper.create_temporal_attention_map(
                subject_id=subject_id,
                attention_sequence=attention_seq,
                timestamps=timestamps,
                diagnosis=diagnosis,
                save=True
            )
            
            
        except Exception as e:
            print(f"     Error con {subject_id}: {e}")
    
    print(f"\n Mapas generados en: ../EEG_ADHD_v5/attention_maps")


def example_4_discriminative_analysis_real_data():
    
    print("\n" + "="*80)
    print("EJEMPLO 4: Análisis Discriminativo con Datos Reales")
    print("="*80)
    
    # Cargar features
    features_file = Path('../EEG_ADHD_v5/data/processed/microtemporal_features.csv')
    
    if not features_file.exists():
        print(f"\n     Archivo no encontrado: {features_file}")
        return
    
    print(f"\n Cargando datos...")
    df = pd.read_csv(features_file)
    
    # Verificar columnas necesarias
    if 'adhd_label' not in df.columns:
        print("     Columna 'adhd_label' no encontrada")
        print("   Asignando diagnósticos aleatorios para demostración...")
        df['adhd_label'] = np.random.choice([0, 1], len(df))
    
    # Preparar datos para análisis
    # Necesitamos: subject_id, time, attention, adhd_label
    
    if 'sequence_id' in df.columns:
        # Usar sequence_id como proxy de tiempo
        df['time'] = df.groupby('subject_id')['sequence_id'].transform(
            lambda x: (x - x.min()) * 60  # Convertir a segundos (ventanas de 60s)
        )
    else:
        # Crear tiempo sintético
        df['time'] = df.groupby('subject_id').cumcount() * 60
    
    # Usar mean_attention como medida de atención
    data_for_analysis = df[['subject_id', 'time', 'mean_attention', 'adhd_label']].copy()
    data_for_analysis.rename(columns={'mean_attention': 'attention'}, inplace=True)
    
    print(f"    Datos preparados: {len(data_for_analysis)} puntos")
    print(f"   ADHD: {(data_for_analysis['adhd_label'] == 1).sum()}")
    print(f"   Control: {(data_for_analysis['adhd_label'] == 0).sum()}")
    
    # Crear mapper y analizar
    mapper = TemporalAttentionMapper(output_dir='../EEG_ADHD_v5/attention_maps')
    
    analysis = mapper.identify_discriminative_segments(
        data=data_for_analysis,
        segment_duration=60  # Segmentos de 60s
    )
    
    # Visualizar
    fig = mapper.visualize_discriminative_segments(
        analysis=analysis,
        save=True
    )
    
    
    # Generar reporte
    report = mapper.generate_clinical_report(
        analysis=analysis,
        output_file='../EEG_ADHD_v5/attention_maps/clinical_report.txt'
    )
    
    # Mostrar resultados clave
    print("\n RESULTADOS:")
    print(f"   Segmentos totales: {analysis['n_total_segments']}")
    print(f"   Segmentos discriminativos: {analysis['n_discriminative']}")
    
    if analysis['most_discriminative'] is not None:
        seg = analysis['most_discriminative']
        print(f"\n   Segmento más discriminativo:")
        print(f"      Tiempo: {seg['start_time']:.0f}-{seg['end_time']:.0f}s")
        print(f"      Cohen's d: {seg['cohens_d']:.3f}")
        print(f"      AUC: {seg['auc']:.3f}")
    
    print(f"\n Análisis completado")


def main():
    
    print("\n" + "="*80)
    print("EJEMPLOS DE USO: Mapas de Atención Temporal")
    print("="*80)
    
    import matplotlib
    matplotlib.use('Agg')  # Backend sin GUI
    import matplotlib.pyplot as plt
    
    examples = [
        
        ("Datos Reales - Mapas Individuales", example_3_load_from_eeg_data),
        ("Datos Reales - Análisis Discriminativo", example_4_discriminative_analysis_real_data)
    ]
    
    print("\nEjemplos disponibles:")
    for i, (name, _) in enumerate(examples, 1):
        print(f"  {i}. {name}")
    
    print("\n" + "-"*80)
    
    # Ejecutar ejemplos
    for name, func in examples:
        try:
            func()
        except Exception as e:
            print(f"\n  Error en '{name}': {e}")
            import traceback
            traceback.print_exc()
    
    print("\n" + "="*80)
    print(" Ejemplos completados")
    print("="*80)


if __name__ == "__main__":
    main()
