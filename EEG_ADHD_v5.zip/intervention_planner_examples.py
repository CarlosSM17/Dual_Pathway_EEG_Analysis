"""
Ejemplo de Uso: Generación de Planes de Intervención Educativa
================================================================

"""

import sys
from pathlib import Path

# Importar módulos del sistema
from integrated_profile_system import IntegratedProfile
from educational_intervention_planner import (
    EducationalInterventionPlanner,
    generate_intervention_plan_for_profile,
    generate_plans_for_cohort
)

# Si tienes los perfiles guardados
import json


def example_1_single_profile():
    """
    Ejemplo 1: Generar plan para un perfil individual
    """
    print("\n" + "="*80)
    print("EJEMPLO 1: Plan Individual")
    print("="*80)
    
    # Opción A: Cargar perfil desde JSON
    profile_path = '../EEG_ADHD_v5/profiles/v107_profile.json'
    
    if Path(profile_path).exists():
        with open(profile_path, 'r', encoding='utf-8') as f:
            profile_data = json.load(f)
        
        # Reconstruir perfil
        profile = IntegratedProfile.from_dict(profile_data)
        
        # Generar plan
        plan = generate_intervention_plan_for_profile(
            profile=profile,
            output_dir='../EEG_ADHD_v5/intervention_plans'
        )
        
        print("\n Plan generado exitosamente")
        print(f"   Estrategias de alta prioridad: {len(plan['recommended_strategies']['high_priority'])}")
        print(f"   Estrategias totales: {sum(len(v) for v in plan['recommended_strategies'].values())}")
        
    else:
        print(f" Archivo de perfil no encontrado: {profile_path}")
        print("   Ejecuta primero Fase4.py para generar perfiles")


def example_2_cohort_from_directory():
    """
    Ejemplo 2: Generar planes para todos los perfiles en un directorio
    """
    print("\n" + "="*80)
    print("EJEMPLO 2: Planes para Cohorte Completa")
    print("="*80)
    
    profiles_dir = Path('../EEG_ADHD_v5/profiles')
    
    if not profiles_dir.exists():
        print(f"  Directorio de perfiles no encontrado: {profiles_dir}")
        return
    
    # Cargar todos los perfiles JSON
    profiles = []
    for json_file in profiles_dir.glob('*_profile.json'):
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                profile_data = json.load(f)
            profile = IntegratedProfile.from_dict(profile_data)
            profiles.append(profile)
        except Exception as e:
            print(f"     Error cargando {json_file.name}: {e}")
    
    print(f"\n Perfiles cargados: {len(profiles)}")
    
    if profiles:
        # Generar planes para todos
        generate_plans_for_cohort(
            profiles=profiles,
            output_dir='../EEG_ADHD_v5/intervention_plans'
        )


def example_3_custom_profile():
    """
    Ejemplo 3: Crear perfil personalizado y generar plan
    """
    print("\n" + "="*80)
    print("EJEMPLO 3: Plan desde Perfil Personalizado")
    print("="*80)
    
    # Crear perfil de ejemplo
    custom_profile = IntegratedProfile(
        subject_id='example_student',
        
        # Diagnóstico ADHD
        adhd_diagnosis='ADHD',
        adhd_probability=0.85,
        adhd_confidence='Alta',
        
        # Perfil microtemporal
        dominant_profile=2,  # Variabilidad Alta
        dominant_profile_name='Variabilidad Alta con Recuperación',
        profile_distribution={0: 0.1, 1: 0.2, 2: 0.5, 3: 0.1, 4: 0.1},
        profile_stability=0.5,
        
        # Severidad
        severity_score=55.0,
        severity_category='Moderado',
        attention_deficit_score=45.0,
        variability_score=60.0,
        recovery_score=40.0,
        vigilance_score=50.0,
        
        # Índices de funcionamiento
        sustained_attention_index=0.45,
        cognitive_flexibility_index=0.55,
        self_regulation_index=0.40,
        
        # Patrones temporales
        time_on_task_pattern='Declive Moderado',
        transition_frequency='Alta',
        recovery_capacity='Moderada',
        
        # Riesgo
        academic_impact_risk='Alto',
        intervention_urgency='Alta',
        response_to_intervention_prediction='Moderada',
        
        # Metadata
        n_sequences=10,
        analysis_timestamp='2024-12-19T00:00:00'
    )
    
    # Generar plan
    planner = EducationalInterventionPlanner(output_dir='./example_plans')
    plan = planner.generate_plan(custom_profile)
    
    print("\n Resumen del plan:")
    print(f"   Nivel de severidad: {plan['student_info']['severity_category']}")
    print(f"   Estrategias de alta prioridad:")
    for strategy in plan['recommended_strategies']['high_priority']:
        print(f"      • {strategy['code']}: {strategy['name']}")


def example_4_analyze_plan_details():
    """
    Ejemplo 4: Analizar detalles de un plan generado
    """
    print("\n" + "="*80)
    print("EJEMPLO 4: Análisis Detallado de Plan")
    print("="*80)
    
    # Cargar un plan existente
    plan_path = '../EEG_ADHD_v5/intervention_plans/v107_intervention_plan.json'
    
    if Path(plan_path).exists():
        with open(plan_path, 'r', encoding='utf-8') as f:
            plan = json.load(f)
        
        print(f"\n Análisis del plan para: {plan['student_info']['subject_id']}")
        print(f"   Diagnóstico: {plan['student_info']['adhd_diagnosis']}")
        print(f"   Severidad: {plan['student_info']['severity_category']}")
        
        print("\n Áreas de necesidad identificadas:")
        for area in plan['needs_analysis']['priority_areas']:
            print(f"   • {area}")
        
        print("\n Fortalezas identificadas:")
        for strength in plan['needs_analysis']['strengths']:
            print(f"   • {strength}")
        
        print("\n Distribución de estrategias por categoría:")
        all_strategies = (
            plan['recommended_strategies']['high_priority'] +
            plan['recommended_strategies']['moderate_priority'] +
            plan['recommended_strategies']['supplementary']
        )
        
        categories = {}
        for strategy in all_strategies:
            cat = strategy['category']
            categories[cat] = categories.get(cat, 0) + 1
        
        for cat, count in sorted(categories.items()):
            print(f"   {cat}: {count} estrategias")
        
        print("\n  Línea de tiempo:")
        timeline = plan['implementation_timeline']
        print(f"   Fase 1 (inmediato): {len(timeline['phase_1_immediate'])} estrategias")
        print(f"   Fase 2 (corto plazo): {len(timeline['phase_2_short_term'])} estrategias")
        print(f"   Fase 3 (largo plazo): {len(timeline['phase_3_long_term'])} estrategias")
        
    else:
        print(f"  Plan no encontrado: {plan_path}")
        print("   Ejecuta primero el Ejemplo 1 o 2")


def example_5_compare_plans():
    """
    Ejemplo 5: Comparar planes de diferentes perfiles
    """
    print("\n" + "="*80)
    print("EJEMPLO 5: Comparación de Planes ADHD vs Control")
    print("="*80)
    
    plans_dir = Path('../EEG_ADHD_v5/intervention_plans')
    
    if not plans_dir.exists():
        print(f"  Directorio de planes no encontrado")
        return
    
    # Cargar todos los planes
    adhd_plans = []
    control_plans = []
    
    for json_file in plans_dir.glob('*_intervention_plan.json'):
        try:
            with open(json_file, 'r', encoding='utf-8') as f:
                plan = json.load(f)
            
            if plan['student_info']['adhd_diagnosis'] == 'ADHD':
                adhd_plans.append(plan)
            else:
                control_plans.append(plan)
        except Exception as e:
            continue
    
    print(f"\n Planes cargados:")
    print(f"   ADHD: {len(adhd_plans)}")
    print(f"   Control: {len(control_plans)}")
    
    if adhd_plans and control_plans:
        # Comparar número promedio de estrategias
        adhd_avg = sum(
            len(p['recommended_strategies']['high_priority'])
            for p in adhd_plans
        ) / len(adhd_plans)
        
        control_avg = sum(
            len(p['recommended_strategies']['high_priority'])
            for p in control_plans
        ) / len(control_plans)
        
        print(f"\n Estrategias de alta prioridad (promedio):")
        print(f"   ADHD: {adhd_avg:.1f}")
        print(f"   Control: {control_avg:.1f}")
        
        # Estrategias más comunes en ADHD
        adhd_strategies = {}
        for plan in adhd_plans:
            for strategy in plan['recommended_strategies']['high_priority']:
                code = strategy['code']
                adhd_strategies[code] = adhd_strategies.get(code, 0) + 1
        
        print(f"\n Estrategias más frecuentes en ADHD:")
        for code, count in sorted(adhd_strategies.items(), key=lambda x: x[1], reverse=True)[:5]:
            pct = count / len(adhd_plans) * 100
            print(f"   {code}: {count}/{len(adhd_plans)} ({pct:.0f}%)")


def main():
    """Ejecutar todos los ejemplos"""
    print("\n" + "="*80)
    print("EJEMPLOS DE USO: Generación de Planes de Intervención Educativa")
    print("="*80)
    
    examples = [
        ("Cohorte Completa", example_2_cohort_from_directory),
        ("Perfil Personalizado", example_3_custom_profile),
        ("Análisis Detallado", example_4_analyze_plan_details),
        ("Comparación ADHD vs Control", example_5_compare_plans)
    ]
    
    print("\nEjemplos disponibles:")
    for i, (name, _) in enumerate(examples, 1):
        print(f"  {i}. {name}")
    
    print("\n" + "-"*80)
    
    # Ejecutar ejemplos automáticamente
    for name, func in examples:
        try:
            func()
        except Exception as e:
            print(f"\n  Error en '{name}': {e}")
            import traceback
            traceback.print_exc()
    
    print("\n" + "="*80)
    print(" Ejemplos completados")
    print("="*80)


if __name__ == "__main__":
    main()
