"""
Módulo de Mapas de Atención Temporal 
===================================================================
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from typing import Dict, List, Tuple, Optional
from scipy import stats
from sklearn.metrics import roc_auc_score
import warnings
warnings.filterwarnings('ignore')


class TemporalAttentionMapper:
    """
    Genera mapas de atención temporal y análisis de discriminación
    """
    
    def __init__(self, output_dir: str = './attention_maps'):
        """
        Inicializar generador de mapas
        
        Args:
            output_dir: Directorio para guardar visualizaciones
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Configuración de visualización
        plt.style.use('seaborn-v0_8-darkgrid')
        sns.set_palette("husl")
        
    def create_temporal_attention_map(self,
                                     subject_id: str,
                                     attention_sequence: np.ndarray,
                                     timestamps: np.ndarray,
                                     diagnosis: str,
                                     save: bool = True) -> plt.Figure:
        """
        Crear mapa de atención temporal individual
        
        Args:
            subject_id: ID del sujeto
            attention_sequence: Niveles de atención [n_timepoints]
            timestamps: Timestamps correspondientes [n_timepoints]
            diagnosis: 'ADHD' o 'Control'
            save: Si guardar la figura
            
        Returns:
            fig: Figura de matplotlib
        """
        fig = plt.figure(figsize=(16, 10))
        gs = fig.add_gridspec(4, 2, hspace=0.3, wspace=0.3)
        
        # Título principal
        fig.suptitle(
            f'Mapa de Atención Temporal - {subject_id} ({diagnosis})',
            fontsize=16, fontweight='bold', y=0.98
        )
        
        # ====================================================================
        # 1. Serie temporal completa
        # ====================================================================
        ax1 = fig.add_subplot(gs[0, :])
        
        # Línea de atención
        ax1.plot(timestamps, attention_sequence, 'b-', linewidth=2, alpha=0.7)
        ax1.fill_between(timestamps, attention_sequence, alpha=0.3)
        
        # Líneas de referencia
        mean_attention = np.mean(attention_sequence)
        ax1.axhline(mean_attention, color='r', linestyle='--', 
                   label=f'Media: {mean_attention:.3f}', linewidth=2)
        ax1.axhline(0.5, color='g', linestyle=':', 
                   label='Umbral óptimo: 0.5', linewidth=1.5)
        
        # Identificar lapsos (attention < 0.3)
        lapsos = attention_sequence < 0.3
        if np.any(lapsos):
            ax1.scatter(timestamps[lapsos], attention_sequence[lapsos],
                       color='red', s=100, marker='x', 
                       label=f'Lapsos ({np.sum(lapsos)})', zorder=5)
        
        ax1.set_xlabel('Tiempo (s)', fontsize=12)
        ax1.set_ylabel('Nivel de Atención', fontsize=12)
        ax1.set_title('Serie Temporal de Atención', fontsize=14, fontweight='bold')
        ax1.legend(loc='upper right')
        ax1.grid(True, alpha=0.3)
        ax1.set_ylim([0, 1])
        
        # ====================================================================
        # 2. Heatmap de ventanas temporales
        # ====================================================================
        ax2 = fig.add_subplot(gs[1, :])
        
        # Dividir en ventanas de 30s
        window_size = 30  # segundos
        n_windows = int(np.ceil(timestamps[-1] / window_size))
        
        attention_windows = []
        window_labels = []
        
        for i in range(n_windows):
            start_time = i * window_size
            end_time = (i + 1) * window_size
            
            mask = (timestamps >= start_time) & (timestamps < end_time)
            if np.sum(mask) > 0:
                window_attention = attention_sequence[mask]
                attention_windows.append(window_attention)
                window_labels.append(f'{start_time}-{end_time}s')
        
        # Crear matriz para heatmap (padding para mismo tamaño)
        max_len = max(len(w) for w in attention_windows)
        attention_matrix = np.full((len(attention_windows), max_len), np.nan)
        
        for i, window in enumerate(attention_windows):
            attention_matrix[i, :len(window)] = window
        
        # Plotear heatmap
        im = ax2.imshow(attention_matrix, aspect='auto', cmap='RdYlGn',
                       vmin=0, vmax=1, interpolation='nearest')
        
        ax2.set_yticks(range(len(window_labels)))
        ax2.set_yticklabels(window_labels, fontsize=10)
        ax2.set_xlabel('Muestras dentro de ventana', fontsize=12)
        ax2.set_ylabel('Ventana Temporal', fontsize=12)
        ax2.set_title('Heatmap de Atención por Ventana Temporal', 
                     fontsize=14, fontweight='bold')
        
        # Colorbar
        cbar = plt.colorbar(im, ax=ax2)
        cbar.set_label('Nivel de Atención', fontsize=11)
        
        # ====================================================================
        # 3. Distribución por ventana
        # ====================================================================
        ax3 = fig.add_subplot(gs[2, 0])
        
        window_means = [np.mean(w) for w in attention_windows]
        window_stds = [np.std(w) for w in attention_windows]
        
        x_pos = np.arange(len(window_means))
        ax3.bar(x_pos, window_means, yerr=window_stds, 
               capsize=5, alpha=0.7, color='steelblue')
        ax3.axhline(0.5, color='g', linestyle=':', linewidth=2)
        
        ax3.set_xticks(x_pos)
        ax3.set_xticklabels([f'V{i+1}' for i in x_pos], fontsize=9)
        ax3.set_xlabel('Ventana', fontsize=12)
        ax3.set_ylabel('Atención Media ± SD', fontsize=12)
        ax3.set_title('Atención Promedio por Ventana', 
                     fontsize=13, fontweight='bold')
        ax3.grid(True, alpha=0.3, axis='y')
        ax3.set_ylim([0, 1])
        
        # ====================================================================
        # 4. Variabilidad temporal
        # ====================================================================
        ax4 = fig.add_subplot(gs[2, 1])
        
        # Calcular variabilidad móvil (rolling std)
        window_len = 5
        rolling_std = pd.Series(attention_sequence).rolling(
            window=window_len, center=True
        ).std().fillna(0)
        
        ax4.plot(timestamps, rolling_std, 'r-', linewidth=2)
        ax4.fill_between(timestamps, rolling_std, alpha=0.3, color='red')
        
        mean_std = np.mean(rolling_std)
        ax4.axhline(mean_std, color='k', linestyle='--',
                   label=f'Media: {mean_std:.3f}', linewidth=2)
        
        ax4.set_xlabel('Tiempo (s)', fontsize=12)
        ax4.set_ylabel('Variabilidad (SD móvil)', fontsize=12)
        ax4.set_title(f'Variabilidad Temporal (ventana={window_len} puntos)',
                     fontsize=13, fontweight='bold')
        ax4.legend()
        ax4.grid(True, alpha=0.3)
        
        # ====================================================================
        # 5. Estadísticas descriptivas
        # ====================================================================
        ax5 = fig.add_subplot(gs[3, 0])
        ax5.axis('off')
        
        stats_text = f"""
        ESTADÍSTICAS DESCRIPTIVAS
        {'='*40}
        
        Nivel de Atención:
          • Media: {np.mean(attention_sequence):.3f}
          • Mediana: {np.median(attention_sequence):.3f}
          • SD: {np.std(attention_sequence):.3f}
          • Rango: [{np.min(attention_sequence):.3f}, {np.max(attention_sequence):.3f}]
        
        Variabilidad:
          • Coef. Variación: {(np.std(attention_sequence) / np.mean(attention_sequence)):.3f}
          • IQR: {np.percentile(attention_sequence, 75) - np.percentile(attention_sequence, 25):.3f}
        
        Eventos:
          • Lapsos (<0.3): {np.sum(attention_sequence < 0.3)} ({np.sum(attention_sequence < 0.3) / len(attention_sequence) * 100:.1f}%)
          • Alta atención (>0.7): {np.sum(attention_sequence > 0.7)} ({np.sum(attention_sequence > 0.7) / len(attention_sequence) * 100:.1f}%)
        
        Ventanas Temporales:
          • Total: {len(window_means)}
          • Ventana con menor atención: V{np.argmin(window_means) + 1} ({np.min(window_means):.3f})
          • Ventana con mayor atención: V{np.argmax(window_means) + 1} ({np.max(window_means):.3f})
        """
        
        ax5.text(0.05, 0.95, stats_text, transform=ax5.transAxes,
                fontsize=10, verticalalignment='top', 
                fontfamily='monospace',
                bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.3))
        
        # ====================================================================
        # 6. Histograma de distribución
        # ====================================================================
        ax6 = fig.add_subplot(gs[3, 1])
        
        ax6.hist(attention_sequence, bins=30, alpha=0.7, 
                color='steelblue', edgecolor='black')
        ax6.axvline(np.mean(attention_sequence), color='r', 
                   linestyle='--', linewidth=2, label='Media')
        ax6.axvline(np.median(attention_sequence), color='g',
                   linestyle=':', linewidth=2, label='Mediana')
        ax6.axvline(0.5, color='orange', linestyle='-.',
                   linewidth=2, label='Umbral óptimo')
        
        ax6.set_xlabel('Nivel de Atención', fontsize=12)
        ax6.set_ylabel('Frecuencia', fontsize=12)
        ax6.set_title('Distribución de Niveles de Atención',
                     fontsize=13, fontweight='bold')
        ax6.legend()
        ax6.grid(True, alpha=0.3, axis='y')
        
        plt.tight_layout()
        
        if save:
            filename = self.output_dir / f'{subject_id}_attention_map.png'
            fig.savefig(filename, dpi=300, bbox_inches='tight')
            print(f"    Mapa guardado: {filename}")
        
        return fig
    
    def identify_discriminative_segments(self,
                                        data: pd.DataFrame,
                                        segment_duration: int = 30) -> Dict:
        """
        Identificar segmentos temporales discriminativos para ADHD vs Control
        
        Args:
            data: DataFrame con columnas [subject_id, time, attention, adhd_label]
            segment_duration: Duración de segmentos en segundos
            
        Returns:
            analysis: Diccionario con análisis de discriminación
        """
        print("\n Analizando segmentos temporales discriminativos...")
        
        # Dividir en segmentos
        max_time = data['time'].max()
        n_segments = int(np.ceil(max_time / segment_duration))
        
        segment_results = []
        
        for seg_idx in range(n_segments):
            start_time = seg_idx * segment_duration
            end_time = (seg_idx + 1) * segment_duration
            
            # Datos del segmento
            segment_data = data[
                (data['time'] >= start_time) & (data['time'] < end_time)
            ].copy()
            
            if len(segment_data) == 0:
                continue
            
            # Calcular métricas por grupo
            adhd_data = segment_data[segment_data['adhd_label'] == 1]['attention']
            control_data = segment_data[segment_data['adhd_label'] == 0]['attention']
            
            if len(adhd_data) == 0 or len(control_data) == 0:
                continue
            
            # Estadísticas
            adhd_mean = adhd_data.mean()
            control_mean = control_data.mean()
            
            # T-test
            t_stat, p_value = stats.ttest_ind(adhd_data, control_data)
            
            # Effect size (Cohen's d)
            pooled_std = np.sqrt(
                ((len(adhd_data) - 1) * adhd_data.std()**2 + 
                 (len(control_data) - 1) * control_data.std()**2) /
                (len(adhd_data) + len(control_data) - 2)
            )
            cohens_d = (adhd_mean - control_mean) / pooled_std
            
            # AUC (capacidad discriminativa)
            labels = np.concatenate([
                np.ones(len(adhd_data)),
                np.zeros(len(control_data))
            ])
            scores = np.concatenate([adhd_data.values, control_data.values])
            
            # Invertir scores porque menor atención = más ADHD
            auc = roc_auc_score(labels, -scores)  
            
            segment_results.append({
                'segment': seg_idx + 1,
                'start_time': start_time,
                'end_time': end_time,
                'adhd_mean': adhd_mean,
                'adhd_std': adhd_data.std(),
                'control_mean': control_mean,
                'control_std': control_data.std(),
                'difference': adhd_mean - control_mean,
                't_statistic': t_stat,
                'p_value': p_value,
                'cohens_d': cohens_d,
                'auc': auc,
                'n_adhd': len(adhd_data),
                'n_control': len(control_data)
            })
        
        # Convertir a DataFrame
        results_df = pd.DataFrame(segment_results)
        
        # Identificar segmentos más discriminativos
        # Criterio: |Cohen's d| > 0.5 y p < 0.05
        discriminative_segments = results_df[
            (np.abs(results_df['cohens_d']) > 0.5) & 
            (results_df['p_value'] < 0.05)
        ].sort_values('cohens_d', key=abs, ascending=False)
        
        analysis = {
            'all_segments': results_df,
            'discriminative_segments': discriminative_segments,
            'n_total_segments': len(results_df),
            'n_discriminative': len(discriminative_segments),
            'most_discriminative': results_df.loc[results_df['cohens_d'].abs().idxmax()] if len(results_df) > 0 else None,
            'best_auc_segment': results_df.loc[results_df['auc'].idxmax()] if len(results_df) > 0 else None
        }
        
        print(f"   Total de segmentos analizados: {analysis['n_total_segments']}")
        print(f"   Segmentos discriminativos: {analysis['n_discriminative']}")
        
        if analysis['most_discriminative'] is not None:
            seg = analysis['most_discriminative']
            print(f"\n   Segmento más discriminativo:")
            print(f"      Tiempo: {seg['start_time']}-{seg['end_time']}s")
            print(f"      Cohen's d: {seg['cohens_d']:.3f}")
            print(f"      AUC: {seg['auc']:.3f}")
            print(f"      p-value: {seg['p_value']:.4f}")
        
        return analysis
    
    def visualize_discriminative_segments(self,
                                         analysis: Dict,
                                         save: bool = True) -> plt.Figure:
        """
        Visualizar análisis de segmentos discriminativos
        
        Args:
            analysis: Output de identify_discriminative_segments
            save: Si guardar la figura
            
        Returns:
            fig: Figura de matplotlib
        """
        results_df = analysis['all_segments']
        
        fig = plt.figure(figsize=(16, 12))
        gs = fig.add_gridspec(3, 2, hspace=0.3, wspace=0.3)
        
        fig.suptitle(
            'Análisis de Segmentos Temporales Discriminativos ADHD vs Control',
            fontsize=16, fontweight='bold', y=0.98
        )
        
        # ====================================================================
        # 1. Atención media por segmento
        # ====================================================================
        ax1 = fig.add_subplot(gs[0, :])
        
        x = results_df['segment']
        
        ax1.plot(x, results_df['adhd_mean'], 'ro-', linewidth=2, 
                markersize=8, label='ADHD', alpha=0.7)
        ax1.fill_between(x, 
                         results_df['adhd_mean'] - results_df['adhd_std'],
                         results_df['adhd_mean'] + results_df['adhd_std'],
                         alpha=0.2, color='red')
        
        ax1.plot(x, results_df['control_mean'], 'bo-', linewidth=2,
                markersize=8, label='Control', alpha=0.7)
        ax1.fill_between(x,
                         results_df['control_mean'] - results_df['control_std'],
                         results_df['control_mean'] + results_df['control_std'],
                         alpha=0.2, color='blue')
        
        # Marcar segmentos discriminativos
        if len(analysis['discriminative_segments']) > 0:
            disc_segs = analysis['discriminative_segments']['segment'].values
            for seg in disc_segs:
                ax1.axvspan(seg - 0.5, seg + 0.5, alpha=0.2, color='yellow')
        
        ax1.set_xlabel('Segmento Temporal', fontsize=12)
        ax1.set_ylabel('Nivel de Atención', fontsize=12)
        ax1.set_title('Atención Media por Segmento Temporal (± SD)',
                     fontsize=14, fontweight='bold')
        ax1.legend(loc='best', fontsize=11)
        ax1.grid(True, alpha=0.3)
        ax1.set_ylim([0, 1])
        
        # ====================================================================
        # 2. Effect Size (Cohen's d)
        # ====================================================================
        ax2 = fig.add_subplot(gs[1, 0])
        
        colors = ['green' if abs(d) > 0.5 else 'gray' 
                 for d in results_df['cohens_d']]
        
        ax2.bar(results_df['segment'], results_df['cohens_d'],
               color=colors, alpha=0.7, edgecolor='black')
        ax2.axhline(0.5, color='r', linestyle='--', linewidth=2,
                   label='Umbral: d=0.5 (efecto mediano)')
        ax2.axhline(-0.5, color='r', linestyle='--', linewidth=2)
        ax2.axhline(0, color='k', linestyle='-', linewidth=1)
        
        ax2.set_xlabel('Segmento Temporal', fontsize=12)
        ax2.set_ylabel("Cohen's d", fontsize=12)
        ax2.set_title('Tamaño del Efecto por Segmento',
                     fontsize=13, fontweight='bold')
        ax2.legend()
        ax2.grid(True, alpha=0.3, axis='y')
        
        # ====================================================================
        # 3. P-values
        # ====================================================================
        ax3 = fig.add_subplot(gs[1, 1])
        
        # -log10(p) para mejor visualización
        log_p = -np.log10(results_df['p_value'])
        
        colors = ['green' if p < 0.05 else 'gray' 
                 for p in results_df['p_value']]
        
        ax3.bar(results_df['segment'], log_p, color=colors,
               alpha=0.7, edgecolor='black')
        ax3.axhline(-np.log10(0.05), color='r', linestyle='--',
                   linewidth=2, label='p = 0.05')
        ax3.axhline(-np.log10(0.01), color='orange', linestyle=':',
                   linewidth=2, label='p = 0.01')
        
        ax3.set_xlabel('Segmento Temporal', fontsize=12)
        ax3.set_ylabel('-log10(p-value)', fontsize=12)
        ax3.set_title('Significancia Estadística por Segmento',
                     fontsize=13, fontweight='bold')
        ax3.legend()
        ax3.grid(True, alpha=0.3, axis='y')
        
        # ====================================================================
        # 4. AUC (capacidad discriminativa)
        # ====================================================================
        ax4 = fig.add_subplot(gs[2, 0])
        
        colors = ['green' if auc > 0.6 else 'gray' 
                 for auc in results_df['auc']]
        
        ax4.bar(results_df['segment'], results_df['auc'],
               color=colors, alpha=0.7, edgecolor='black')
        ax4.axhline(0.5, color='gray', linestyle='-', linewidth=1,
                   label='Azar (AUC=0.5)')
        ax4.axhline(0.6, color='orange', linestyle='--', linewidth=2,
                   label='Discriminación aceptable')
        ax4.axhline(0.7, color='r', linestyle='--', linewidth=2,
                   label='Buena discriminación')
        
        ax4.set_xlabel('Segmento Temporal', fontsize=12)
        ax4.set_ylabel('AUC', fontsize=12)
        ax4.set_title('Capacidad Discriminativa (AUC-ROC) por Segmento',
                     fontsize=13, fontweight='bold')
        ax4.legend()
        ax4.grid(True, alpha=0.3, axis='y')
        ax4.set_ylim([0.3, 0.9])
        
        # ====================================================================
        # 5. Tabla de segmentos discriminativos
        # ====================================================================
        ax5 = fig.add_subplot(gs[2, 1])
        ax5.axis('off')
        
        if len(analysis['discriminative_segments']) > 0:
            disc = analysis['discriminative_segments'].head(10)
            
            table_text = "SEGMENTOS MÁS DISCRIMINATIVOS\n"
            table_text += "="*60 + "\n\n"
            table_text += f"{'Seg':<5} {'Tiempo':<12} {'d':<7} {'AUC':<7} {'p':<8}\n"
            table_text += "-"*60 + "\n"
            
            for _, row in disc.iterrows():
                table_text += f"{int(row['segment']):<5} "
                table_text += f"{int(row['start_time'])}-{int(row['end_time'])}s{'':<4} "
                table_text += f"{row['cohens_d']:>6.3f}  "
                table_text += f"{row['auc']:>6.3f}  "
                table_text += f"{row['p_value']:>7.4f}\n"
            
            ax5.text(0.05, 0.95, table_text, transform=ax5.transAxes,
                    fontsize=10, verticalalignment='top',
                    fontfamily='monospace',
                    bbox=dict(boxstyle='round', facecolor='lightgreen', alpha=0.3))
        else:
            ax5.text(0.5, 0.5, 'No se encontraron segmentos\nsignificativamente discriminativos',
                    transform=ax5.transAxes, ha='center', va='center',
                    fontsize=12, bbox=dict(boxstyle='round', facecolor='wheat'))
        
        plt.tight_layout()
        
        if save:
            filename = self.output_dir / 'discriminative_segments_analysis.png'
            fig.savefig(filename, dpi=300, bbox_inches='tight')
            print(f"    Análisis guardado: {filename}")
        
        return fig
    
    def generate_clinical_report(self,
                                 analysis: Dict,
                                 output_file: Optional[str] = None) -> str:
        """
        Generar reporte clínico de segmentos discriminativos
        
        Args:
            analysis: Output de identify_discriminative_segments
            output_file: Archivo donde guardar el reporte
            
        Returns:
            report: Texto del reporte
        """
        report_lines = []
        
        report_lines.append("="*80)
        report_lines.append("REPORTE CLÍNICO: SEGMENTOS TEMPORALES DISCRIMINATIVOS ADHD")
        report_lines.append("="*80)
        report_lines.append("")
        
        # Resumen general
        report_lines.append("RESUMEN EJECUTIVO")
        report_lines.append("-"*80)
        report_lines.append(f"Total de segmentos analizados: {analysis['n_total_segments']}")
        report_lines.append(f"Segmentos discriminativos (|d| > 0.5, p < 0.05): {analysis['n_discriminative']}")
        report_lines.append("")
        
        # Segmento más discriminativo
        if analysis['most_discriminative'] is not None:
            seg = analysis['most_discriminative']
            
            report_lines.append("SEGMENTO MÁS DISCRIMINATIVO")
            report_lines.append("-"*80)
            report_lines.append(f"Ventana temporal: {seg['start_time']:.0f}-{seg['end_time']:.0f} segundos")
            report_lines.append(f"Atención ADHD: {seg['adhd_mean']:.3f} ± {seg['adhd_std']:.3f}")
            report_lines.append(f"Atención Control: {seg['control_mean']:.3f} ± {seg['control_std']:.3f}")
            report_lines.append(f"Diferencia: {seg['difference']:.3f}")
            report_lines.append(f"Cohen's d: {seg['cohens_d']:.3f}")
            report_lines.append(f"AUC: {seg['auc']:.3f}")
            report_lines.append(f"p-value: {seg['p_value']:.6f}")
            
            # Interpretación clínica
            report_lines.append("")
            report_lines.append("INTERPRETACIÓN CLÍNICA:")
            
            if abs(seg['cohens_d']) > 0.8:
                effect = "GRANDE"
            elif abs(seg['cohens_d']) > 0.5:
                effect = "MEDIANO"
            else:
                effect = "PEQUEÑO"
            
            report_lines.append(f"  • Tamaño del efecto: {effect}")
            
            if seg['auc'] > 0.7:
                disc = "BUENA"
            elif seg['auc'] > 0.6:
                disc = "ACEPTABLE"
            else:
                disc = "LIMITADA"
            
            report_lines.append(f"   Capacidad discriminativa: {disc}")
            
            if seg['cohens_d'] < 0:
                report_lines.append(f"   ADHD muestra MENOR atención en este segmento")
            else:
                report_lines.append(f"   ADHD muestra MAYOR atención en este segmento (atípico)")
            
            report_lines.append("")
        
        # Top 5 segmentos discriminativos
        if len(analysis['discriminative_segments']) > 0:
            report_lines.append("TOP 5 SEGMENTOS DISCRIMINATIVOS")
            report_lines.append("-"*80)
            report_lines.append(f"{'Rank':<6} {'Tiempo (s)':<15} {'Cohens d':<12} {'AUC':<10} {'p-value':<12}")
            report_lines.append("-"*80)
            
            for i, (_, row) in enumerate(analysis['discriminative_segments'].head(5).iterrows(), 1):
                report_lines.append(
                    f"{i:<6} "
                    f"{row['start_time']:.0f}-{row['end_time']:.0f}{'':<7} "
                    f"{row['cohens_d']:>10.3f}  "
                    f"{row['auc']:>8.3f}  "
                    f"{row['p_value']:>10.6f}"
                )
            
            report_lines.append("")
        
        # Recomendaciones clínicas
        report_lines.append("RECOMENDACIONES CLÍNICAS")
        report_lines.append("-"*80)
        
        if analysis['n_discriminative'] > 0:
            disc_segs = analysis['discriminative_segments']
            
            # Identificar momento más crítico
            earliest_disc = disc_segs.iloc[0]
            
            report_lines.append("1. VENTANAS DE OBSERVACIÓN PRIORITARIAS:")
            report_lines.append(f"    Enfocarse en el segmento {earliest_disc['start_time']:.0f}-{earliest_disc['end_time']:.0f}s")
            report_lines.append(f"     como ventana diagnóstica crítica")
            report_lines.append("")
            
            report_lines.append("2. PROTOCOLO DE EVALUACIÓN SUGERIDO:")
            report_lines.append(f"    Incluir al menos {analysis['n_discriminative']} ventanas temporales")
            report_lines.append(f"    Monitorear especialmente los primeros {int(earliest_disc['end_time'])} segundos")
            report_lines.append("")
            
            # Calcular si hay patrón temporal
            time_correlation = np.corrcoef(
                disc_segs['start_time'],
                np.abs(disc_segs['cohens_d'])
            )[0, 1]
            
            if abs(time_correlation) > 0.3:
                if time_correlation > 0:
                    pattern = "incrementa con el tiempo (efecto de fatiga)"
                else:
                    pattern = "disminuye con el tiempo (efecto de adaptación)"
                
                report_lines.append("3. PATRÓN TEMPORAL IDENTIFICADO:")
                report_lines.append(f"    La discriminación {pattern}")
                report_lines.append(f"    Correlación: {time_correlation:.3f}")
            
        else:
            report_lines.append("   No se identificaron segmentos significativamente discriminativos")
            report_lines.append("   Considerar análisis con ventanas temporales más amplias")
            report_lines.append("   Revisar calidad de datos y tamaño muestral")
        
        report_lines.append("")
        report_lines.append("="*80)
        report_lines.append("Fin del reporte")
        report_lines.append("="*80)
        
        report = "\n".join(report_lines)
        
        # Guardar si se especifica archivo
        if output_file is None:
            output_file = self.output_dir / 'clinical_report_discriminative_segments.txt'
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"\n    Reporte clínico guardado: {output_file}")
        
        return report


def create_attention_maps_from_profiles(profiles_dir: str,
                                        output_dir: str = './attention_maps',
                                        n_samples: int = 10):
    """
    Crear mapas de atención para perfiles del sistema
    
    Args:
        profiles_dir: Directorio con perfiles integrados
        output_dir: Directorio de salida
        n_samples: Número de mapas a generar
    """
    print("\n" + "="*80)
    print("GENERACIÓN DE MAPAS DE ATENCIÓN TEMPORAL")
    print("="*80)
    
    mapper = TemporalAttentionMapper(output_dir=output_dir)
    
    # Implementación específica dependiendo de estructura de datos
    print(f"\n   Directorio de perfiles: {profiles_dir}")
    print(f"   Salida: {output_dir}")
    print(f"   Muestras: {n_samples}")
    
    return mapper


if __name__ == "__main__":
    print("Módulo de Mapas de Atención Temporal")
    print("Uso: Importar y usar con datos de secuencias temporales")
