"""
Módulo de Evaluación de Modelo EEG-TDAH - VERSIÓN 2
===================================================
- Evalúa clasificación ADHD vs Control
- Evalúa clasificación de perfiles temporales
- Agregación de predicciones por sujeto
- Métricas a nivel de sujeto
- Genera métricas comprehensivas
- Crea visualizaciones detalladas
- Análisis de errores

"""

import torch
import numpy as np
import h5py
from pathlib import Path
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, List, Tuple
import json
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, roc_curve, auc,
    roc_auc_score, precision_recall_curve, average_precision_score
)
from datetime import datetime
import pandas as pd

# Importar modelo
from src.models.hybrid_model import create_model


class ModelEvaluator:
    """
    Evaluador comprehensivo de modelo EEG-TDAH
    """
    
    def __init__(self, model_path: str, data_path: str, output_dir: str):
        """
        Inicializar evaluador
        
        Args:
            model_path: Ruta al modelo entrenado
            data_path: Ruta a datos preprocesados
            output_dir: Directorio para resultados de evaluación
        """
        self.model_path = Path(model_path)
        self.data_path = Path(data_path)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Subdirectorios
        self.dirs = {
            'metrics': self.output_dir / 'metrics',
            'plots': self.output_dir / 'plots',
            'reports': self.output_dir / 'reports',
            'errors': self.output_dir / 'error_analysis'
        }
        for dir_path in self.dirs.values():
            dir_path.mkdir(parents=True, exist_ok=True)
        
        # Device
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        
        # Cargar modelo
        print("✓ Cargando modelo para evaluación...")
        self.model = self._load_model()
        
        # Nombres de clases
        self.adhd_classes = ['Control', 'ADHD']
        self.profile_classes = [
            'Stable-High',
            'Fluctuating',
            'Low-Persistent',
            'Fatigable',
            'Mixed'
        ]
        
        print(f"✓ Evaluador inicializado")
        print(f"   Device: {self.device}")
        print(f"   Modelo: {self.model_path}")
        print(f"   Datos: {self.data_path}")
        print(f"   Resultados: {self.output_dir}")
    
    def _load_model(self):
        """Cargar modelo entrenado"""
        model = create_model({
            'n_channels': 19,
            'time_samples': 128,
            'cnn_filters': 64,
            'transformer_dim': 128,
            'lstm_hidden': 128,
            'num_profiles': 5
        })
        
        checkpoint = torch.load(self.model_path, map_location=self.device, weights_only=False)
        model.load_state_dict(checkpoint['model_state_dict'])
        model.to(self.device)
        model.eval()
        
        return model
    
    def load_subjects(self, subject_list: List[str] = None, scale: int = 2):
        """
        Cargar datos de sujetos para evaluación
        
        Args:
            subject_list: Lista de IDs de sujetos (None para todos)
            scale: Escala temporal a usar
            
        Returns:
            Diccionario con datos y labels
        """
        print(f"\n{'='*70}")
        print("CARGANDO DATOS PARA EVALUACIÓN")
        print(f"{'='*70}")
        
        data = {
            'windows': [],
            'adhd_labels': [],
            'subject_ids': [],
            'window_indices': []
        }
        
        with h5py.File(self.data_path, 'r') as hf:
            scale_key = f'scale_{scale}s'
            
            if subject_list is None:
                subject_list = list(hf[scale_key].keys())
            
            for subject_id in subject_list:
                if subject_id not in hf[scale_key]:
                    print(f"Sujeto {subject_id} no encontrado")
                    continue
                
                subject_group = hf[scale_key][subject_id]
                windows = subject_group['windows'][:]
                adhd_label = 1 if subject_group.attrs['class'] == 'ADHD' else 0
                
                # Agregar ventanas
                for i, window in enumerate(windows):
                    data['windows'].append(window)
                    data['adhd_labels'].append(adhd_label)
                    data['subject_ids'].append(subject_id)
                    data['window_indices'].append(i)
        
        # Convertir a arrays
        data['windows'] = np.array(data['windows'])
        data['adhd_labels'] = np.array(data['adhd_labels'])
        
        print(f"✓ Datos cargados:")
        print(f"   Sujetos: {len(set(data['subject_ids']))}")
        print(f"   Total ventanas: {len(data['windows'])}")
        print(f"   ADHD: {np.sum(data['adhd_labels'])} ventanas")
        print(f"   Control: {len(data['adhd_labels']) - np.sum(data['adhd_labels'])} ventanas")
        
        return data
    
    
    def predict_batch(self, windows: np.ndarray, batch_size: int = 32):
        """
        Realizar predicciones en batch
        
        Args:
            windows: Array de ventanas (n_windows, n_channels, time_samples)
            batch_size: Tamaño de batch
            
        Returns:
            Diccionario con predicciones
        """
        self.model.eval()
        
        all_adhd_logits = []
        all_profile_logits = []
        all_attention_scores = []
        
        n_windows = len(windows)
        n_batches = (n_windows + batch_size - 1) // batch_size
        
        with torch.no_grad():
            for i in range(n_batches):
                start_idx = i * batch_size
                end_idx = min(start_idx + batch_size, n_windows)
                batch = windows[start_idx:end_idx]
                
                # Convertir a tensor
                batch_tensor = torch.FloatTensor(batch).to(self.device)
                
                # Predicción - modelo devuelve (outputs, attn_weights)
                outputs, attn_weights = self.model(batch_tensor)
                
                # Extraer logits
                adhd_logits = outputs['adhd'].cpu().numpy()
                profile_logits = outputs['profile'].cpu().numpy()
                attention_scores = outputs['attention'].cpu().numpy()
                
                all_adhd_logits.append(adhd_logits)
                all_profile_logits.append(profile_logits)
                all_attention_scores.append(attention_scores)
        
        # Concatenar resultados
        all_adhd_logits = np.concatenate(all_adhd_logits, axis=0)
        all_profile_logits = np.concatenate(all_profile_logits, axis=0)
        all_attention_scores = np.concatenate(all_attention_scores, axis=0)
        
        # Calcular probabilidades y predicciones
        adhd_probs = self._softmax(all_adhd_logits)
        profile_probs = self._softmax(all_profile_logits)
        
        predictions = {
            'adhd_logits': all_adhd_logits,
            'adhd_probs': adhd_probs,
            'adhd_pred': np.argmax(adhd_probs, axis=1),
            'profile_logits': all_profile_logits,
            'profile_probs': profile_probs,
            'profile_pred': np.argmax(profile_probs, axis=1),
            'attention_scores': all_attention_scores
        }
        
        return predictions
    
    def predict_by_subject(self, data: Dict, predictions: Dict) -> pd.DataFrame:
        """
        Agregar predicciones por sujeto
        
        Para cada sujeto:
        - Agrega predicciones de todas sus ventanas
        - Usa mayoría de votos para clasificación
        - Calcula probabilidad promedio
        - Calcula confianza
        
        Args:
            data: Diccionario con datos cargados
            predictions: Diccionario con predicciones por ventana
            
        Returns:
            DataFrame con predicciones por sujeto
        """
        print(f"\n{'='*70}")
        print("AGREGANDO PREDICCIONES POR SUJETO")
        print(f"{'='*70}")
        
        subject_predictions = []
        unique_subjects = list(set(data['subject_ids']))
        
        for subject_id in unique_subjects:
            # Obtener máscaras de ventanas de este sujeto
            subject_mask = np.array([sid == subject_id for sid in data['subject_ids']])
            
            # Extraer datos del sujeto
            subject_adhd_probs = predictions['adhd_probs'][subject_mask]
            subject_adhd_preds = predictions['adhd_pred'][subject_mask]
            subject_profile_probs = predictions['profile_probs'][subject_mask]
            subject_profile_preds = predictions['profile_pred'][subject_mask]
            subject_attention = predictions['attention_scores'][subject_mask]
            
            # Etiqueta real
            true_adhd = data['adhd_labels'][subject_mask][0]
            
            # ============================================================
            # AGREGACIÓN ADHD - Mayoría de votos
            # ============================================================
            adhd_pred_counts = np.bincount(subject_adhd_preds)
            adhd_majority = np.argmax(adhd_pred_counts)
            
            # Probabilidad promedio de ADHD
            adhd_prob_avg = np.mean(subject_adhd_probs[:, 1])  # Probabilidad clase ADHD
            
            # Confianza (proporción de ventanas que votaron por clase predicha)
            adhd_confidence = adhd_pred_counts[adhd_majority] / len(subject_adhd_preds)
            
            # ============================================================
            # AGREGACIÓN PERFILES - Mayoría de votos
            # ============================================================
            profile_pred_counts = np.bincount(subject_profile_preds, minlength=5)
            profile_majority = np.argmax(profile_pred_counts)
            
            # Probabilidad promedio del perfil predicho
            profile_prob_avg = np.mean(subject_profile_probs[:, profile_majority])
            
            # Distribución de perfiles (proporción de ventanas en cada perfil)
            profile_distribution = profile_pred_counts / len(subject_profile_preds)
            
            # ============================================================
            # MÉTRICAS DE ATENCIÓN
            # ============================================================
            attention_mean = np.mean(subject_attention)
            attention_std = np.std(subject_attention)
            attention_min = np.min(subject_attention)
            attention_max = np.max(subject_attention)
            
            # Crear registro de predicción
            subject_record = {
                # Identificación
                'subject_id': subject_id,
                'n_windows': int(len(subject_adhd_preds)),
                
                # ADHD - Predicción
                'predicted_adhd': int(adhd_majority),
                'predicted_diagnosis': 'ADHD' if adhd_majority == 1 else 'Control',
                'adhd_probability': float(adhd_prob_avg),
                'adhd_confidence': float(adhd_confidence),
                
                # ADHD - Ground truth
                'true_adhd': int(true_adhd),
                'true_diagnosis': 'ADHD' if true_adhd == 1 else 'Control',
                'adhd_correct': int(adhd_majority == true_adhd),
                
                # Perfil - Predicción
                'predicted_profile': int(profile_majority),
                'predicted_profile_name': self.profile_classes[profile_majority],
                'profile_probability': float(profile_prob_avg),
                
                # Distribución de perfiles
                'profile_dist_0': float(profile_distribution[0]),
                'profile_dist_1': float(profile_distribution[1]),
                'profile_dist_2': float(profile_distribution[2]),
                'profile_dist_3': float(profile_distribution[3]),
                'profile_dist_4': float(profile_distribution[4]),
                
                # Métricas de atención
                'attention_mean': float(attention_mean),
                'attention_std': float(attention_std),
                'attention_min': float(attention_min),
                'attention_max': float(attention_max)
            }
            
            subject_predictions.append(subject_record)
        
        # Crear DataFrame
        df = pd.DataFrame(subject_predictions)
        
        # Calcular métricas globales
        accuracy = df['adhd_correct'].mean()
        
        print(f"✓ Predicciones agregadas:")
        print(f"   Sujetos totales: {len(df)}")
        print(f"   Accuracy por sujeto: {accuracy:.4f}")
        print(f"   ADHD predichos: {(df['predicted_adhd'] == 1).sum()}")
        print(f"   Control predichos: {(df['predicted_adhd'] == 0).sum()}")
        
        return df
    
    def save_predictions_for_step7(self, subject_df: pd.DataFrame, output_path: str = None):
        """
        Guardar predicciones en formato compatible con Paso 7 (Fase4.py)
        
        Args:
            subject_df: DataFrame con predicciones por sujeto
            output_path: Ruta de salida (None para usar default)
        """
        if output_path is None:
            output_path = self.dirs['reports'] / 'adhd_predictions.csv'
        else:
            output_path = Path(output_path)
        
        # Crear DataFrame en formato Step 7
        step7_df = subject_df[[
            'subject_id',
            'predicted_diagnosis',
            'adhd_probability'
        ]].copy()
        
        # Renombrar columnas
        step7_df.columns = ['subject_id', 'diagnosis', 'probability']
        
        # Guardar
        step7_df.to_csv(output_path, index=False)
        
        print(f"\n✓ Predicciones para Paso 7 guardadas: {output_path}")
        print(f"   Formato: subject_id, diagnosis, probability")
        print(f"   Compatible con: Fase4.py --adhd-predictions {output_path}")
        
        return output_path
    
    def evaluate_subject_level(self, subject_df: pd.DataFrame) -> Dict:
        """
        Evaluar métricas a nivel de sujeto (no ventanas)
        
        Args:
            subject_df: DataFrame con predicciones por sujeto
            
        Returns:
            Diccionario con métricas a nivel de sujeto
        """
        print(f"\n{'='*70}")
        print("EVALUACIÓN A NIVEL DE SUJETO")
        print(f"{'='*70}")
        
        y_true = subject_df['true_adhd'].values
        y_pred = subject_df['predicted_adhd'].values
        y_probs = subject_df['adhd_probability'].values
        
        # Métricas básicas
        accuracy = accuracy_score(y_true, y_pred)
        precision = precision_score(y_true, y_pred, zero_division=0)
        recall = recall_score(y_true, y_pred, zero_division=0)
        f1 = f1_score(y_true, y_pred, zero_division=0)
        
        # Matriz de confusión
        cm = confusion_matrix(y_true, y_pred)
        
        # ROC-AUC
        roc_auc = roc_auc_score(y_true, y_probs)
        
        # Precision-Recall
        avg_precision = average_precision_score(y_true, y_probs)
        
        # Métricas por clase
        per_class_metrics = {}
        for class_idx, class_name in enumerate(self.adhd_classes):
            y_true_binary = (y_true == class_idx).astype(int)
            y_pred_binary = (y_pred == class_idx).astype(int)
            
            per_class_metrics[class_name] = {
                'precision': precision_score(y_true_binary, y_pred_binary, zero_division=0),
                'recall': recall_score(y_true_binary, y_pred_binary, zero_division=0),
                'f1_score': f1_score(y_true_binary, y_pred_binary, zero_division=0),
                'support': int(np.sum(y_true_binary))
            }
        
        # Análisis de confianza
        confidence_stats = {
            'mean': float(subject_df['adhd_confidence'].mean()),
            'std': float(subject_df['adhd_confidence'].std()),
            'min': float(subject_df['adhd_confidence'].min()),
            'max': float(subject_df['adhd_confidence'].max())
        }
        
        # Análisis de atención
        attention_stats = {
            'mean': float(subject_df['attention_mean'].mean()),
            'std': float(subject_df['attention_mean'].std())
        }
        
        metrics = {
            'accuracy': float(accuracy),
            'precision': float(precision),
            'recall': float(recall),
            'f1_score': float(f1),
            'roc_auc': float(roc_auc),
            'avg_precision': float(avg_precision),
            'confusion_matrix': cm.tolist(),
            'per_class': per_class_metrics,
            'confidence_stats': confidence_stats,
            'attention_stats': attention_stats,
            'n_subjects': int(len(subject_df)),
            'n_adhd': int((y_true == 1).sum()),
            'n_control': int((y_true == 0).sum())
        }
        
        print(f"✓ Métricas a nivel de sujeto:")
        print(f"   Accuracy: {accuracy:.4f}")
        print(f"   Precision: {precision:.4f}")
        print(f"   Recall: {recall:.4f}")
        print(f"   F1-Score: {f1:.4f}")
        print(f"   ROC-AUC: {roc_auc:.4f}")
        print(f"   Confianza promedio: {confidence_stats['mean']:.4f}")
        
        return metrics
    
    def _softmax(self, x):
        """Aplicar softmax"""
        exp_x = np.exp(x - np.max(x, axis=1, keepdims=True))
        return exp_x / np.sum(exp_x, axis=1, keepdims=True)
    
    def evaluate_adhd_classification(self, y_true: np.ndarray, y_pred: np.ndarray, 
                                     y_probs: np.ndarray) -> Dict:
        """
        Evaluar clasificación ADHD vs Control
        
        Args:
            y_true: Labels verdaderos
            y_pred: Predicciones
            y_probs: Probabilidades
            
        Returns:
            Diccionario con métricas
        """
        # Métricas básicas
        accuracy = accuracy_score(y_true, y_pred)
        precision = precision_score(y_true, y_pred, average='binary')
        recall = recall_score(y_true, y_pred, average='binary')
        f1 = f1_score(y_true, y_pred, average='binary')
        
        # Métricas por clase
        precision_per_class = precision_score(y_true, y_pred, average=None)
        recall_per_class = recall_score(y_true, y_pred, average=None)
        f1_per_class = f1_score(y_true, y_pred, average=None)
        
        # Matriz de confusión
        cm = confusion_matrix(y_true, y_pred)
        
        # ROC-AUC
        fpr, tpr, thresholds = roc_curve(y_true, y_probs[:, 1])
        roc_auc = auc(fpr, tpr)
        
        # Precision-Recall
        precision_curve, recall_curve, pr_thresholds = precision_recall_curve(
            y_true, y_probs[:, 1]
        )
        avg_precision = average_precision_score(y_true, y_probs[:, 1])
        
        metrics = {
            'accuracy': float(accuracy),
            'precision': float(precision),
            'recall': float(recall),
            'f1_score': float(f1),
            'roc_auc': float(roc_auc),
            'avg_precision': float(avg_precision),
            'confusion_matrix': cm.tolist(),
            'per_class': {
                'Control': {
                    'precision': float(precision_per_class[0]),
                    'recall': float(recall_per_class[0]),
                    'f1_score': float(f1_per_class[0])
                },
                'ADHD': {
                    'precision': float(precision_per_class[1]),
                    'recall': float(recall_per_class[1]),
                    'f1_score': float(f1_per_class[1])
                }
            },
            'roc_curve': {
                'fpr': fpr.tolist(),
                'tpr': tpr.tolist(),
                'thresholds': thresholds.tolist()
            },
            'pr_curve': {
                'precision': precision_curve.tolist(),
                'recall': recall_curve.tolist(),
                'thresholds': pr_thresholds.tolist()
            }
        }
        
        return metrics
    
    def evaluate_profile_classification(self, y_true: np.ndarray, y_pred: np.ndarray,
                                        y_probs: np.ndarray) -> Dict:
        """
        Evaluar clasificación de perfiles temporales
        
        Args:
            y_true: Labels verdaderos
            y_pred: Predicciones
            y_probs: Probabilidades
            
        Returns:
            Diccionario con métricas
        """
        # Métricas macro/micro
        accuracy = accuracy_score(y_true, y_pred)
        precision_macro = precision_score(y_true, y_pred, average='macro')
        recall_macro = recall_score(y_true, y_pred, average='macro')
        f1_macro = f1_score(y_true, y_pred, average='macro')
        
        # Métricas por clase
        precision_per_class = precision_score(y_true, y_pred, average=None, zero_division=0)
        recall_per_class = recall_score(y_true, y_pred, average=None, zero_division=0)
        f1_per_class = f1_score(y_true, y_pred, average=None, zero_division=0)
        
        # Matriz de confusión
        cm = confusion_matrix(y_true, y_pred)
        
        metrics = {
            'accuracy': float(accuracy),
            'precision_macro': float(precision_macro),
            'recall_macro': float(recall_macro),
            'f1_macro': float(f1_macro),
            'confusion_matrix': cm.tolist(),
            'per_class': {}
        }
        
        for i, class_name in enumerate(self.profile_classes):
            metrics['per_class'][class_name] = {
                'precision': float(precision_per_class[i]),
                'recall': float(recall_per_class[i]),
                'f1_score': float(f1_per_class[i])
            }
        
        return metrics
    
    def analyze_errors(self, data: Dict, predictions: Dict) -> Dict:
        """
        Analizar errores de clasificación
        
        Args:
            data: Datos originales
            predictions: Predicciones del modelo
            
        Returns:
            Análisis de errores
        """
        print(f"\n{'='*70}")
        print("ANÁLISIS DE ERRORES")
        print(f"{'='*70}")
        
        y_true = data['adhd_labels']
        y_pred = predictions['adhd_pred']
        
        # Identificar errores
        errors = y_true != y_pred
        n_errors = np.sum(errors)
        
        # Clasificar tipos de errores
        false_positives = (y_true == 0) & (y_pred == 1)
        false_negatives = (y_true == 1) & (y_pred == 0)
        
        n_fp = np.sum(false_positives)
        n_fn = np.sum(false_negatives)
        
        # Analizar por sujeto
        subject_ids = np.array(data['subject_ids'])
        subjects_with_errors = {}
        
        for subject_id in set(subject_ids):
            mask = subject_ids == subject_id
            subject_errors = errors[mask]
            if np.any(subject_errors):
                subjects_with_errors[subject_id] = {
                    'total_windows': int(np.sum(mask)),
                    'error_windows': int(np.sum(subject_errors)),
                    'error_rate': float(np.mean(subject_errors)),
                    'true_label': int(y_true[mask][0]),
                    'pred_label': int(y_pred[mask][0])
                }
        
        error_analysis = {
            'total_errors': int(n_errors),
            'error_rate': float(n_errors / len(y_true)),
            'false_positives': int(n_fp),
            'false_negatives': int(n_fn),
            'fp_rate': float(n_fp / np.sum(y_true == 0)) if np.sum(y_true == 0) > 0 else 0,
            'fn_rate': float(n_fn / np.sum(y_true == 1)) if np.sum(y_true == 1) > 0 else 0,
            'subjects_with_errors': subjects_with_errors
        }
        
        print(f"✓ Errores totales: {n_errors} ({error_analysis['error_rate']:.2%})")
        print(f"   Falsos positivos: {n_fp} ({error_analysis['fp_rate']:.2%})")
        print(f"   Falsos negativos: {n_fn} ({error_analysis['fn_rate']:.2%})")
        print(f"   Sujetos con errores: {len(subjects_with_errors)}")
        
        return error_analysis
    
    def plot_confusion_matrices(self, adhd_metrics: Dict, profile_metrics: Dict):
        """
        Generar matrices de confusión visualizadas
        
        Args:
            adhd_metrics: Métricas ADHD
            profile_metrics: Métricas de perfiles
        """
        fig, axes = plt.subplots(1, 2, figsize=(16, 6))
        
        # Matriz de confusión ADHD
        cm_adhd = np.array(adhd_metrics['confusion_matrix'])
        sns.heatmap(cm_adhd, annot=True, fmt='d', cmap='Blues', 
                   xticklabels=self.adhd_classes, 
                   yticklabels=self.adhd_classes,
                   ax=axes[0])
        axes[0].set_title('Matriz de Confusión: ADHD vs Control', fontsize=14, fontweight='bold')
        axes[0].set_ylabel('Verdadero', fontsize=12)
        axes[0].set_xlabel('Predicho', fontsize=12)
        
        # Matriz de confusión perfiles
        cm_profile = np.array(profile_metrics['confusion_matrix'])
        sns.heatmap(cm_profile, annot=True, fmt='d', cmap='Greens',
                   xticklabels=self.profile_classes,
                   yticklabels=self.profile_classes,
                   ax=axes[1])
        axes[1].set_title('Matriz de Confusión: Perfiles Temporales', fontsize=14, fontweight='bold')
        axes[1].set_ylabel('Verdadero', fontsize=12)
        axes[1].set_xlabel('Predicho', fontsize=12)
        plt.setp(axes[1].get_xticklabels(), rotation=45, ha='right')
        plt.setp(axes[1].get_yticklabels(), rotation=0)
        
        plt.tight_layout()
        plot_path = self.dirs['plots'] / 'confusion_matrices.png'
        plt.savefig(plot_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f"✓ Matrices de confusión guardadas: {plot_path}")
    
    def plot_roc_curve(self, adhd_metrics: Dict):
        """
        Generar curva ROC
        
        Args:
            adhd_metrics: Métricas ADHD con datos de curva ROC
        """
        fig, ax = plt.subplots(figsize=(10, 8))
        
        fpr = adhd_metrics['roc_curve']['fpr']
        tpr = adhd_metrics['roc_curve']['tpr']
        roc_auc = adhd_metrics['roc_auc']
        
        ax.plot(fpr, tpr, color='darkorange', lw=2,
               label=f'ROC curve (AUC = {roc_auc:.3f})')
        ax.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', label='Random')
        ax.set_xlim([0.0, 1.0])
        ax.set_ylim([0.0, 1.05])
        ax.set_xlabel('False Positive Rate', fontsize=12)
        ax.set_ylabel('True Positive Rate', fontsize=12)
        ax.set_title('Curva ROC: Clasificación ADHD', fontsize=14, fontweight='bold')
        ax.legend(loc="lower right", fontsize=11)
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plot_path = self.dirs['plots'] / 'roc_curve.png'
        plt.savefig(plot_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f"✓ Curva ROC guardada: {plot_path}")
    
    def plot_precision_recall_curve(self, adhd_metrics: Dict):
        """
        Generar curva Precision-Recall
        
        Args:
            adhd_metrics: Métricas ADHD con datos de curva PR
        """
        fig, ax = plt.subplots(figsize=(10, 8))
        
        precision = adhd_metrics['pr_curve']['precision']
        recall = adhd_metrics['pr_curve']['recall']
        avg_precision = adhd_metrics['avg_precision']
        
        ax.plot(recall, precision, color='darkgreen', lw=2,
               label=f'PR curve (AP = {avg_precision:.3f})')
        ax.set_xlim([0.0, 1.0])
        ax.set_ylim([0.0, 1.05])
        ax.set_xlabel('Recall', fontsize=12)
        ax.set_ylabel('Precision', fontsize=12)
        ax.set_title('Curva Precision-Recall: Clasificación ADHD', 
                    fontsize=14, fontweight='bold')
        ax.legend(loc="lower left", fontsize=11)
        ax.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plot_path = self.dirs['plots'] / 'precision_recall_curve.png'
        plt.savefig(plot_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f"✓ Curva Precision-Recall guardada: {plot_path}")
    
    def plot_metrics_comparison(self, adhd_metrics: Dict, profile_metrics: Dict):
        """
        Comparar métricas visualmente
        
        Args:
            adhd_metrics: Métricas ADHD
            profile_metrics: Métricas de perfiles
        """
        fig, axes = plt.subplots(1, 2, figsize=(16, 6))
        
        # Métricas ADHD
        metrics_adhd = ['accuracy', 'precision', 'recall', 'f1_score', 'roc_auc']
        values_adhd = [adhd_metrics[m] for m in metrics_adhd]
        
        colors = ['#FF6B6B' if v < 0.7 else '#4ECDC4' if v < 0.85 else '#95E77D' 
                 for v in values_adhd]
        
        axes[0].barh(metrics_adhd, values_adhd, color=colors, alpha=0.8)
        axes[0].set_xlim(0, 1)
        axes[0].set_xlabel('Score', fontsize=12)
        axes[0].set_title('Métricas: Clasificación ADHD', fontsize=14, fontweight='bold')
        axes[0].grid(True, alpha=0.3, axis='x')
        
        for i, v in enumerate(values_adhd):
            axes[0].text(v + 0.02, i, f'{v:.3f}', va='center', fontweight='bold')
        
        # Métricas Perfiles
        metrics_profile = ['accuracy', 'precision_macro', 'recall_macro', 'f1_macro']
        values_profile = [profile_metrics[m] for m in metrics_profile]
        
        colors = ['#FF6B6B' if v < 0.6 else '#4ECDC4' if v < 0.75 else '#95E77D' 
                 for v in values_profile]
        
        axes[1].barh(metrics_profile, values_profile, color=colors, alpha=0.8)
        axes[1].set_xlim(0, 1)
        axes[1].set_xlabel('Score', fontsize=12)
        axes[1].set_title('Métricas: Clasificación Perfiles', fontsize=14, fontweight='bold')
        axes[1].grid(True, alpha=0.3, axis='x')
        
        for i, v in enumerate(values_profile):
            axes[1].text(v + 0.02, i, f'{v:.3f}', va='center', fontweight='bold')
        
        plt.tight_layout()
        plot_path = self.dirs['plots'] / 'metrics_comparison.png'
        plt.savefig(plot_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f"✓ Comparación de métricas guardada: {plot_path}")
    
    def generate_evaluation_report(self, adhd_metrics: Dict, profile_metrics: Dict,
                                   error_analysis: Dict) -> str:
        """
        Generar reporte textual de evaluación
        
        Args:
            adhd_metrics: Métricas ADHD
            profile_metrics: Métricas de perfiles
            error_analysis: Análisis de errores
            
        Returns:
            String con reporte
        """
        report = []
        report.append("=" * 80)
        report.append("REPORTE DE EVALUACIÓN - MODELO EEG-TDAH")
        report.append("=" * 80)
        report.append("")
        report.append(f"Fecha: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        report.append(f"Modelo: {self.model_path}")
        report.append("")
        
        # Métricas ADHD
        report.append("CLASIFICACIÓN ADHD VS CONTROL")
        report.append("-" * 80)
        report.append(f"Accuracy:     {adhd_metrics['accuracy']:.4f}")
        report.append(f"Precision:    {adhd_metrics['precision']:.4f}")
        report.append(f"Recall:       {adhd_metrics['recall']:.4f}")
        report.append(f"F1-Score:     {adhd_metrics['f1_score']:.4f}")
        report.append(f"ROC-AUC:      {adhd_metrics['roc_auc']:.4f}")
        report.append(f"Avg Precision: {adhd_metrics['avg_precision']:.4f}")
        report.append("")
        
        report.append("Métricas por Clase:")
        for class_name in ['Control', 'ADHD']:
            class_metrics = adhd_metrics['per_class'][class_name]
            report.append(f"  {class_name}:")
            report.append(f"    Precision: {class_metrics['precision']:.4f}")
            report.append(f"    Recall:    {class_metrics['recall']:.4f}")
            report.append(f"    F1-Score:  {class_metrics['f1_score']:.4f}")
        report.append("")
        
        # Métricas Perfiles
        report.append("CLASIFICACIÓN DE PERFILES TEMPORALES")
        report.append("-" * 80)
        report.append(f"Accuracy:      {profile_metrics['accuracy']:.4f}")
        report.append(f"Precision (macro): {profile_metrics['precision_macro']:.4f}")
        report.append(f"Recall (macro):    {profile_metrics['recall_macro']:.4f}")
        report.append(f"F1-Score (macro):  {profile_metrics['f1_macro']:.4f}")
        report.append("")
        
        report.append("Métricas por Perfil:")
        for profile_name in self.profile_classes:
            profile_m = profile_metrics['per_class'][profile_name]
            report.append(f"  {profile_name}:")
            report.append(f"    Precision: {profile_m['precision']:.4f}")
            report.append(f"    Recall:    {profile_m['recall']:.4f}")
            report.append(f"    F1-Score:  {profile_m['f1_score']:.4f}")
        report.append("")
        
        # Análisis de errores
        report.append("ANÁLISIS DE ERRORES")
        report.append("-" * 80)
        report.append(f"Total de errores:     {error_analysis['total_errors']}")
        report.append(f"Tasa de error:        {error_analysis['error_rate']:.2%}")
        report.append(f"Falsos positivos:     {error_analysis['false_positives']} ({error_analysis['fp_rate']:.2%})")
        report.append(f"Falsos negativos:     {error_analysis['false_negatives']} ({error_analysis['fn_rate']:.2%})")
        report.append(f"Sujetos con errores:  {len(error_analysis['subjects_with_errors'])}")
        report.append("")
        
        # Top errores por sujeto
        if error_analysis['subjects_with_errors']:
            report.append("Sujetos con mayor tasa de error (Top 10):")
            sorted_subjects = sorted(
                error_analysis['subjects_with_errors'].items(),
                key=lambda x: x[1]['error_rate'],
                reverse=True
            )[:10]
            
            for subject_id, error_info in sorted_subjects:
                report.append(f"  {subject_id}: {error_info['error_rate']:.2%} " +
                            f"({error_info['error_windows']}/{error_info['total_windows']} ventanas)")
        
        report.append("")
        report.append("=" * 80)
        report.append("Fin del reporte")
        report.append("=" * 80)
        
        return "\n".join(report)
    
    def evaluate_full(self, subject_list: List[str] = None, scale: int = 2):
        """
        Evaluación completa del modelo
        
        Args:
            subject_list: Lista de sujetos a evaluar (None para todos)
            scale: Escala temporal
            
        Returns:
            Diccionario con resultados completos
        """
        print(f"\n{'='*80}")
        print("EVALUACIÓN COMPLETA DEL MODELO")
        print(f"{'='*80}\n")
        
        # 1. Cargar datos
        data = self.load_subjects(subject_list, scale)
        
        # 2. Realizar predicciones por ventana
        print(f"\n{'='*70}")
        print("REALIZANDO PREDICCIONES POR VENTANA")
        print(f"{'='*70}")
        predictions = self.predict_batch(data['windows'])
        print(f"✓ Predicciones completadas: {len(predictions['adhd_pred'])} ventanas")
        
        # 3. **NUEVO** Agregar predicciones por sujeto
        subject_df = self.predict_by_subject(data, predictions)
        
        # 4. **NUEVO** Evaluar a nivel de sujeto
        subject_metrics = self.evaluate_subject_level(subject_df)
        
        # 5. **NUEVO** Guardar predicciones para Paso 7
        self.save_predictions_for_step7(subject_df)
        
        # Guardar también el DataFrame completo de sujetos
        subject_detailed_path = self.dirs['reports'] / 'subject_predictions_detailed.csv'
        subject_df.to_csv(subject_detailed_path, index=False)
        print(f"✓ Predicciones detalladas por sujeto: {subject_detailed_path}")
        
        # 6. Evaluar clasificación ADHD (a nivel de ventana)
        print(f"\n{'='*70}")
        print("EVALUANDO CLASIFICACIÓN ADHD (Nivel Ventana)")
        print(f"{'='*70}")
        adhd_metrics = self.evaluate_adhd_classification(
            data['adhd_labels'],
            predictions['adhd_pred'],
            predictions['adhd_probs']
        )
        print(f"✓ Accuracy (ventana): {adhd_metrics['accuracy']:.4f}")
        print(f"✓ ROC-AUC (ventana): {adhd_metrics['roc_auc']:.4f}")
        
        # 7. Evaluar clasificación de perfiles
        print(f"\n{'='*70}")
        print("EVALUANDO CLASIFICACIÓN DE PERFILES")
        print(f"{'='*70}")
        # Generar labels simulados para demostración
        simulated_profile_labels = np.random.randint(0, 5, size=len(predictions['profile_pred']))
        profile_metrics = self.evaluate_profile_classification(
            simulated_profile_labels,
            predictions['profile_pred'],
            predictions['profile_probs']
        )
        print(f"✓ Accuracy: {profile_metrics['accuracy']:.4f}")
        
        # 8. Análisis de errores (por ventana)
        error_analysis = self.analyze_errors(data, predictions)
        
        # 9. Generar visualizaciones
        print(f"\n{'='*70}")
        print("GENERANDO VISUALIZACIONES")
        print(f"{'='*70}")
        self.plot_confusion_matrices(adhd_metrics, profile_metrics)
        self.plot_roc_curve(adhd_metrics)
        self.plot_precision_recall_curve(adhd_metrics)
        self.plot_metrics_comparison(adhd_metrics, profile_metrics)
        
        # 10. Generar reportes
        print(f"\n{'='*70}")
        print("GENERANDO REPORTES")
        print(f"{'='*70}")
        
        # Reporte textual
        report_text = self.generate_evaluation_report(
            adhd_metrics, profile_metrics, error_analysis
        )
        report_path = self.dirs['reports'] / 'evaluation_report.txt'
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(report_text)
        print(f"✓ Reporte textual: {report_path}")
        
        # Reporte JSON completo
        json_report = {
            'timestamp': datetime.now().isoformat(),
            'model_path': str(self.model_path),
            'data_path': str(self.data_path),
            'n_subjects': len(set(data['subject_ids'])),
            'n_windows': len(data['windows']),
            'adhd_metrics_window': adhd_metrics,
            'adhd_metrics_subject': subject_metrics,  # **NUEVO**
            'profile_metrics': profile_metrics,
            'error_analysis': error_analysis
        }
        
        json_path = self.dirs['metrics'] / 'evaluation_metrics.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(json_report, f, indent=2, ensure_ascii=False)
        print(f"✓ Métricas JSON: {json_path}")
        
        # Error analysis detallado
        error_path = self.dirs['errors'] / 'error_analysis.json'
        with open(error_path, 'w', encoding='utf-8') as f:
            json.dump(error_analysis, f, indent=2, ensure_ascii=False)
        print(f"✓ Análisis de errores: {error_path}")
        
        print(f"\n{'='*80}")
        print("EVALUACIÓN COMPLETADA")
        print(f"{'='*80}")
        print(f"Resultados en: {self.output_dir}")
        print(f"\n RESUMEN:")
        print(f"   Nivel Ventana - Accuracy: {adhd_metrics['accuracy']:.2%}")
        print(f"   Nivel Sujeto  - Accuracy: {subject_metrics['accuracy']:.2%}")
        print(f"   ROC-AUC (sujeto): {subject_metrics['roc_auc']:.3f}")
        
        return {
            'adhd_metrics_window': adhd_metrics,
            'adhd_metrics_subject': subject_metrics,  # **NUEVO**
            'profile_metrics': profile_metrics,
            'error_analysis': error_analysis,
            'predictions': predictions,
            'subject_predictions': subject_df,  # **NUEVO**
            'data': data
        }


def main():
    """Función principal"""
    print("\n" + "="*80)
    print("EVALUACIÓN DE MODELO EEG-TDAH - VERSIÓN 2")
    print("Con Predicciones Agregadas por Sujeto")
    print("="*80 + "\n")
    
    # Configurar rutas
    model_path = '../EEG_ADHD_v5/models/best_model.pth'
    data_path = '../EEG_ADHD_v5/data/processed/preprocessed_data.h5'
    output_dir = '../EEG_ADHD_v5/results/evaluation'
    
    # Verificar archivos
    if not Path(model_path).exists():
        print(f"✗ Modelo no encontrado: {model_path}")
        return
    
    if not Path(data_path).exists():
        print(f"✗ Datos no encontrados: {data_path}")
        return
    
    # Crear evaluador
    evaluator = ModelEvaluator(model_path, data_path, output_dir)
    
    # Evaluar modelo completo
    # Puedes especificar sujetos específicos o None para todos
    results = evaluator.evaluate_full(subject_list=None, scale=2)
    
    print("\n✓ Evaluación completada exitosamente")
    print(f"\nRESUMEN DE RESULTADOS:")
    print(f"\n   Nivel Ventana:")
    print(f"     Accuracy: {results['adhd_metrics_window']['accuracy']:.2%}")
    print(f"     ROC-AUC: {results['adhd_metrics_window']['roc_auc']:.3f}")
    print(f"     F1-Score: {results['adhd_metrics_window']['f1_score']:.3f}")
    print(f"\n   Nivel Sujeto:")
    print(f"     Accuracy: {results['adhd_metrics_subject']['accuracy']:.2%}")
    print(f"     ROC-AUC: {results['adhd_metrics_subject']['roc_auc']:.3f}")
    print(f"     F1-Score: {results['adhd_metrics_subject']['f1_score']:.3f}")
    print(f"     Confianza: {results['adhd_metrics_subject']['confidence_stats']['mean']:.2%}")
    print(f"\n   Archivos generados:")
    print(f"     - adhd_predictions.csv (para Paso 7)")
    print(f"     - subject_predictions_detailed.csv")
    print(f"     - evaluation_metrics.json")
    print(f"     - Visualizaciones en plots/")


if __name__ == "__main__":
    main()
