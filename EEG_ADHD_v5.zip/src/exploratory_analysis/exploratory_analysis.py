"""
Módulo 1: Análisis Exploratorio de Datos EEG
====================================================

"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats, signal
from typing import Dict
import warnings
warnings.filterwarnings('ignore')

# Configuración de visualización
plt.style.use('seaborn-v0_8-darkgrid')
sns.set_palette("husl")

class EEGExploratoryAnalysis:
    """
    Clase para realizar análisis exploratorio de datos EEG
    """
    
    def __init__(self, data_path: str, fs: int = 128):
        """
        Inicializar análisis exploratorio
        
        Args:
            data_path: Ruta al archivo CSV con datos EEG
            fs: Frecuencia de muestreo (Hz)
        """
        self.data_path = data_path
        self.fs = fs
        self.channels = ['Fp1', 'Fp2', 'F3', 'F4', 'C3', 'C4', 'P3', 'P4', 
                        'O1', 'O2', 'F7', 'F8', 'T7', 'T8', 'P7', 'P8', 
                        'Fz', 'Cz', 'Pz']
        self.df = None
        self.stats_summary = {}
        
    def load_data(self) -> pd.DataFrame:
        """Cargar datos EEG desde CSV"""
        print(" Cargando datos EEG...")
        self.df = pd.read_csv(self.data_path)
        print(f" Datos cargados: {self.df.shape[0]} muestras, {self.df.shape[1]} columnas")
        return self.df
    
    def basic_statistics(self) -> Dict:
        """Calcular estadísticas básicas del dataset"""
        print("\n ESTADÍSTICAS BÁSICAS DEL DATASET")
        print("=" * 60)
        
        stats = {}
        
        # Distribución de clases
        class_dist = self.df['Class'].value_counts()
        stats['class_distribution'] = class_dist
        print(f"\n Distribución de Clases:")
        print(class_dist)
        
        # Número de sujetos únicos
        unique_subjects = self.df['ID'].nunique()
        stats['total_subjects'] = unique_subjects
        print(f"\n Número de sujetos únicos: {unique_subjects}")
        
        # Sujetos por clase
        subjects_per_class = self.df.groupby('Class')['ID'].nunique()
        stats['subjects_per_class'] = subjects_per_class
        print(f"\n Sujetos por clase:")
        print(subjects_per_class)
        
        # Muestras por sujeto
        samples_per_subject = self.df.groupby('ID').size()
        stats['samples_per_subject'] = samples_per_subject.describe()
        print(f"\n Estadísticas de muestras por sujeto:")
        print(samples_per_subject.describe())
        
        # Duración estimada por sujeto
        duration_per_subject = samples_per_subject / self.fs
        stats['duration_per_subject'] = duration_per_subject.describe()
        print(f"\n Duración estimada por sujeto (segundos):")
        print(duration_per_subject.describe())
        
        self.stats_summary = stats
        return stats
    
    def analyze_signal_quality(self) -> Dict:
        """Analizar calidad de las señales EEG"""
        print("\n ANÁLISIS DE CALIDAD DE SEÑALES")
        print("=" * 60)
        
        quality_metrics = {}
        
        for channel in self.channels:
            channel_data = self.df[channel].values
            
            # Valores faltantes
            missing = np.sum(np.isnan(channel_data))
            
            # Valores extremos (outliers usando IQR)
            Q1 = np.percentile(channel_data, 25)
            Q3 = np.percentile(channel_data, 75)
            IQR = Q3 - Q1
            outliers = np.sum((channel_data < Q1 - 3*IQR) | (channel_data > Q3 + 3*IQR))
            
            # Rango dinámico
            dynamic_range = np.ptp(channel_data)
            
            # SNR estimado (simple)
            signal_power = np.mean(channel_data**2)
            noise_power = np.var(np.diff(channel_data))
            snr = 10 * np.log10(signal_power / (noise_power + 1e-10))
            
            quality_metrics[channel] = {
                'missing': missing,
                'outliers': outliers,
                'dynamic_range': dynamic_range,
                'snr_db': snr
            }
        
        # Resumen
        quality_df = pd.DataFrame(quality_metrics).T
        print("\n Métricas de calidad por canal:")
        print(quality_df.describe())
        
        return quality_metrics
    
    def analyze_amplitude_distribution(self) -> None:
        """Analizar distribución de amplitudes por clase"""
        print("\n ANÁLISIS DE DISTRIBUCIÓN DE AMPLITUDES")
        print("=" * 60)
        
        fig, axes = plt.subplots(5, 4, figsize=(20, 25))
        axes = axes.flatten()
        
        for idx, channel in enumerate(self.channels):
            adhd_data = self.df[self.df['Class'] == 'ADHD'][channel]
            control_data = self.df[self.df['Class'] == 'Control'][channel]
            
            axes[idx].hist(adhd_data, bins=50, alpha=0.6, label='ADHD', density=True)
            axes[idx].hist(control_data, bins=50, alpha=0.6, label='Control', density=True)
            axes[idx].set_title(f'{channel}')
            axes[idx].set_xlabel('Amplitud (μV)')
            axes[idx].set_ylabel('Densidad')
            axes[idx].legend()
            axes[idx].grid(True, alpha=0.3)
            
            # Test de normalidad
            _, p_adhd = stats.normaltest(adhd_data.dropna())
            _, p_control = stats.normaltest(control_data.dropna())
            
            axes[idx].text(0.02, 0.98, f'Normal test p:\nADHD:{p_adhd:.4f}\nCtrl:{p_control:.4f}',
                          transform=axes[idx].transAxes, verticalalignment='top',
                          bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5),
                          fontsize=8)
        
        # Remover axes sobrantes
        for idx in range(len(self.channels), len(axes)):
            fig.delaxes(axes[idx])
        
        plt.tight_layout()
        plt.savefig('../EEG_ADHD_v5/results/1_amplitude_distribution.png', 
                    dpi=300, bbox_inches='tight')
        print(" Gráfico guardado: 1_amplitude_distribution.png")
        plt.close()
    
    def analyze_spectral_power(self) -> Dict:
        """Analizar potencia espectral por bandas de frecuencia"""
        print("\n ANÁLISIS DE POTENCIA ESPECTRAL")
        print("=" * 60)
        
        # Definir bandas de frecuencia
        bands = {
            'Delta': (0.5, 4),
            'Theta': (4, 8),
            'Alpha': (8, 13),
            'Beta': (13, 30),
            'Gamma': (30, 64)
        }
        
        spectral_features = []
        
        # Analizar un subconjunto de datos por eficiencia
        sample_size = min(10000, len(self.df))
        sample_df = self.df.sample(n=sample_size, random_state=42)
        
        for idx, row in sample_df.iterrows():
            subject_id = row['ID']
            class_label = row['Class']
            
            for channel in self.channels:
                signal_data = row[channel]
                
                if not np.isnan(signal_data):
                    # Calcular PSD usando Welch
                    f, psd = signal.welch([signal_data], fs=self.fs, nperseg=min(128, self.fs))
                    
                    # Potencia por banda
                    for band_name, (low, high) in bands.items():
                        band_power = np.trapz(psd[(f >= low) & (f < high)])
                        
                        spectral_features.append({
                            'ID': subject_id,
                            'Class': class_label,
                            'Channel': channel,
                            'Band': band_name,
                            'Power': band_power
                        })
        
        spectral_df = pd.DataFrame(spectral_features)
        
        # Visualizar potencia por banda y clase
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        axes = axes.flatten()
        
        for idx, (band_name, _) in enumerate(bands.items()):
            band_data = spectral_df[spectral_df['Band'] == band_name]
            
            sns.boxplot(data=band_data, x='Class', y='Power', ax=axes[idx])
            axes[idx].set_title(f'Banda {band_name}')
            axes[idx].set_ylabel('Potencia Espectral')
            axes[idx].set_yscale('log')
            
            # Test estadístico
            adhd_power = band_data[band_data['Class'] == 'ADHD']['Power']
            control_power = band_data[band_data['Class'] == 'Control']['Power']
            
            if len(adhd_power) > 0 and len(control_power) > 0:
                _, p_value = stats.mannwhitneyu(adhd_power, control_power)
                axes[idx].text(0.5, 0.95, f'p-value: {p_value:.4f}',
                              transform=axes[idx].transAxes,
                              ha='center', va='top',
                              bbox=dict(boxstyle='round', facecolor='yellow', alpha=0.5))
        
        # Remover axis sobrante
        fig.delaxes(axes[5])
        
        plt.tight_layout()
        plt.savefig('../EEG_ADHD_v5/results/2_spectral_power.png', 
                    dpi=300, bbox_inches='tight')
        print(" Gráfico guardado: 2_spectral_power.png")
        plt.close()
        
        return spectral_df
    
    def analyze_temporal_patterns(self) -> None:
        """Analizar patrones temporales de las señales"""
        print("\n ANÁLISIS DE PATRONES TEMPORALES")
        print("=" * 60)
        
        # Seleccionar un sujeto representativo de cada clase
        adhd_subject = self.df[self.df['Class'] == 'ADHD']['ID'].iloc[0]
        control_subject = self.df[self.df['Class'] == 'Control']['ID'].iloc[0]
        
        adhd_data = self.df[self.df['ID'] == adhd_subject].head(self.fs * 10)  # 10 segundos
        control_data = self.df[self.df['ID'] == control_subject].head(self.fs * 10)
        
        fig, axes = plt.subplots(4, 2, figsize=(16, 16))
        
        channels_to_plot = ['Fp1', 'Fz', 'Cz', 'Pz']
        time_axis = np.arange(len(adhd_data)) / self.fs
        
        for idx, channel in enumerate(channels_to_plot):
            # ADHD
            axes[idx, 0].plot(time_axis, adhd_data[channel].values, linewidth=0.8)
            axes[idx, 0].set_title(f'ADHD - {channel}')
            axes[idx, 0].set_ylabel('Amplitud (μV)')
            axes[idx, 0].grid(True, alpha=0.3)
            
            # Control
            axes[idx, 1].plot(time_axis, control_data[channel].values, linewidth=0.8)
            axes[idx, 1].set_title(f'Control - {channel}')
            axes[idx, 1].set_ylabel('Amplitud (μV)')
            axes[idx, 1].grid(True, alpha=0.3)
            
            if idx == len(channels_to_plot) - 1:
                axes[idx, 0].set_xlabel('Tiempo (s)')
                axes[idx, 1].set_xlabel('Tiempo (s)')
        
        plt.tight_layout()
        plt.savefig('../EEG_ADHD_v5/results/3_temporal_patterns.png', 
                    dpi=300, bbox_inches='tight')
        print(" Gráfico guardado: 3_temporal_patterns.png")
        plt.close()
    
    def analyze_channel_correlations(self) -> None:
        """Analizar correlaciones entre canales"""
        print("\n ANÁLISIS DE CORRELACIONES ENTRE CANALES")
        print("=" * 60)
        
        # Calcular matrices de correlación por clase
        adhd_data = self.df[self.df['Class'] == 'ADHD'][self.channels].corr()
        control_data = self.df[self.df['Class'] == 'Control'][self.channels].corr()
        
        fig, axes = plt.subplots(1, 3, figsize=(24, 7))
        
        # ADHD
        sns.heatmap(adhd_data, annot=False, cmap='RdBu_r', center=0, 
                    vmin=-1, vmax=1, ax=axes[0], cbar_kws={'label': 'Correlación'})
        axes[0].set_title('Correlaciones - ADHD', fontsize=14, fontweight='bold')
        
        # Control
        sns.heatmap(control_data, annot=False, cmap='RdBu_r', center=0, 
                    vmin=-1, vmax=1, ax=axes[1], cbar_kws={'label': 'Correlación'})
        axes[1].set_title('Correlaciones - Control', fontsize=14, fontweight='bold')
        
        # Diferencia
        diff = adhd_data - control_data
        sns.heatmap(diff, annot=False, cmap='RdBu_r', center=0, 
                    vmin=-0.5, vmax=0.5, ax=axes[2], cbar_kws={'label': 'Diferencia'})
        axes[2].set_title('Diferencia (ADHD - Control)', fontsize=14, fontweight='bold')
        
        plt.tight_layout()
        plt.savefig('../EEG_ADHD_v5/results/4_channel_correlations.png', 
                    dpi=300, bbox_inches='tight')
        print(" Gráfico guardado: 4_channel_correlations.png")
        plt.close()
    
    def generate_summary_report(self) -> None:
        """Generar reporte resumen del análisis exploratorio"""
        print("\n GENERANDO REPORTE RESUMEN")
        print("=" * 60)
        
        report = []
        report.append("=" * 80)
        report.append("REPORTE DE ANÁLISIS EXPLORATORIO - EEG TDAH")
        report.append("=" * 80)
        report.append("")
        
        # Dataset info
        report.append("1. INFORMACIÓN DEL DATASET")
        report.append("-" * 80)
        report.append(f"   • Total de muestras: {len(self.df):,}")
        report.append(f"   • Número de canales: {len(self.channels)}")
        report.append(f"   • Frecuencia de muestreo: {self.fs} Hz")
        report.append(f"   • Total de sujetos: {self.stats_summary.get('total_subjects', 'N/A')}")
        report.append("")
        
        # Class distribution
        report.append("2. DISTRIBUCIÓN DE CLASES")
        report.append("-" * 80)
        if 'class_distribution' in self.stats_summary:
            for cls, count in self.stats_summary['class_distribution'].items():
                report.append(f"   • {cls}: {count:,} muestras")
        report.append("")
        
        # Recommendations
        report.append("3. RECOMENDACIONES PARA PREPROCESAMIENTO")
        report.append("-" * 80)
        report.append("Aplicar filtro pasa-banda (0.5-50 Hz)")
        report.append("Implementar filtro notch (60 Hz / 50 Hz según región)")
        report.append("Realizar ICA para eliminación de artefactos oculares y musculares")
        report.append("Aplicar CAR (Common Average Reference)")
        report.append("Normalización por sujeto (z-score)")
        report.append("")
        
        report.append("4. OBSERVACIONES CLAVE")
        report.append("-" * 80)
        report.append("   • Los datos muestran variabilidad inter-sujeto")
        report.append("   • Se requiere análisis multi-escala temporal")
        report.append("   • Las diferencias espectrales sugieren características discriminativas")
        report.append("")
        
        report_text = "\n".join(report)
        
        # Guardar reporte
        with open('../EEG_ADHD_v5/results/exploratory_analysis_report.txt', 'w', encoding='utf-8') as f:
            f.write(report_text)
        
        print(report_text)
        print(" Reporte guardado: exploratory_analysis_report.txt")
    
    def run_complete_analysis(self) -> None:
        """Ejecutar análisis exploratorio completo"""
        print("\n" + "="*80)
        print(" INICIANDO ANÁLISIS EXPLORATORIO COMPLETO")
        print("="*80)
        
        # Cargar datos
        self.load_data()
        
        # Estadísticas básicas
        self.basic_statistics()
        
        # Calidad de señales
        self.analyze_signal_quality()
        
        # Análisis de amplitudes
        self.analyze_amplitude_distribution()
        
        # Análisis espectral
        self.analyze_spectral_power()
        
        # Patrones temporales
        self.analyze_temporal_patterns()
        
        # Correlaciones
        self.analyze_channel_correlations()
        
        # Reporte final
        self.generate_summary_report()
        
        print("\n" + "="*80)
        print(" ANÁLISIS EXPLORATORIO COMPLETADO")
        print("="*80)


# Ejemplo de uso
if __name__ == "__main__":
    # Crear directorio de resultados
    import os
    os.makedirs('../EEG_ADHD_v5/results', exist_ok=True)
    
    # Inicializar y ejecutar análisis
    analyzer = EEGExploratoryAnalysis(
        data_path='../data/raw/adhddata.csv',
        fs=128
    )
    
    # Ejecutar análisis completo
    analyzer.run_complete_analysis()
