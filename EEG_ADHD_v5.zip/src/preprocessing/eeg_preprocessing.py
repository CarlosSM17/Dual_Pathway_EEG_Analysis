"""
Módulo 3: Preprocesamiento Avanzado de Señales EEG
==================================================
Descripción: Implementación de pipeline de preprocesamiento completo:
            - Filtro pasa-banda (0.5-50 Hz)
            - Filtro Notch (60 Hz)
            - Descomposición Wavelet
            - ICA para eliminación de artefactos
            - Common Average Reference (CAR)

"""

import numpy as np
import pandas as pd
from scipy import signal
from scipy.signal import butter, filtfilt, iirnotch
import pywt
from sklearn.decomposition import FastICA
from typing import Dict, List, Tuple, Optional
import h5py
from tqdm import tqdm
import warnings
warnings.filterwarnings('ignore')


class EEGPreprocessor:
    """
    Clase para preprocesamiento completo de señales EEG
    """
    
    def __init__(self, fs: int = 128):
        """
        Inicializar preprocesador
        
        Args:
            fs: Frecuencia de muestreo (Hz)
        """
        self.fs = fs
        self.channels = ['Fp1', 'Fp2', 'F3', 'F4', 'C3', 'C4', 'P3', 'P4', 
                        'O1', 'O2', 'F7', 'F8', 'T7', 'T8', 'P7', 'P8', 
                        'Fz', 'Cz', 'Pz']
        self.n_channels = len(self.channels)
        
        # Parámetros de filtrado
        self.bandpass_low = 0.5
        self.bandpass_high = 50.0
        self.notch_freq = 60.0  
        self.notch_quality = 30.0
        
    # ============================================================================
    # FILTROS DIGITALES
    # ============================================================================
    
    def bandpass_filter(self, data: np.ndarray, lowcut: float = None, 
                       highcut: float = None, order: int = 4) -> np.ndarray:
        """
        Aplicar filtro pasa-banda Butterworth
        
        Args:
            data: Señal de entrada (samples,) o (channels, samples)
            lowcut: Frecuencia de corte inferior (Hz)
            highcut: Frecuencia de corte superior (Hz)
            order: Orden del filtro
            
        Returns:
            Señal filtrada
        """
        if lowcut is None:
            lowcut = self.bandpass_low
        if highcut is None:
            highcut = self.bandpass_high
        
        nyquist = 0.5 * self.fs
        low = lowcut / nyquist
        high = highcut / nyquist
        
        # Diseñar filtro
        b, a = butter(order, [low, high], btype='band')
        
        # Aplicar filtro
        if data.ndim == 1:
            filtered_data = filtfilt(b, a, data)
        else:
            filtered_data = np.zeros_like(data)
            for i in range(data.shape[0]):
                filtered_data[i] = filtfilt(b, a, data[i])
        
        return filtered_data
    
    def notch_filter(self, data: np.ndarray, freq: float = None, 
                    quality: float = None) -> np.ndarray:
        """
        Aplicar filtro Notch para eliminar ruido de línea eléctrica
        
        Args:
            data: Señal de entrada
            freq: Frecuencia a eliminar (Hz)
            quality: Factor de calidad del filtro
            
        Returns:
            Señal filtrada
        """
        if freq is None:
            freq = self.notch_freq
        if quality is None:
            quality = self.notch_quality
        
        # Diseñar filtro notch
        b, a = iirnotch(freq, quality, self.fs)
        
        # Aplicar filtro
        if data.ndim == 1:
            filtered_data = filtfilt(b, a, data)
        else:
            filtered_data = np.zeros_like(data)
            for i in range(data.shape[0]):
                filtered_data[i] = filtfilt(b, a, data[i])
        
        return filtered_data
    
    # ============================================================================
    # DESCOMPOSICIÓN WAVELET
    # ============================================================================
    
    def wavelet_decomposition(self, data: np.ndarray, wavelet: str = 'db4', 
                             level: int = 5) -> Dict:
        """
        Realizar descomposición wavelet de la señal
        
        Args:
            data: Señal de entrada
            wavelet: Tipo de wavelet ('db4', 'sym4', 'coif4', etc.)
            level: Nivel de descomposición
            
        Returns:
            Diccionario con coeficientes de descomposición
        """
        if data.ndim == 1:
            coeffs = pywt.wavedec(data, wavelet, level=level)
            return {
                'approximation': coeffs[0],
                'details': coeffs[1:]
            }
        else:
            decompositions = []
            for i in range(data.shape[0]):
                coeffs = pywt.wavedec(data[i], wavelet, level=level)
                decompositions.append({
                    'approximation': coeffs[0],
                    'details': coeffs[1:]
                })
            return decompositions
    
    def wavelet_denoising(self, data: np.ndarray, wavelet: str = 'db4', 
                         level: int = 5, threshold_mode: str = 'soft') -> np.ndarray:
        """
        Eliminación de ruido mediante thresholding de wavelets
        
        Args:
            data: Señal de entrada
            wavelet: Tipo de wavelet
            level: Nivel de descomposición
            threshold_mode: Modo de threshold ('soft' o 'hard')
            
        Returns:
            Señal denoiseada
        """
        if data.ndim == 1:
            # Descomponer
            coeffs = pywt.wavedec(data, wavelet, level=level)
            
            # Calcular threshold (regla universal de Donoho)
            sigma = np.median(np.abs(coeffs[-1])) / 0.6745
            threshold = sigma * np.sqrt(2 * np.log(len(data)))
            
            # Aplicar threshold a coeficientes de detalle
            coeffs_thresh = [coeffs[0]]
            for detail_coeffs in coeffs[1:]:
                coeffs_thresh.append(pywt.threshold(detail_coeffs, threshold, 
                                                    mode=threshold_mode))
            
            # Reconstruir señal
            denoised = pywt.waverec(coeffs_thresh, wavelet)
            
            # Asegurar misma longitud
            return denoised[:len(data)]
        else:
            denoised_data = np.zeros_like(data)
            for i in range(data.shape[0]):
                denoised_data[i] = self.wavelet_denoising(
                    data[i], wavelet, level, threshold_mode
                )
            return denoised_data
    
    # ============================================================================
    # INDEPENDENT COMPONENT ANALYSIS (ICA)
    # ============================================================================
    
    def apply_ica(self, data: np.ndarray, n_components: int = None, 
                  max_iter: int = 500, random_state: int = 42) -> Tuple[np.ndarray, object]:
        """
        Aplicar ICA para separación de fuentes independientes
        
        Args:
            data: Datos de entrada (channels, samples)
            n_components: Número de componentes (None = mismo que canales)
            max_iter: Número máximo de iteraciones
            random_state: Semilla aleatoria
            
        Returns:
            Tupla (componentes independientes, objeto ICA)
        """
        if n_components is None:
            n_components = data.shape[0]
        
        # Transponer para formato sklearn (samples, features)
        data_t = data.T
        
        # Aplicar ICA
        ica = FastICA(n_components=n_components, max_iter=max_iter, 
                     random_state=random_state, whiten='unit-variance')
        
        # Ajustar y transformar
        ica_sources = ica.fit_transform(data_t)
        
        # Transponer de vuelta (components, samples)
        return ica_sources.T, ica
    
    def remove_artifacts_ica(self, data: np.ndarray, 
                           artifact_indices: List[int]) -> np.ndarray:
        """
        Eliminar artefactos usando ICA
        
        Args:
            data: Datos de entrada (channels, samples)
            artifact_indices: Índices de componentes que son artefactos
            
        Returns:
            Datos con artefactos eliminados
        """
        # Aplicar ICA
        ica_sources, ica = self.apply_ica(data)
        
        # Eliminar componentes de artefactos
        ica_sources_clean = ica_sources.copy()
        ica_sources_clean[artifact_indices, :] = 0
        
        # Reconstruir señal
        reconstructed = ica.inverse_transform(ica_sources_clean.T)
        
        return reconstructed.T
    
    def detect_blink_components(self, ica_sources: np.ndarray, 
                               frontal_channels: List[str] = None) -> List[int]:
        """
        Detectar automáticamente componentes de parpadeo
        
        Args:
            ica_sources: Componentes independientes (components, samples)
            frontal_channels: Lista de canales frontales a considerar
            
        Returns:
            Lista de índices de componentes de parpadeo
        """
        if frontal_channels is None:
            frontal_channels = ['Fp1', 'Fp2']
        
        # Criterios para detección de parpadeos:
        # 1. Alta amplitud
        # 2. Actividad principalmente en canales frontales
        # 3. Cambios abruptos
        
        blink_components = []
        
        for i in range(ica_sources.shape[0]):
            component = ica_sources[i]
            
            # Criterio 1: Alta amplitud relativa
            amplitude = np.std(component)
            mean_amplitude = np.mean([np.std(ica_sources[j]) 
                                     for j in range(ica_sources.shape[0])])
            
            if amplitude > 2 * mean_amplitude:
                blink_components.append(i)
        
        return blink_components
    
    # ============================================================================
    # COMMON AVERAGE REFERENCE (CAR)
    # ============================================================================
    
    def apply_car(self, data: np.ndarray) -> np.ndarray:
        """
        Aplicar Common Average Reference
        
        Args:
            data: Datos de entrada (channels, samples)
            
        Returns:
            Datos con CAR aplicado
        """
        # Calcular promedio de todos los canales
        avg_signal = np.mean(data, axis=0)
        
        # Restar promedio de cada canal
        car_data = data - avg_signal
        
        return car_data
    
    # ============================================================================
    # NORMALIZACIÓN
    # ============================================================================
    
    def z_score_normalization(self, data: np.ndarray, axis: int = -1) -> np.ndarray:
        """
        Normalización Z-score
        
        Args:
            data: Datos de entrada
            axis: Eje a lo largo del cual normalizar
            
        Returns:
            Datos normalizados
        """
        mean = np.mean(data, axis=axis, keepdims=True)
        std = np.std(data, axis=axis, keepdims=True)
        
        # Evitar división por cero
        std[std == 0] = 1
        
        normalized = (data - mean) / std
        
        return normalized
    
    def robust_scaling(self, data: np.ndarray, axis: int = -1) -> np.ndarray:
        """
        Escalado robusto usando mediana e IQR
        
        Args:
            data: Datos de entrada
            axis: Eje a lo largo del cual escalar
            
        Returns:
            Datos escalados
        """
        median = np.median(data, axis=axis, keepdims=True)
        q75 = np.percentile(data, 75, axis=axis, keepdims=True)
        q25 = np.percentile(data, 25, axis=axis, keepdims=True)
        iqr = q75 - q25
        
        # Evitar división por cero
        iqr[iqr == 0] = 1
        
        scaled = (data - median) / iqr
        
        return scaled
    
    # ============================================================================
    # PIPELINE COMPLETO
    # ============================================================================
    
    def preprocess_window(self, window: np.ndarray, 
                         apply_wavelet: bool = True,
                         apply_ica: bool = True,
                         apply_car: bool = True,
                         normalize: str = 'zscore') -> np.ndarray:
        """
        Aplicar pipeline completo de preprocesamiento a una ventana
        
        Args:
            window: Ventana de datos (channels, samples)
            apply_wavelet: Aplicar denoising wavelet
            apply_ica: Aplicar ICA para eliminación de artefactos
            apply_car: Aplicar Common Average Reference
            normalize: Tipo de normalización ('zscore', 'robust', o None)
            
        Returns:
            Ventana preprocesada
        """
        processed = window.copy()
        
        # 1. Filtro pasa-banda
        processed = self.bandpass_filter(processed)
        
        # 2. Filtro Notch
        processed = self.notch_filter(processed)
        
        # 3. Wavelet denoising (opcional)
        if apply_wavelet:
            processed = self.wavelet_denoising(processed)
        
        # 4. ICA para eliminación de artefactos (opcional)
        if apply_ica and processed.shape[0] >= 3:  # Necesita al menos 3 canales
            try:
                ica_sources, ica = self.apply_ica(processed)
                
                # Detectar y eliminar componentes de artefactos
                artifact_components = self.detect_blink_components(ica_sources)
                
                if len(artifact_components) > 0:
                    ica_sources_clean = ica_sources.copy()
                    ica_sources_clean[artifact_components, :] = 0
                    processed = ica.inverse_transform(ica_sources_clean.T).T
            except Exception as e:
                print(f"    ICA falló: {e}. Continuando sin ICA.")
        
        # 5. Common Average Reference (opcional)
        if apply_car:
            processed = self.apply_car(processed)
        
        # 6. Normalización
        if normalize == 'zscore':
            processed = self.z_score_normalization(processed, axis=-1)
        elif normalize == 'robust':
            processed = self.robust_scaling(processed, axis=-1)
        
        return processed
    
    def preprocess_dataset(self, input_file: str, output_file: str,
                          apply_wavelet: bool = True,
                          apply_ica: bool = True,  # ICA puede ser costoso
                          apply_car: bool = True,
                          normalize: str = 'zscore') -> None:
        """
        Preprocesar dataset completo multi-escala
        
        Args:
            input_file: Ruta al archivo HDF5 de entrada
            output_file: Ruta al archivo HDF5 de salida
            apply_wavelet: Aplicar denoising wavelet
            apply_ica: Aplicar ICA
            apply_car: Aplicar CAR
            normalize: Tipo de normalización
        """
        print("\n PREPROCESANDO DATASET MULTI-ESCALA")
        print("=" * 80)
        print(f"Pipeline de preprocesamiento:")
        print(f"Filtro pasa-banda: {self.bandpass_low}-{self.bandpass_high} Hz")
        print(f"Filtro Notch: {self.notch_freq} Hz")
        print(f"   {'✓' if apply_wavelet else '✗'} Wavelet denoising")
        print(f"   {'✓' if apply_ica else '✗'} ICA")
        print(f"   {'✓' if apply_car else '✗'} CAR")
        print(f"   ✓ Normalización: {normalize}")
        print()
        
        # Abrir archivos
        with h5py.File(input_file, 'r') as hf_in, \
             h5py.File(output_file, 'w') as hf_out:
            
            # Copiar metadatos
            for key, value in hf_in.attrs.items():
                hf_out.attrs[key] = value
            
            # Procesar cada escala temporal
            for scale_key in hf_in.keys():
                print(f" Procesando {scale_key}...")
                
                scale_group_in = hf_in[scale_key]
                scale_group_out = hf_out.create_group(scale_key)
                
                # Copiar atributos de escala
                for key, value in scale_group_in.attrs.items():
                    scale_group_out.attrs[key] = value
                
                # Procesar cada sujeto
                for subject_id in tqdm(scale_group_in.keys(), desc=f"  {scale_key}"):
                    subject_group_in = scale_group_in[subject_id]
                    subject_group_out = scale_group_out.create_group(subject_id)
                    
                    # Copiar atributos de sujeto
                    for key, value in subject_group_in.attrs.items():
                        subject_group_out.attrs[key] = value
                    
                    # Cargar ventanas
                    windows = subject_group_in['windows'][:]
                    
                    # Preprocesar cada ventana
                    processed_windows = np.zeros_like(windows)
                    
                    for i in range(windows.shape[0]):
                        processed_windows[i] = self.preprocess_window(
                            windows[i],
                            apply_wavelet=apply_wavelet,
                            apply_ica=apply_ica,
                            apply_car=apply_car,
                            normalize=normalize
                        )
                    
                    # Guardar ventanas procesadas
                    subject_group_out.create_dataset(
                        'windows', 
                        data=processed_windows,
                        compression='gzip',
                        compression_opts=9
                    )
        
        print(f"\n Preprocesamiento completado")
        print(f" Datos guardados en: {output_file}")


# Ejemplo de uso
if __name__ == "__main__":
    import os
    os.makedirs('../data/processed', exist_ok=True)
    
    # Inicializar preprocesador
    preprocessor = EEGPreprocessor(fs=128)
    
    # Preprocesar dataset
    preprocessor.preprocess_dataset(
        input_file='../data/processed/multi_scale_data.h5',
        output_file='../data/processed/preprocessed_data.h5',
        apply_wavelet=True,
        apply_ica=True, 
        apply_car=True,
        normalize='zscore'
    )
