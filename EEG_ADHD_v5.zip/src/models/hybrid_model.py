"""
Módulo 5: Modelo Híbrido de Deep Learning para Análisis EEG-TDAH
=================================================================

Arquitectura:
1. Spatial Encoder (CNN) - Extracción de patrones espaciales
2. Temporal Transformer - Dependencias temporales largas
3. Bidirectional LSTM - Modelado de secuencias
4. Multi-Head Attention - Enfoque en características relevantes
5. Multi-Task Classification Head - Clasificación de perfiles

"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import TransformerEncoder, TransformerEncoderLayer
import math


class SpatialCNNEncoder(nn.Module):
    """CNN para extracción de patrones espaciales en EEG"""
    
    def __init__(self, n_channels: int = 19, n_filters: int = 64):
        super(SpatialCNNEncoder, self).__init__()
        
        # Convolución espacial (a través de canales)
        self.spatial_conv1 = nn.Conv2d(1, n_filters, kernel_size=(n_channels, 1))
        self.bn1 = nn.BatchNorm2d(n_filters)
        
        # Convolución temporal
        self.temporal_conv1 = nn.Conv2d(n_filters, n_filters, kernel_size=(1, 25), padding=(0, 12))
        self.bn2 = nn.BatchNorm2d(n_filters)
        
        self.temporal_conv2 = nn.Conv2d(n_filters, n_filters * 2, kernel_size=(1, 25), padding=(0, 12))
        self.bn3 = nn.BatchNorm2d(n_filters * 2)
        
        # Pooling
        self.pool = nn.AvgPool2d(kernel_size=(1, 4))
        
        self.dropout = nn.Dropout(0.5)
        
    def forward(self, x):
        # x: (batch, 1, channels, samples)
        
        # Convolución espacial
        x = F.elu(self.bn1(self.spatial_conv1(x)))
        x = self.dropout(x)
        
        # Convoluciones temporales
        x = F.elu(self.bn2(self.temporal_conv1(x)))
        x = self.pool(x)
        x = self.dropout(x)
        
        x = F.elu(self.bn3(self.temporal_conv2(x)))
        x = self.pool(x)
        x = self.dropout(x)
        
        return x


class PositionalEncoding(nn.Module):
    """Codificación posicional para Transformer"""
    
    def __init__(self, d_model: int, max_len: int = 5000):
        super(PositionalEncoding, self).__init__()
        
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        
        pe = pe.unsqueeze(0).transpose(0, 1)
        self.register_buffer('pe', pe)
        
    def forward(self, x):
        return x + self.pe[:x.size(0), :]


class TemporalTransformer(nn.Module):
    """Transformer para captura de dependencias temporales"""
    
    def __init__(self, d_model: int = 128, nhead: int = 8, 
                 num_layers: int = 4, dim_feedforward: int = 512):
        super(TemporalTransformer, self).__init__()
        
        self.pos_encoder = PositionalEncoding(d_model)
        
        encoder_layers = TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=0.3,
            batch_first=True
        )
        
        self.transformer_encoder = TransformerEncoder(
            encoder_layers,
            num_layers=num_layers
        )
        
        self.d_model = d_model
        
    def forward(self, x):
        # x: (batch, seq_len, d_model)
        x = self.pos_encoder(x.transpose(0, 1)).transpose(0, 1)
        x = self.transformer_encoder(x)
        return x


class BidirectionalLSTM(nn.Module):
    """BiLSTM para modelado de secuencias temporales"""
    
    def __init__(self, input_size: int, hidden_size: int = 128, num_layers: int = 2):
        super(BidirectionalLSTM, self).__init__()
        
        self.lstm = nn.LSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=0.3
        )
        
        self.layer_norm = nn.LayerNorm(hidden_size * 2)
        
    def forward(self, x):
        # x: (batch, seq_len, input_size)
        lstm_out, (h_n, c_n) = self.lstm(x)
        lstm_out = self.layer_norm(lstm_out)
        return lstm_out, (h_n, c_n)


class MultiHeadAttention(nn.Module):
    """Mecanismo de atención multi-cabeza personalizado"""
    
    def __init__(self, d_model: int = 256, num_heads: int = 8):
        super(MultiHeadAttention, self).__init__()
        
        self.num_heads = num_heads
        self.d_model = d_model
        self.d_k = d_model // num_heads
        
        self.W_q = nn.Linear(d_model, d_model)
        self.W_k = nn.Linear(d_model, d_model)
        self.W_v = nn.Linear(d_model, d_model)
        self.W_o = nn.Linear(d_model, d_model)
        
        self.dropout = nn.Dropout(0.1)
        
    def scaled_dot_product_attention(self, Q, K, V, mask=None):
        attn_scores = torch.matmul(Q, K.transpose(-2, -1)) / math.sqrt(self.d_k)
        
        if mask is not None:
            attn_scores = attn_scores.masked_fill(mask == 0, -1e9)
        
        attn_probs = F.softmax(attn_scores, dim=-1)
        attn_probs = self.dropout(attn_probs)
        
        output = torch.matmul(attn_probs, V)
        
        return output, attn_probs
    
    def split_heads(self, x):
        batch_size, seq_length, d_model = x.size()
        return x.view(batch_size, seq_length, self.num_heads, self.d_k).transpose(1, 2)
    
    def combine_heads(self, x):
        batch_size, _, seq_length, d_k = x.size()
        return x.transpose(1, 2).contiguous().view(batch_size, seq_length, self.d_model)
    
    def forward(self, Q, K, V, mask=None):
        Q = self.split_heads(self.W_q(Q))
        K = self.split_heads(self.W_k(K))
        V = self.split_heads(self.W_v(V))
        
        attn_output, attn_weights = self.scaled_dot_product_attention(Q, K, V, mask)
        
        output = self.W_o(self.combine_heads(attn_output))
        
        return output, attn_weights


class MultiTaskClassificationHead(nn.Module):
    """Cabeza de clasificación multi-tarea"""
    
    def __init__(self, input_dim: int, num_profiles: int = 5):
        super(MultiTaskClassificationHead, self).__init__()
        
        # Tarea 1: Clasificación ADHD vs Control
        self.adhd_classifier = nn.Sequential(
            nn.Linear(input_dim, 256),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, 2)  # ADHD vs Control
        )
        
        # Tarea 2: Clasificación de perfil temporal
        self.profile_classifier = nn.Sequential(
            nn.Linear(input_dim, 256),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, num_profiles)  # 5 perfiles
        )
        
        # Tarea 3: Predicción de nivel de atención (regresión)
        self.attention_regressor = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, 1)  # Nivel de atención continuo
        )
    
    def forward(self, x):
        adhd_logits = self.adhd_classifier(x)
        profile_logits = self.profile_classifier(x)
        attention_score = self.attention_regressor(x)
        
        return {
            'adhd': adhd_logits,
            'profile': profile_logits,
            'attention': attention_score
        }


class HybridEEGModel(nn.Module):
    """
    Modelo híbrido completo para análisis de EEG en TDAH
    """
    
    def __init__(self, n_channels: int = 19, time_samples: int = 128,
                 cnn_filters: int = 64, transformer_dim: int = 128,
                 lstm_hidden: int = 128, num_profiles: int = 5):
        super(HybridEEGModel, self).__init__()
        
        print("  Construyendo Modelo Híbrido EEG-TDAH")
        
        # 1. Spatial CNN Encoder
        self.spatial_encoder = SpatialCNNEncoder(n_channels, cnn_filters)
        
        # Calcular dimensión después de CNN
        self.cnn_output_samples = time_samples // 16  # Después de 2 poolings de 4
        self.cnn_output_channels = cnn_filters * 2
        
        # Proyección a dimensión del transformer
        self.projection = nn.Linear(self.cnn_output_channels, transformer_dim)
        
        # 2. Temporal Transformer
        self.temporal_transformer = TemporalTransformer(
            d_model=transformer_dim,
            nhead=8,
            num_layers=4
        )
        
        # 3. Bidirectional LSTM
        self.bilstm = BidirectionalLSTM(
            input_size=transformer_dim,
            hidden_size=lstm_hidden,
            num_layers=2
        )
        
        # 4. Multi-Head Attention
        self.attention = MultiHeadAttention(
            d_model=lstm_hidden * 2,  # BiLSTM output
            num_heads=8
        )
        
        # 5. Global pooling
        self.global_pool = nn.AdaptiveAvgPool1d(1)
        
        # 6. Multi-Task Classification Head
        self.classification_head = MultiTaskClassificationHead(
            input_dim=lstm_hidden * 2,
            num_profiles=num_profiles
        )
        
        print(f"    Spatial CNN Encoder: {n_channels} channels → {cnn_filters*2} features")
        print(f"    Temporal Transformer: {transformer_dim}-dim, 4 layers")
        print(f"    BiLSTM: {lstm_hidden} hidden units, 2 layers")
        print(f"    Multi-Head Attention: 8 heads")
        print(f"    Classification Head: Multi-task ({num_profiles} profiles)")
    
    def forward(self, x):
        # x: (batch, channels, samples)
        batch_size = x.size(0)
        
        # Preparar para CNN (agregar dimensión de canal)
        x = x.unsqueeze(1)  # (batch, 1, channels, samples)
        
        # 1. Spatial CNN Encoding
        x = self.spatial_encoder(x)  # (batch, cnn_channels, 1, reduced_samples)
        
        # Reshape para secuencia
        x = x.squeeze(2).transpose(1, 2)  # (batch, seq_len, features)
        
        # Proyectar a dimensión del transformer
        x = self.projection(x)  # (batch, seq_len, transformer_dim)
        
        # 2. Temporal Transformer
        x = self.temporal_transformer(x)  # (batch, seq_len, transformer_dim)
        
        # 3. Bidirectional LSTM
        x, _ = self.bilstm(x)  # (batch, seq_len, lstm_hidden*2)
        
        # 4. Multi-Head Attention (self-attention)
        x, attn_weights = self.attention(x, x, x)  # (batch, seq_len, lstm_hidden*2)
        
        # 5. Global pooling
        x = x.transpose(1, 2)  # (batch, features, seq_len)
        x = self.global_pool(x).squeeze(-1)  # (batch, features)
        
        # 6. Multi-Task Classification
        outputs = self.classification_head(x)
        
        return outputs, attn_weights


def create_model(config: dict = None):
    """
    Crear instancia del modelo con configuración personalizada
    
    Args:
        config: Diccionario de configuración
        
    Returns:
        Modelo instanciado
    """
    if config is None:
        config = {
            'n_channels': 19,
            'time_samples': 128,
            'cnn_filters': 64,
            'transformer_dim': 128,
            'lstm_hidden': 128,
            'num_profiles': 5
        }
    
    model = HybridEEGModel(**config)
    
    # Contar parámetros
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    
    print(f"\n Parámetros del modelo:")
    print(f"   Total: {total_params:,}")
    print(f"   Entrenables: {trainable_params:,}")
    
    return model


if __name__ == "__main__":
    # Ejemplo de uso
    model = create_model()
    
    # Test forward pass
    batch_size = 128
    n_channels = 19
    samples = 128
    
    x = torch.randn(batch_size, n_channels, samples)
    
    outputs, attn_weights = model(x)
    
    print("\n Test forward pass:")
    print(f"   Input shape: {x.shape}")
    print(f"   ADHD output: {outputs['adhd'].shape}")
    print(f"   Profile output: {outputs['profile'].shape}")
    print(f"   Attention output: {outputs['attention'].shape}")
    print(f"   Attention weights: {attn_weights.shape}")
