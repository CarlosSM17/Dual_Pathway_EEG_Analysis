"""
Módulo 2: División por Escalas Temporales 
======================================================
"""

import numpy as np
import pandas as pd
from typing import Dict, List
import h5py
from tqdm import tqdm
import warnings
warnings.filterwarnings('ignore')

class TemporalScaler:
    """
    Clase para dividir señales EEG en múltiples escalas temporales
    """
    
    def __init__(self, data_path: str, fs: int = 128):
        """
        Inicializar el escalador temporal
        
        Args:
            data_path: Ruta al archivo CSV con datos EEG
            fs: Frecuencia de muestreo (Hz)
        """
        self.data_path = data_path
        self.fs = fs
        self.channels = ['Fp1', 'Fp2', 'F3', 'F4', 'C3', 'C4', 'P3', 'P4', 
                        'O1', 'O2', 'F7', 'F8', 'T7', 'T8', 'P7', 'P8', 
                        'Fz', 'Cz', 'Pz']
        
        # Escalas temporales en segundos
        self.time_scales = [1,2,4,8,16]
        
        # Número de muestras por ventana
        self.window_samples = {
            scale: scale * self.fs for scale in self.time_scales
        }
        
        self.df = None
        self.scaled_data = {}
        
    def load_data(self) -> pd.DataFrame:
        """Cargar datos EEG desde CSV"""
        print("Cargando datos EEG...")
        self.df = pd.read_csv(self.data_path)
        print(f"Datos cargados: {self.df.shape[0]} muestras")
        return self.df
    
    def create_windows(self, signal: np.ndarray, window_size: int, 
                       overlap: float = 0.5) -> List[np.ndarray]:
        """
        Crear ventanas deslizantes de una señal
        
        Args:
            signal: Señal de entrada
            window_size: Tamaño de la ventana en muestras
            overlap: Proporción de solapamiento (0-1)
            
        Returns:
            Lista de ventanas
        """
        step_size = int(window_size * (1 - overlap))
        windows = []
        
        for start in range(0, len(signal) - window_size + 1, step_size):
            end = start + window_size
            window = signal[start:end]
            
            if len(window) == window_size:
                windows.append(window)
        
        return windows
    
    def segment_by_subject(self, subject_id: str, time_scale: int, 
                          overlap: float = 0.5) -> Dict:
        """
        Segmentar datos de un sujeto en una escala temporal específica
        
        Args:
            subject_id: ID del sujeto
            time_scale: Escala temporal en segundos
            overlap: Proporción de solapamiento
            
        Returns:
            Diccionario con ventanas segmentadas
        """
        # Filtrar datos del sujeto
        subject_data = self.df[self.df['ID'] == subject_id].copy()
        
        if len(subject_data) == 0:
            return None
        
        # Obtener clase del sujeto
        subject_class = subject_data['Class'].iloc[0]
        
        # Tamaño de ventana en muestras
        window_size = self.window_samples[time_scale]
        
        # Contenedor para las ventanas
        windows_data = {
            'windows': [],
            'subject_id': subject_id,
            'class': subject_class,
            'time_scale': time_scale,
            'n_windows': 0
        }
        
        # Procesar cada canal
        channel_windows = {}
        
        for channel in self.channels:
            signal = subject_data[channel].values
            windows = self.create_windows(signal, window_size, overlap)
            channel_windows[channel] = windows
        
        # Organizar ventanas (todas deben tener el mismo número)
        n_windows = min(len(windows) for windows in channel_windows.values())
        
        for i in range(n_windows):
            window_dict = {}
            
            for channel in self.channels:
                window_dict[channel] = channel_windows[channel][i]
            
            window_dict['subject_id'] = subject_id
            window_dict['class'] = subject_class
            window_dict['time_scale'] = time_scale
            window_dict['window_index'] = i
            
            windows_data['windows'].append(window_dict)
        
        windows_data['n_windows'] = n_windows
        
        return windows_data
    
    def process_all_scales(self, overlap: float = 0.5, 
                          save_format: str = 'hdf5') -> Dict:
        """
        Procesar todos los sujetos en todas las escalas temporales
        
        Args:
            overlap: Proporción de solapamiento
            save_format: Formato de guardado ('hdf5' o 'numpy')
            
        Returns:
            Diccionario con datos segmentados por escala
        """
        print("\nPROCESANDO ESCALAS TEMPORALES MULTI-ESCALA")
        print("=" * 80)
        
        # Cargar datos si no están cargados
        if self.df is None:
            self.load_data()
        
        # Obtener lista de sujetos únicos
        unique_subjects = self.df['ID'].unique()
        print(f"Total de sujetos: {len(unique_subjects)}")
        
        # Procesar cada escala temporal
        for time_scale in self.time_scales:
            print(f"\nProcesando escala: {time_scale} segundos")
            print(f"   Tamaño de ventana: {self.window_samples[time_scale]} muestras")
            
            scale_data = {
                'time_scale': time_scale,
                'window_size': self.window_samples[time_scale],
                'overlap': overlap,
                'subjects': [],
                'total_windows': 0
            }
            
            # Procesar cada sujeto
            for subject_id in tqdm(unique_subjects, desc=f"Escala {time_scale}s"):
                subject_windows = self.segment_by_subject(
                    subject_id, time_scale, overlap
                )
                
                if subject_windows is not None and subject_windows['n_windows'] > 0:
                    scale_data['subjects'].append(subject_windows)
                    scale_data['total_windows'] += subject_windows['n_windows']
            
            self.scaled_data[time_scale] = scale_data
            
            print(f"Procesados {len(scale_data['subjects'])} sujetos")
            print(f"Total de ventanas: {scale_data['total_windows']}")
        
        # Guardar datos
        if save_format == 'hdf5':
            self.save_as_hdf5()
        elif save_format == 'numpy':
            self.save_as_numpy()
        
        # Generar estadísticas
        self.generate_scaling_statistics()
        
        return self.scaled_data
    
    def save_as_hdf5(self, output_path: str = None) -> None:
        """
        Guardar datos segmentados en formato HDF5
        
        Args:
            output_path: Ruta de salida (opcional)
        """
        if output_path is None:
            output_path = '../EEG_ADHD_v5/data/processed/multi_scale_data.h5'
        
        print(f"\nGuardando datos en formato HDF5...")
        
        with h5py.File(output_path, 'w') as hf:
            # Metadata general
            hf.attrs['fs'] = self.fs
            hf.attrs['channels'] = self.channels
            hf.attrs['time_scales'] = self.time_scales
            
            # Guardar cada escala temporal
            for time_scale, scale_data in self.scaled_data.items():
                scale_group = hf.create_group(f'scale_{time_scale}s')
                scale_group.attrs['time_scale'] = time_scale
                scale_group.attrs['total_windows'] = scale_data['total_windows']
                
                # Guardar datos de cada sujeto
                for subject_data in scale_data['subjects']:
                    subject_id = subject_data['subject_id']
                    subject_group = scale_group.create_group(subject_id)
                    
                    subject_group.attrs['class'] = subject_data['class']
                    subject_group.attrs['n_windows'] = subject_data['n_windows']
                    
                    # Organizar ventanas en arrays
                    n_windows = subject_data['n_windows']
                    window_size = self.window_samples[time_scale]
                    n_channels = len(self.channels)
                    
                    # Crear array 3D: (n_windows, n_channels, window_size)
                    windows_array = np.zeros((n_windows, n_channels, window_size))
                    
                    for i, window in enumerate(subject_data['windows']):
                        for ch_idx, channel in enumerate(self.channels):
                            windows_array[i, ch_idx, :] = window[channel]
                    
                    subject_group.create_dataset('windows', data=windows_array,
                                                compression='gzip', compression_opts=9)
        
        print(f"Datos guardados en: {output_path}")
    
    def save_as_numpy(self, output_dir: str = None) -> None:
        """
        Guardar datos segmentados en formato NumPy
        
        Args:
            output_dir: Directorio de salida (opcional)
        """
        if output_dir is None:
            output_dir = '../EEG_ADHD_v5/data/processed/numpy_arrays'
        
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        print(f"\nGuardando datos en formato NumPy...")
        
        for time_scale, scale_data in self.scaled_data.items():
            scale_dir = os.path.join(output_dir, f'scale_{time_scale}s')
            os.makedirs(scale_dir, exist_ok=True)
            
            for subject_data in scale_data['subjects']:
                subject_id = subject_data['subject_id']
                
                # Organizar en array
                n_windows = subject_data['n_windows']
                window_size = self.window_samples[time_scale]
                n_channels = len(self.channels)
                
                windows_array = np.zeros((n_windows, n_channels, window_size))
                
                for i, window in enumerate(subject_data['windows']):
                    for ch_idx, channel in enumerate(self.channels):
                        windows_array[i, ch_idx, :] = window[channel]
                
                # Guardar
                metadata = {
                    'class': subject_data['class'],
                    'n_windows': n_windows,
                    'time_scale': time_scale,
                    'channels': self.channels
                }
                
                file_path = os.path.join(scale_dir, f'{subject_id}.npz')
                np.savez_compressed(file_path, 
                                   windows=windows_array,
                                   metadata=metadata)
        
        print(f"Datos guardados en: {output_dir}")
    
    def generate_scaling_statistics(self) -> None:
        """Generar estadísticas de la segmentación"""
        print("\nESTADÍSTICAS DE SEGMENTACIÓN MULTI-ESCALA")
        print("=" * 80)
        
        stats = []
        
        for time_scale in self.time_scales:
            scale_data = self.scaled_data[time_scale]
            
            # Contar ventanas por clase
            adhd_windows = 0
            control_windows = 0
            
            for subject_data in scale_data['subjects']:
                if subject_data['class'] == 'ADHD':
                    adhd_windows += subject_data['n_windows']
                else:
                    control_windows += subject_data['n_windows']
            
            stats.append({
                'Escala (s)': time_scale,
                'Ventanas ADHD': adhd_windows,
                'Ventanas Control': control_windows,
                'Total Ventanas': scale_data['total_windows'],
                'Ratio ADHD/Control': adhd_windows / (control_windows + 1e-10)
            })
        
        stats_df = pd.DataFrame(stats)
        print(stats_df.to_string(index=False))
        
        # Guardar estadísticas
        stats_df.to_csv('../EEG_ADHD_v5/results/scaling_statistics.csv', 
                       index=False)
        print("\nEstadísticas guardadas: scaling_statistics.csv")
    
    def load_scaled_data(self, file_path: str, time_scale: int = None) -> Dict:
        """
        Cargar datos segmentados desde archivo HDF5
        
        Args:
            file_path: Ruta al archivo HDF5
            time_scale: Escala temporal específica a cargar (opcional)
            
        Returns:
            Diccionario con datos cargados
        """
        print(f"Cargando datos segmentados desde: {file_path}")
        
        loaded_data = {}
        
        with h5py.File(file_path, 'r') as hf:
            scales = self.time_scales if time_scale is None else [time_scale]
            
            for scale in scales:
                scale_key = f'scale_{scale}s'
                
                if scale_key in hf:
                    scale_group = hf[scale_key]
                    scale_data = {
                        'time_scale': scale,
                        'subjects': []
                    }
                    
                    for subject_id in scale_group.keys():
                        subject_group = scale_group[subject_id]
                        windows_array = subject_group['windows'][:]
                        
                        subject_data = {
                            'subject_id': subject_id,
                            'class': subject_group.attrs['class'],
                            'n_windows': subject_group.attrs['n_windows'],
                            'windows': windows_array
                        }
                        
                        scale_data['subjects'].append(subject_data)
                    
                    loaded_data[scale] = scale_data
                    print(f"Cargada escala {scale}s: {len(scale_data['subjects'])} sujetos")
        
        return loaded_data


# Ejemplo de uso
if __name__ == "__main__":
    import os
    os.makedirs('../EEG_ADHD_v5/data/processed', exist_ok=True)
    
    # Inicializar escalador
    scaler = TemporalScaler(
        data_path='../EEG_ADHD_v5/data/raw/adhdata.csv',
        fs=128
    )
    
    # Procesar todas las escalas con 50% de solapamiento
    scaled_data = scaler.process_all_scales(
        overlap=0.5,
        save_format='hdf5'
    )
    
    print("\nProcesamiento de escalas temporales completado")
