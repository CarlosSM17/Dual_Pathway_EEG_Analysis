"""
Módulo de Generación de Planes de Intervención Educativa Personalizados
========================================================================

Genera recomendaciones de intervención basadas en perfiles integrados ADHD
alineadas con la taxonomía científica de estrategias educativas.

"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple
from dataclasses import dataclass, field
from pathlib import Path
import json
from datetime import datetime

# Importar perfil integrado
from integrated_profile_system import IntegratedProfile


# ============================================================================
# TAXONOMÍA DE ESTRATEGIAS (Basada en investigación)
# ============================================================================

@dataclass
class InterventionStrategy:
    """Estrategia de intervención individual"""
    code: str
    name: str
    category: str
    evidence: str  # "High", "Moderate"
    expected_impact: str
    description: str
    implementation: List[str]
    materials_needed: List[str] = field(default_factory=list)
    time_investment: str = ""  # "Low", "Moderate", "High"
    
    def to_dict(self) -> Dict:
        """Convertir a diccionario"""
        return {
            'code': self.code,
            'name': self.name,
            'category': self.category,
            'evidence': self.evidence,
            'expected_impact': self.expected_impact,
            'description': self.description,
            'implementation': self.implementation,
            'materials_needed': self.materials_needed,
            'time_investment': self.time_investment
        }


# Definir todas las estrategias de la taxonomía
INTERVENTION_STRATEGIES = {
    # ========================================================================
    # ESTRATEGIAS AMBIENTALES (Environmental)
    # ========================================================================
    'ENV1': InterventionStrategy(
        code='ENV1',
        name='Ubicación Estratégica',
        category='Ambiental',
        evidence='Alto',
        expected_impact='Incremento de atención',
        description='Colocar al estudiante cerca del profesor, lejos de distracciones (ventanas, puertas, compañeros disruptivos)',
        implementation=[
            'Sentar al estudiante en las primeras filas',
            'Posición cerca del escritorio del profesor',
            'Evitar asientos cerca de ventanas o puertas',
            'Alejar de estudiantes con comportamiento disruptivo',
            'Considerar asiento junto a estudiantes modelo'
        ],
        materials_needed=['Reorganización del salón'],
        time_investment='Bajo'
    ),
    
    'ENV2': InterventionStrategy(
        code='ENV2',
        name='Reducción de Estimulación Visual',
        category='Ambiental',
        evidence='Moderado',
        expected_impact='Reducción de distracción',
        description='Minimizar elementos visuales distractores en el entorno de trabajo',
        implementation=[
            'Reducir decoraciones excesivas en paredes',
            'Usar carpetas o divisores visuales',
            'Minimizar objetos en el escritorio del estudiante',
            'Usar áreas de trabajo visualmente "limpias"',
            'Considerar uso de auriculares con cancelación de ruido'
        ],
        materials_needed=['Divisores visuales', 'Organizadores de escritorio'],
        time_investment='Bajo'
    ),
    
    'ENV3': InterventionStrategy(
        code='ENV3',
        name='Control de Ruido Ambiental',
        category='Ambiental',
        evidence='Alto',
        expected_impact='Mejora de concentración',
        description='Reducir ruido y distracciones auditivas en el ambiente',
        implementation=[
            'Utilizar señales visuales en lugar de audibles cuando sea posible',
            'Proporcionar auriculares con cancelación de ruido',
            'Crear "zonas de silencio" para trabajo concentrado',
            'Usar música de fondo suave o ruido blanco si ayuda',
            'Minimizar interrupciones auditivas durante tareas críticas'
        ],
        materials_needed=['Auriculares', 'Señalización visual', 'Reproductor de ruido blanco'],
        time_investment='Moderado'
    ),
    
    # ========================================================================
    # ESTRATEGIAS INSTRUCCIONALES (Instructional)
    # ========================================================================
    'INS1': InterventionStrategy(
        code='INS1',
        name='Segmentación de Tareas',
        category='Instruccional',
        evidence='Alto',
        expected_impact='Incremento de completación de tareas',
        description='Dividir tareas largas en segmentos manejables con checkpoints',
        implementation=[
            'Dividir asignaciones largas en pasos pequeños',
            'Proporcionar una tarea a la vez',
            'Usar listas de verificación para cada paso',
            'Celebrar la completación de cada segmento',
            'Proporcionar retroalimentación frecuente'
        ],
        materials_needed=['Listas de verificación', 'Timers visuales'],
        time_investment='Moderado'
    ),
    
    'INS2': InterventionStrategy(
        code='INS2',
        name='Instrucciones Multimodales',
        category='Instruccional',
        evidence='Alto',
        expected_impact='Incremento de comprensión',
        description='Presentar información usando múltiples modalidades (visual, auditiva, kinestésica)',
        implementation=[
            'Combinar instrucciones verbales con visuales',
            'Usar diagramas, gráficos y organizadores visuales',
            'Incorporar elementos táctiles o manipulativos',
            'Repetir información importante en diferentes formatos',
            'Verificar comprensión pidiendo al estudiante que parafrasee'
        ],
        materials_needed=['Materiales visuales', 'Organizadores gráficos', 'Manipulativos'],
        time_investment='Moderado'
    ),
    
    'INS3': InterventionStrategy(
        code='INS3',
        name='Tiempo Extendido',
        category='Instruccional',
        evidence='Alto',
        expected_impact='Reducción de frustración, incremento de retención',
        description='Proporcionar tiempo adicional para completar tareas y evaluaciones',
        implementation=[
            'Dar 50% más de tiempo en exámenes',
            'Permitir pausas durante tareas largas',
            'No penalizar por trabajo no terminado en tiempo regular',
            'Ofrecer oportunidades de completar fuera del aula',
            'Reducir cantidad de tareas si es necesario'
        ],
        materials_needed=['Flexibilidad en horarios'],
        time_investment='Bajo'
    ),
    
    'INS4': InterventionStrategy(
        code='INS4',
        name='Organizadores Gráficos',
        category='Instruccional',
        evidence='Alto',
        expected_impact='Incremento de comprensión y organización',
        description='Usar mapas conceptuales, diagramas y estructuras visuales',
        implementation=[
            'Proporcionar organizadores gráficos pre-elaborados',
            'Enseñar a crear mapas mentales',
            'Usar líneas de tiempo para secuencias',
            'Implementar diagramas de Venn para comparaciones',
            'Utilizar matrices para organizar información'
        ],
        materials_needed=['Plantillas de organizadores', 'Software de mapas mentales'],
        time_investment='Moderado'
    ),
    
    # ========================================================================
    # ESTRATEGIAS CONDUCTUALES (Behavioral)
    # ========================================================================
    'BEH1': InterventionStrategy(
        code='BEH1',
        name='Reforzamiento Positivo',
        category='Conductual',
        evidence='Alto',
        expected_impact='Incremento de comportamiento deseado',
        description='Sistema de recompensas por comportamientos y logros específicos',
        implementation=[
            'Establecer sistema de puntos o fichas',
            'Proporcionar retroalimentación positiva inmediata',
            'Usar refuerzos tangibles e intangibles',
            'Celebrar pequeños logros frecuentemente',
            'Mantener ratio alto de comentarios positivos vs negativos (5:1)'
        ],
        materials_needed=['Sistema de puntos', 'Recompensas', 'Gráficas de progreso'],
        time_investment='Moderado'
    ),
    
    'BEH2': InterventionStrategy(
        code='BEH2',
        name='Auto-monitoreo',
        category='Conductual',
        evidence='Moderado',
        expected_impact='Incremento de motivación, auto-conciencia y auto-regulación',
        description='Enseñar al estudiante a monitorear y registrar su propio comportamiento',
        implementation=[
            'Crear listas de verificación de auto-evaluación',
            'Usar timers/alarmas para auto-chequeos',
            'Registrar progreso en gráficas personales',
            'Establecer metas personales medibles',
            'Revisar regularmente el progreso con el estudiante'
        ],
        materials_needed=['Hojas de auto-monitoreo', 'Timers', 'Gráficas de progreso'],
        time_investment='Alto'
    ),
    
    # ========================================================================
    # ESTRATEGIAS COGNITIVAS (Cognitive)
    # ========================================================================
    'COG1': InterventionStrategy(
        code='COG1',
        name='Entrenamiento de Memoria de Trabajo',
        category='Cognitiva',
        evidence='Moderado',
        expected_impact='Incremento de memoria de trabajo',
        description='Ejercicios específicos para fortalecer la memoria de trabajo',
        implementation=[
            'Juegos de memoria secuencial (ej. Simon dice)',
            'Tareas de span de dígitos progresivo',
            'Ejercicios de n-back',
            'Repetición y parafraseo de instrucciones',
            'Uso de estrategias de "chunking" (agrupación)'
        ],
        materials_needed=['Aplicaciones de entrenamiento cognitivo', 'Juegos de memoria'],
        time_investment='Alto'
    ),
    
    'COG2': InterventionStrategy(
        code='COG2',
        name='Estrategias Mnemotécnicas',
        category='Cognitiva',
        evidence='Alto',
        expected_impact='Incremento de retención y recuperación',
        description='Enseñar técnicas de memoria para retener información',
        implementation=[
            'Acrónimos y acrósticos',
            'Método de loci (palacio de memoria)',
            'Rimas y canciones',
            'Asociaciones visuales',
            'Técnica de la cadena (linking)'
        ],
        materials_needed=['Guías de mnemotécnicas', 'Tarjetas de memoria'],
        time_investment='Moderado'
    ),
    
    # ========================================================================
    # ESTRATEGIAS TECNOLÓGICAS (Technological)
    # ========================================================================
    'TEC1': InterventionStrategy(
        code='TEC1',
        name='Herramientas Digitales',
        category='Tecnológica',
        evidence='Moderado',
        expected_impact='Apoyo organizacional y motivacional',
        description='Uso de aplicaciones y software para organización y concentración',
        implementation=[
            'Apps de gestión de tiempo (ej. Forest, Focus@Will)',
            'Software de organización (ej. Notion, Trello)',
            'Recordatorios y alarmas',
            'Apps de bloqueo de distracciones',
            'Herramientas de texto-a-voz o voz-a-texto'
        ],
        materials_needed=['Dispositivo digital', 'Licencias de software'],
        time_investment='Moderado'
    ),
    
    'TEC2': InterventionStrategy(
        code='TEC2',
        name='Neurofeedback',
        category='Tecnológica',
        evidence='Moderado',
        expected_impact='Mejora de auto-regulación atencional',
        description='Entrenamiento con retroalimentación de actividad cerebral',
        implementation=[
            'Sesiones regulares de neurofeedback (2-3 veces/semana)',
            'Protocolos específicos para ADHD (ej. beta/theta)',
            'Monitoreo de progreso con evaluaciones',
            'Integración con otras estrategias',
            'Seguimiento a largo plazo'
        ],
        materials_needed=['Equipo de neurofeedback', 'Software especializado', 'Profesional entrenado'],
        time_investment='Alto'
    ),
    
    # ========================================================================
    # ESTRATEGIAS DE DESCANSO/MOVIMIENTO (Rest/Movement)
    # ========================================================================
    'MOV1': InterventionStrategy(
        code='MOV1',
        name='Pausas de Movimiento',
        category='Descanso/Movimiento',
        evidence='Alto',
        expected_impact='Renovación de atención',
        description='Pausas programadas para actividad física',
        implementation=[
            'Pausas de 2-3 minutos cada 20-30 minutos',
            'Permitir fidgets o movimiento controlado',
            'Ejercicios de estiramiento en el asiento',
            'Oportunidades de levantarse (borrar pizarra, repartir materiales)',
            'Brain breaks con movimiento (yoga, jumping jacks)'
        ],
        materials_needed=['Fidgets', 'Espacio para movimiento', 'Timer'],
        time_investment='Bajo'
    ),
    
    'MOV2': InterventionStrategy(
        code='MOV2',
        name='Asiento Flexible',
        category='Descanso/Movimiento',
        evidence='Moderado',
        expected_impact='Reducción de inquietud, incremento de tiempo en tarea',
        description='Opciones de asientos alternativos que permiten movimiento',
        implementation=[
            'Balones de ejercicio como asientos',
            'Bandas elásticas en patas de sillas',
            'Escritorios de pie (standing desks)',
            'Cojines de aire o wobble cushions',
            'Permitir cambio de posición frecuente'
        ],
        materials_needed=['Asientos alternativos', 'Balones', 'Bandas elásticas'],
        time_investment='Bajo'
    ),
}


# ============================================================================
# GENERADOR DE PLANES DE INTERVENCIÓN
# ============================================================================

class EducationalInterventionPlanner:
    """
    Genera planes de intervención educativa personalizados
    basados en perfiles integrados ADHD
    """
    
    def __init__(self, output_dir: str = './intervention_plans'):
        """
        Inicializar generador de planes
        
        Args:
            output_dir: Directorio para guardar planes
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.strategies = INTERVENTION_STRATEGIES
        
    def generate_plan(self, profile: IntegratedProfile) -> Dict:
        """
        Generar plan de intervención personalizado
        
        Args:
            profile: Perfil integrado del estudiante
            
        Returns:
            plan: Diccionario con plan completo
        """
        print(f"\n📋 Generando plan de intervención para: {profile.subject_id}")
        
        # 1. Analizar necesidades basadas en perfil
        needs_analysis = self._analyze_needs(profile)
        
        # 2. Seleccionar y priorizar estrategias
        selected_strategies = self._select_strategies(profile, needs_analysis)
        
        # 3. Crear plan estructurado
        plan = self._create_intervention_plan(
            profile=profile,
            needs=needs_analysis,
            strategies=selected_strategies
        )
        
        # 4. Guardar plan
        self._save_plan(profile.subject_id, plan)
        
        print(f"   ✅ Plan generado: {len(selected_strategies)} estrategias")
        
        return plan
    
    def _analyze_needs(self, profile: IntegratedProfile) -> Dict:
        """
        Analizar necesidades del estudiante basado en perfil
        
        Returns:
            needs: Diccionario con áreas de necesidad y prioridades
        """
        needs = {
            'priority_areas': [],
            'severity_level': profile.severity_category,
            'primary_challenges': [],
            'strengths': []
        }
        
        # Analizar basado en índices de funcionamiento
        if profile.sustained_attention_index < 0.5:
            needs['priority_areas'].append('attention')
            needs['primary_challenges'].append('Dificultad manteniendo atención sostenida')
        
        if profile.self_regulation_index < 0.5:
            needs['priority_areas'].append('self_regulation')
            needs['primary_challenges'].append('Dificultades de autorregulación')
        
        if profile.cognitive_flexibility_index < 0.5:
            needs['priority_areas'].append('cognitive_flexibility')
            needs['primary_challenges'].append('Rigidez cognitiva')
        
        # Analizar basado en perfil microtemporal
        profile_challenges = {
            0: [],  # Estable - pocas necesidades
            1: ['Necesita apoyo para mantener compensación'],
            2: ['Alta variabilidad requiere estructura'],
            3: ['Lapsos frecuentes requieren monitoreo'],
            4: ['Hipoactivación requiere estimulación']
        }
        
        needs['primary_challenges'].extend(
            profile_challenges.get(profile.dominant_profile, [])
        )
        
        # Analizar fortalezas
        if profile.sustained_attention_index >= 0.6:
            needs['strengths'].append('Buena atención sostenida en periodos cortos')
        
        if profile.recovery_capacity in ['Excelente', 'Buena']:
            needs['strengths'].append('Buena capacidad de recuperación')
        
        if profile.self_regulation_index >= 0.6:
            needs['strengths'].append('Capacidad de autorregulación')
        
        return needs
    
    def _select_strategies(self, 
                          profile: IntegratedProfile, 
                          needs: Dict) -> List[Tuple[str, InterventionStrategy, int]]:
        """
        Seleccionar y priorizar estrategias
        
        Returns:
            strategies: Lista de tuplas (código, estrategia, prioridad)
        """
        selected = []
        
        # ====================================================================
        # ESTRATEGIAS AMBIENTALES (Siempre recomendadas para ADHD)
        # ====================================================================
        if profile.adhd_diagnosis == 'ADHD':
            selected.append(('ENV1', self.strategies['ENV1'], 1))  # Alta prioridad
            
            if profile.severity_score > 40:
                selected.append(('ENV2', self.strategies['ENV2'], 2))
                selected.append(('ENV3', self.strategies['ENV3'], 1))
        
        # ====================================================================
        # ESTRATEGIAS INSTRUCCIONALES
        # ====================================================================
        # Segmentación de tareas (crítico para perfiles con lapsos)
        if profile.dominant_profile in [2, 3, 4]:  # Variable, Lapsos, Hipoactivación
            selected.append(('INS1', self.strategies['INS1'], 1))
        
        # Instrucciones multimodales (beneficia a todos con ADHD)
        if profile.adhd_diagnosis == 'ADHD':
            selected.append(('INS2', self.strategies['INS2'], 2))
        
        # Tiempo extendido (para severidad moderada-alta)
        if profile.severity_score > 45:
            selected.append(('INS3', self.strategies['INS3'], 1))
        
        # Organizadores gráficos (para problemas de organización)
        if 'cognitive_flexibility' in needs['priority_areas']:
            selected.append(('INS4', self.strategies['INS4'], 2))
        
        # ====================================================================
        # ESTRATEGIAS CONDUCTUALES
        # ====================================================================
        # Reforzamiento positivo (siempre útil)
        if profile.adhd_diagnosis == 'ADHD':
            selected.append(('BEH1', self.strategies['BEH1'], 1))
        
        # Auto-monitoreo (para estudiantes con algo de autorregulación)
        if profile.self_regulation_index >= 0.4:
            selected.append(('BEH2', self.strategies['BEH2'], 2))
        
        # ====================================================================
        # ESTRATEGIAS COGNITIVAS
        # ====================================================================
        # Memoria de trabajo (si es área de necesidad)
        if 'attention' in needs['priority_areas']:
            selected.append(('COG1', self.strategies['COG1'], 2))
        
        # Mnemotécnicas (útiles para todos)
        selected.append(('COG2', self.strategies['COG2'], 3))
        
        # ====================================================================
        # ESTRATEGIAS TECNOLÓGICAS
        # ====================================================================
        # Herramientas digitales (recomendadas para todos)
        selected.append(('TEC1', self.strategies['TEC1'], 3))
        
        # Neurofeedback (solo para casos moderados-severos)
        if profile.severity_score > 50:
            selected.append(('TEC2', self.strategies['TEC2'], 3))
        
        # ====================================================================
        # ESTRATEGIAS DE MOVIMIENTO
        # ====================================================================
        # Pausas (críticas para hiperactividad/inquietud)
        if profile.dominant_profile in [1, 2]:  # Compensada, Variable
            selected.append(('MOV1', self.strategies['MOV1'], 1))
        
        # Asiento flexible (moderadamente útil)
        if profile.adhd_diagnosis == 'ADHD':
            selected.append(('MOV2', self.strategies['MOV2'], 2))
        
        # Ordenar por prioridad
        selected.sort(key=lambda x: x[2])
        
        return selected
    
    def _create_intervention_plan(self,
                                 profile: IntegratedProfile,
                                 needs: Dict,
                                 strategies: List[Tuple]) -> Dict:
        """
        Crear plan estructurado de intervención
        
        Returns:
            plan: Diccionario con plan completo
        """
        plan = {
            'student_info': {
                'subject_id': profile.subject_id,
                'adhd_diagnosis': profile.adhd_diagnosis,
                'adhd_probability': profile.adhd_probability,
                'dominant_profile': profile.dominant_profile_name,
                'severity_category': profile.severity_category,
                'severity_score': profile.severity_score,
                'date_created': datetime.now().isoformat()
            },
            
            'needs_analysis': needs,
            
            'recommended_strategies': {
                'high_priority': [],
                'moderate_priority': [],
                'supplementary': []
            },
            
            'implementation_timeline': {
                'phase_1_immediate': [],  # Semana 1-2
                'phase_2_short_term': [],  # Semana 3-6
                'phase_3_long_term': []   # 2-6 meses
            },
            
            'monitoring_plan': {
                'frequency': 'Semanal durante primer mes, luego quincenal',
                'metrics': [
                    'Completación de tareas',
                    'Tiempo en tarea',
                    'Calidad del trabajo',
                    'Comportamiento en clase',
                    'Auto-reporte del estudiante'
                ],
                'adjustment_criteria': 'Revisar y ajustar si no hay mejoría en 4 semanas'
            },
            
            'parent_teacher_collaboration': {
                'communication_frequency': 'Semanal',
                'shared_strategies': [],
                'home_extension': []
            }
        }
        
        # Clasificar estrategias por prioridad
        for code, strategy, priority in strategies:
            strategy_dict = strategy.to_dict()
            
            if priority == 1:
                plan['recommended_strategies']['high_priority'].append(strategy_dict)
                plan['implementation_timeline']['phase_1_immediate'].append(code)
            elif priority == 2:
                plan['recommended_strategies']['moderate_priority'].append(strategy_dict)
                plan['implementation_timeline']['phase_2_short_term'].append(code)
            else:
                plan['recommended_strategies']['supplementary'].append(strategy_dict)
                plan['implementation_timeline']['phase_3_long_term'].append(code)
        
        # Identificar estrategias que pueden extenderse al hogar
        home_strategies = ['BEH1', 'BEH2', 'TEC1', 'MOV1', 'COG2']
        for code, strategy, _ in strategies:
            if code in home_strategies:
                plan['parent_teacher_collaboration']['home_extension'].append({
                    'strategy': strategy.name,
                    'adaptation': f"Aplicar {strategy.name} en contexto del hogar"
                })
        
        return plan
    
    def _save_plan(self, subject_id: str, plan: Dict):
        """Guardar plan como JSON y PDF legible"""
        # JSON
        json_path = self.output_dir / f'{subject_id}_intervention_plan.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(plan, f, indent=2, ensure_ascii=False)
        
        # Texto legible
        txt_path = self.output_dir / f'{subject_id}_intervention_plan.txt'
        with open(txt_path, 'w', encoding='utf-8') as f:
            f.write(self._format_plan_as_text(plan))
        
        print(f"    Plan guardado:")
        print(f"      JSON: {json_path}")
        print(f"      TXT: {txt_path}")
    
    def _format_plan_as_text(self, plan: Dict) -> str:
        """Formatear plan como texto legible"""
        lines = []
        
        lines.append("="*80)
        lines.append("PLAN DE INTERVENCIÓN EDUCATIVA PERSONALIZADO")
        lines.append("="*80)
        lines.append("")
        
        # Información del estudiante
        info = plan['student_info']
        lines.append("INFORMACIÓN DEL ESTUDIANTE")
        lines.append("-" * 80)
        lines.append(f"ID: {info['subject_id']}")
        lines.append(f"Diagnóstico: {info['adhd_diagnosis']} (probabilidad: {info['adhd_probability']:.2%})")
        lines.append(f"Perfil Dominante: {info['dominant_profile']}")
        lines.append(f"Severidad: {info['severity_category']} (score: {info['severity_score']:.1f})")
        lines.append(f"Fecha de creación: {info['date_created']}")
        lines.append("")
        
        # Análisis de necesidades
        needs = plan['needs_analysis']
        lines.append("ANÁLISIS DE NECESIDADES")
        lines.append("-" * 80)
        lines.append(f"Nivel de severidad: {needs['severity_level']}")
        lines.append("")
        lines.append("Desafíos principales:")
        for challenge in needs['primary_challenges']:
            lines.append(f"  • {challenge}")
        lines.append("")
        lines.append("Fortalezas:")
        for strength in needs['strengths']:
            lines.append(f"  • {strength}")
        lines.append("")
        
        # Estrategias recomendadas
        lines.append("ESTRATEGIAS RECOMENDADAS")
        lines.append("="*80)
        
        lines.append("\n🔴 PRIORIDAD ALTA (Implementar inmediatamente):")
        lines.append("-" * 80)
        for i, strategy in enumerate(plan['recommended_strategies']['high_priority'], 1):
            lines.append(f"\n{i}. {strategy['code']}: {strategy['name']}")
            lines.append(f"   Categoría: {strategy['category']}")
            lines.append(f"   Evidencia: {strategy['evidence']}")
            lines.append(f"   Impacto esperado: {strategy['expected_impact']}")
            lines.append(f"   Descripción: {strategy['description']}")
            lines.append(f"   Implementación:")
            for step in strategy['implementation']:
                lines.append(f"     • {step}")
            if strategy['materials_needed']:
                lines.append(f"   Materiales: {', '.join(strategy['materials_needed'])}")
        
        lines.append("\n\n🟡 PRIORIDAD MODERADA (Implementar en 2-4 semanas):")
        lines.append("-" * 80)
        for i, strategy in enumerate(plan['recommended_strategies']['moderate_priority'], 1):
            lines.append(f"\n{i}. {strategy['code']}: {strategy['name']}")
            lines.append(f"   Impacto esperado: {strategy['expected_impact']}")
            lines.append(f"   Descripción: {strategy['description']}")
        
        lines.append("\n\n🟢 ESTRATEGIAS SUPLEMENTARIAS (Considerar después de 1-2 meses):")
        lines.append("-" * 80)
        for i, strategy in enumerate(plan['recommended_strategies']['supplementary'], 1):
            lines.append(f"{i}. {strategy['code']}: {strategy['name']}")
        
        # Línea de tiempo
        lines.append("\n\nLÍNEA DE TIEMPO DE IMPLEMENTACIÓN")
        lines.append("="*80)
        timeline = plan['implementation_timeline']
        lines.append(f"\nFase 1 (Semana 1-2): {', '.join(timeline['phase_1_immediate'])}")
        lines.append(f"Fase 2 (Semana 3-6): {', '.join(timeline['phase_2_short_term'])}")
        lines.append(f"Fase 3 (2-6 meses): {', '.join(timeline['phase_3_long_term'])}")
        
        # Plan de monitoreo
        lines.append("\n\nPLAN DE MONITOREO")
        lines.append("="*80)
        monitoring = plan['monitoring_plan']
        lines.append(f"Frecuencia: {monitoring['frequency']}")
        lines.append("\nMétricas a evaluar:")
        for metric in monitoring['metrics']:
            lines.append(f"  • {metric}")
        lines.append(f"\nCriterios de ajuste: {monitoring['adjustment_criteria']}")
        
        # Colaboración
        lines.append("\n\nCOLABORACIÓN PADRES-MAESTROS")
        lines.append("="*80)
        collab = plan['parent_teacher_collaboration']
        lines.append(f"Frecuencia de comunicación: {collab['communication_frequency']}")
        lines.append("\nExtensión al hogar:")
        for ext in collab['home_extension']:
            lines.append(f"  • {ext['strategy']}: {ext['adaptation']}")
        
        lines.append("\n" + "="*80)
        lines.append("Fin del plan de intervención")
        lines.append("="*80)
        
        return "\n".join(lines)


# ============================================================================
# FUNCIONES DE USO
# ============================================================================

def generate_intervention_plan_for_profile(profile: IntegratedProfile,
                                          output_dir: str = './intervention_plans') -> Dict:
    """
    Función conveniente para generar plan de intervención
    
    Args:
        profile: Perfil integrado del estudiante
        output_dir: Directorio de salida
        
    Returns:
        plan: Plan de intervención completo
    """
    planner = EducationalInterventionPlanner(output_dir=output_dir)
    plan = planner.generate_plan(profile)
    return plan


def generate_plans_for_cohort(profiles: List[IntegratedProfile],
                              output_dir: str = './intervention_plans'):
    """
    Generar planes para toda una cohorte
    
    Args:
        profiles: Lista de perfiles integrados
        output_dir: Directorio de salida
    """
    print(f"\n{'='*80}")
    print("GENERACIÓN DE PLANES DE INTERVENCIÓN - COHORTE")
    print(f"{'='*80}")
    
    planner = EducationalInterventionPlanner(output_dir=output_dir)
    
    plans_generated = 0
    for profile in profiles:
        try:
            planner.generate_plan(profile)
            plans_generated += 1
        except Exception as e:
            print(f"    Error generando plan para {profile.subject_id}: {e}")
    
    print(f"\n Planes generados: {plans_generated}/{len(profiles)}")
    print(f" Ubicación: {output_dir}")


if __name__ == "__main__":
    print("Módulo de Generación de Planes de Intervención Educativa")
    print("Uso: Importar y usar con perfiles integrados del sistema")
