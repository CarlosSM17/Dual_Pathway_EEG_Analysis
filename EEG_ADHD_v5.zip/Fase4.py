"""
FASE 4: Pipeline de Perfiles Integrados
========================================

1. Carga resultados de diagnóstico ADHD (Fase 2)
2. Carga perfiles microtemporales (Fase 3)
3. Integra toda la información
4. Genera perfiles completos por sujeto
5. Análisis de cohorte (ADHD vs Control)
6. Visualizaciones y reportes

"""

import sys
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Dict, List
import warnings
warnings.filterwarnings('ignore')

# Importar módulos del sistema
from integrated_profile_system import (
    IntegratedProfile,
    ProfileIntegrator,
    visualize_integrated_profile,
    generate_clinical_interpretation
)


class Step7IntegratedPipeline:
    
    
    def __init__(self, base_dir: str = '../EEG_ADHD_v5'):
        """
        Inicializar pipeline
        
        Args:
            base_dir: Directorio base del proyecto
        """
        self.base_dir = Path(base_dir)
        self.data_dir = self.base_dir / 'data' / 'processed'
        self.models_dir = self.base_dir / 'models'
        self.results_dir = self.base_dir / 'results'
        self.profiles_dir = self.base_dir / 'profiles'
        
        # Crear directorios
        self.profiles_dir.mkdir(parents=True, exist_ok=True)
        (self.profiles_dir / 'visualizations').mkdir(exist_ok=True)
        
        # Archivos principales
        self.features_file = self.data_dir / 'microtemporal_features.csv'
        
        # Integrador
        self.integrator = ProfileIntegrator(base_dir=str(self.base_dir))
        
        print("\n" + "="*80)
        print("FASE 4: SISTEMA DE PERFILES INTEGRADOS")
        print("   Pipeline Completo del Paso 7")
        print("="*80)
        print(f"\nDirectorio base: {base_dir}")
        print(f"Perfiles: {self.profiles_dir}")
    
    def load_adhd_predictions(self, predictions_file: str = None) -> pd.DataFrame:
        """
        Cargar predicciones ADHD del modelo DL (Fase 2)
        
        Args:
            predictions_file: Ruta al archivo de predicciones
            
        Returns:
            df: DataFrame con predicciones por sujeto
        """
        print("\nCargando predicciones ADHD (Fase 2)...")
        
        if predictions_file is None:
            # Buscar archivo de predicciones
            possible_paths = [
                self.results_dir / 'adhd_predictions.csv',
                self.results_dir / 'model_predictions.csv',
                self.results_dir / 'dl_model_predictions.csv'
            ]
            
            for path in possible_paths:
                if path.exists():
                    predictions_file = path
                    break
        
        if predictions_file and Path(predictions_file).exists():
            df = pd.read_csv(predictions_file)
            print(f"    Predicciones cargadas: {len(df)} sujetos")
            return df
        else:
            print(f"     No se encontraron predicciones ADHD")
            print(f"   Usando diagnóstico de base de datos")
            return None
    
    def load_microtemporal_profiles(self) -> pd.DataFrame:
        """
        Cargar perfiles microtemporales 
        
        Returns:
            df: DataFrame con características y perfiles
        """
        print("\n Cargando perfiles microtemporales (Fase 3)...")
        
        if not self.features_file.exists():
            raise FileNotFoundError(f"Archivo de características no encontrado: {self.features_file}")
        
        df = pd.read_csv(self.features_file)
        print(f"    Features cargadas: {len(df)} secuencias")
        print(f"   Sujetos únicos: {df['subject_id'].nunique()}")
        
        return df
    
    def aggregate_subject_data(self, df: pd.DataFrame) -> Dict:
        """
        Agregar datos por sujeto
        
        Para cada sujeto, calcula:
        - Métricas promedio
        - Perfil dominante
        - Distribución de perfiles
        - Secuencias temporales
        
        Args:
            df: DataFrame con features por secuencia
            
        Returns:
            subject_data: Diccionario con datos agregados por sujeto
        """
        print("\n Agregando datos por sujeto...")
        
        subject_data = {}
        

        for subject_id in df['subject_id'].unique():
            subject_df = df[df['subject_id'] == subject_id]
            
            # Métricas promedio - CONVERTIR A TIPOS PYTHON NATIVOS
            metrics = {
                'mean_attention': float(subject_df['mean_attention'].mean()),
                'stability': float(subject_df['stability'].mean()),
                'transitions_per_minute': float(subject_df['transitions_per_minute'].mean()),
                'recovery_rate': float(subject_df['recovery_rate'].mean()),
                'coefficient_of_variation': float(subject_df['std_attention'].mean() / (subject_df['mean_attention'].mean() + 1e-10)),
                'decrement_percentage': float(subject_df.get('attention_decline', pd.Series([0])).mean() * 100),
                'high_attention_ratio': float(subject_df['high_attention_ratio'].mean()),
                'attention_variance': float(subject_df['attention_variance'].mean()),
                
            }
            
            
            # Perfiles si están disponibles
            if 'profile' in subject_df.columns:
                profiles = subject_df['profile'].values
                dominant_profile = subject_df['profile'].mode()[0] if len(subject_df) > 0 else 0
                
                # Distribución - CONVERTIR EXPLÍCITAMENTE
                profile_counts = subject_df['profile'].value_counts()
                profile_distribution = {
                    int(p): float(count / len(subject_df))
                    for p, count in profile_counts.items()
                }
            else:
                print(f"     Columna 'profile' no encontrada, usando perfil por defecto")
                profiles = np.array([0] * len(subject_df))
                dominant_profile = 0
                profile_distribution = {0: 1.0}
            
            # Diagnóstico ADHD si está disponible
            if 'adhd_label' in subject_df.columns:
                adhd_label = int(subject_df['adhd_label'].iloc[0])  # CONVERTIR
                adhd_diagnosis = "ADHD" if adhd_label == 1 else "Control"
            else:
                adhd_diagnosis = "Unknown"
                adhd_label = -1
            
            subject_data[str(subject_id)] = {  # subject_id a string
                'adhd_label': int(adhd_label),  # CONVERTIR
                'adhd_diagnosis': str(adhd_diagnosis),  # CONVERTIR
                'metrics': metrics,  # Ya convertidos arriba
                'profiles': profiles.tolist() if isinstance(profiles, np.ndarray) else list(profiles),  # Array a list
                'dominant_profile': int(dominant_profile),  # CONVERTIR
                'profile_distribution': profile_distribution,  # Ya convertido arriba
                'n_sequences': int(len(subject_df))  # CONVERTIR
            }
        
        print(f"    Datos agregados: {len(subject_data)} sujetos")
        
        return subject_data
    
    def create_all_profiles(self,
                           subject_data: Dict,
                           adhd_predictions: pd.DataFrame = None,
                           visualize: bool = True) -> List[IntegratedProfile]:
        """
        Crear perfiles integrados para todos los sujetos
        
        Args:
            subject_data: Datos agregados por sujeto
            adhd_predictions: Predicciones ADHD (opcional)
            visualize: Si True, genera visualizaciones
            
        Returns:
            profiles: Lista de perfiles integrados
        """
        print("\n Creando perfiles integrados...")
        
        profiles = []
        
        for subject_id, data in subject_data.items():
            # Datos ADHD
            if adhd_predictions is not None and subject_id in adhd_predictions['subject_id'].values:
                pred_row = adhd_predictions[adhd_predictions['subject_id'] == subject_id].iloc[0]
                adhd_data = {
                    'diagnosis': str(pred_row.get('prediction', data['adhd_diagnosis'])),
                    'probability': float(pred_row.get('probability', 0.5))
                }
            else:
                # Usar datos de base
                if data['adhd_diagnosis'] == "ADHD":
                    adhd_prob = 0.85
                elif data['adhd_diagnosis'] == "Control":
                    adhd_prob = 0.15
                else:
                    adhd_prob = 0.5
                
                adhd_data = {
                    'diagnosis': str(data['adhd_diagnosis']),
                    'probability': float(adhd_prob)
                }
            
            # Datos temporales - CONVERTIR EXPLÍCITAMENTE
            temporal_data = {
                'profiles': data['profiles'] if isinstance(data['profiles'], list) else data['profiles'].tolist(),
                'dominant': int(data['dominant_profile']),
                'distribution': {int(k): float(v) for k, v in data['profile_distribution'].items()}
            }
            
            # Métricas de secuencia - CONVERTIR EXPLÍCITAMENTE
            sequence_metrics = {
                str(k): float(v) if isinstance(v, (int, float, np.integer, np.floating)) else v
                for k, v in data['metrics'].items()
            }
            
            # Crear perfil
            try:
                profile = self.integrator.create_integrated_profile(
                    subject_id=subject_id,
                    adhd_data=adhd_data,
                    temporal_data=temporal_data,
                    sequence_metrics=sequence_metrics
                )
                
                # Guardar
                self.integrator.save_profile(profile)
                profiles.append(profile)
                
                # Visualizar
                if visualize and len(profiles): 
                    viz_path = self.profiles_dir / 'visualizations' / f'{subject_id}_profile.png'
                    visualize_integrated_profile(profile, str(viz_path))
                
            except Exception as e:
                print(f"     Error creando perfil para {subject_id}: {e}")
        
        print(f"\n    Perfiles creados: {len(profiles)}/{len(subject_data)}")
        
        return profiles
    
    def analyze_cohort(self, profiles: List[IntegratedProfile]):
        """
        Análisis comparativo de cohorte (ADHD vs Control)
        """
        print("\n" + "="*80)
        print(" ANÁLISIS DE COHORTE")
        print("="*80)
        
        # Separar por diagnóstico
        adhd_profiles = [p for p in profiles if p.adhd_diagnosis == "ADHD"]
        control_profiles = [p for p in profiles if p.adhd_diagnosis == "Control"]
        
        print(f"\n   ADHD: {len(adhd_profiles)} sujetos")
        print(f"   Control: {len(control_profiles)} sujetos")
        
        # Comparar métricas
        self._compare_groups(adhd_profiles, control_profiles)
        
        # Análisis de perfiles dominantes
        self._analyze_profile_distribution(adhd_profiles, control_profiles)
        
        # Análisis de severidad
        self._analyze_severity(adhd_profiles, control_profiles)
        
        # Generar reporte
        self._generate_cohort_report(adhd_profiles, control_profiles)
    
    def _compare_groups(self, adhd_profiles: List, control_profiles: List):
        """Comparar métricas entre grupos"""
        print("\n COMPARACIÓN DE MÉTRICAS:")
        print("-"*80)
        
        metrics = [
            ('Severidad Global', 'severity_score'),
            ('Atención Sostenida', 'sustained_attention_index'),
            ('Autorregulación', 'self_regulation_index'),
            ('Déficit de Atención', 'attention_deficit_score'),
            ('Variabilidad', 'variability_score')
        ]
        
        print(f"\n{'Métrica':<25} {'ADHD':<15} {'Control':<15} {'Diferencia':<15}")
        print("-"*80)
        
        for name, attr in metrics:
            adhd_vals = [getattr(p, attr) for p in adhd_profiles]
            control_vals = [getattr(p, attr) for p in control_profiles]
            
            adhd_mean = np.mean(adhd_vals) if adhd_vals else 0
            control_mean = np.mean(control_vals) if control_vals else 0
            diff = adhd_mean - control_mean
            
            print(f"{name:<25} {adhd_mean:>10.2f}     {control_mean:>10.2f}     {diff:>+10.2f}")
    
    def _analyze_profile_distribution(self, adhd_profiles: List, control_profiles: List):
        """Analizar distribución de perfiles dominantes"""
        print("\n DISTRIBUCIÓN DE PERFILES DOMINANTES:")
        print("-"*80)
        
        profile_names = {
            0: "P0: Estable",
            1: "P1: Compensada",
            2: "P2: Variable",
            3: "P3: Lapsos",
            4: "P4: Hipoactivación"
        }
        
        print(f"\n{'Perfil':<25} {'ADHD':<15} {'Control':<15}")
        print("-"*80)
        
        for profile_id in range(5):
            adhd_count = sum(1 for p in adhd_profiles if p.dominant_profile == profile_id)
            control_count = sum(1 for p in control_profiles if p.dominant_profile == profile_id)
            
            adhd_pct = adhd_count / len(adhd_profiles) * 100 if adhd_profiles else 0
            control_pct = control_count / len(control_profiles) * 100 if control_profiles else 0
            
            print(f"{profile_names[profile_id]:<25} "
                  f"{adhd_count:>3} ({adhd_pct:>5.1f}%)   "
                  f"{control_count:>3} ({control_pct:>5.1f}%)")
    
    def _analyze_severity(self, adhd_profiles: List, control_profiles: List):
        """Analizar distribución de severidad"""
        print("\n DISTRIBUCIÓN DE SEVERIDAD:")
        print("-"*80)
        
        categories = ["Normal", "Leve", "Moderado", "Severo"]
        
        print(f"\n{'Categoría':<15} {'ADHD':<15} {'Control':<15}")
        print("-"*80)
        
        for category in categories:
            adhd_count = sum(1 for p in adhd_profiles if p.severity_category == category)
            control_count = sum(1 for p in control_profiles if p.severity_category == category)
            
            adhd_pct = adhd_count / len(adhd_profiles) * 100 if adhd_profiles else 0
            control_pct = control_count / len(control_profiles) * 100 if control_profiles else 0
            
            print(f"{category:<15} {adhd_count:>3} ({adhd_pct:>5.1f}%)   "
                  f"{control_count:>3} ({control_pct:>5.1f}%)")
    
    def _generate_cohort_report(self, adhd_profiles: List, control_profiles: List):
        """Generar reporte de cohorte"""
        report_path = self.results_dir / 'step7_cohort_analysis.txt'
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("="*80 + "\n")
            f.write("REPORTE DE ANÁLISIS DE COHORTE - PASO 7\n")
            f.write("Sistema de Perfiles Integrados ADHD\n")
            f.write("="*80 + "\n\n")
            
            f.write(f"TAMAÑO DE MUESTRA:\n")
            f.write(f"  ADHD: {len(adhd_profiles)} sujetos\n")
            f.write(f"  Control: {len(control_profiles)} sujetos\n")
            f.write(f"  Total: {len(adhd_profiles) + len(control_profiles)} sujetos\n\n")
            
            # Estadísticas descriptivas
            f.write("="*80 + "\n")
            f.write("ESTADÍSTICAS DESCRIPTIVAS\n")
            f.write("="*80 + "\n\n")
            
            metrics = [
                ('Severidad Global', 'severity_score'),
                ('Déficit de Atención', 'attention_deficit_score'),
                ('Variabilidad', 'variability_score'),
                ('Score de Recuperación', 'recovery_score'),
                ('Vigilancia', 'vigilance_score'),
                ('Atención Sostenida', 'sustained_attention_index'),
                ('Flexibilidad Cognitiva', 'cognitive_flexibility_index'),
                ('Autorregulación', 'self_regulation_index')
            ]
            
            f.write(f"{'Métrica':<30} {'Grupo':<10} {'Media':<10} {'SD':<10}\n")
            f.write("-"*80 + "\n")
            
            for name, attr in metrics:
                adhd_vals = [getattr(p, attr) for p in adhd_profiles]
                control_vals = [getattr(p, attr) for p in control_profiles]
                
                f.write(f"{name:<30} {'ADHD':<10} {np.mean(adhd_vals):>8.2f}  {np.std(adhd_vals):>8.2f}\n")
                f.write(f"{'':<30} {'Control':<10} {np.mean(control_vals):>8.2f}  {np.std(control_vals):>8.2f}\n")
                f.write("\n")
        
        print(f"\n    Reporte de cohorte: {report_path}")
    
    def run_full_pipeline(self,
                         adhd_predictions_file: str = None,
                         visualize_sample: bool = True) -> List[IntegratedProfile]:
        """
        Ejecutar pipeline completo del Paso 7
        
        Args:
            adhd_predictions_file: Archivo de predicciones ADHD (opcional)
            visualize_sample: Visualizar muestra de perfiles
            
        Returns:
            profiles: Lista de perfiles integrados creados
        """
        print("\n" + "="*80)
        print(" INICIANDO PIPELINE COMPLETO - PASO 7")
        print("="*80)
        
        # Paso 1: Cargar predicciones ADHD
        adhd_predictions = self.load_adhd_predictions(adhd_predictions_file)
        
        # Paso 2: Cargar perfiles microtemporales
        features_df = self.load_microtemporal_profiles()
        
        # Paso 3: Agregar datos por sujeto
        subject_data = self.aggregate_subject_data(features_df)
        
        # Paso 4: Crear perfiles integrados
        profiles = self.create_all_profiles(
            subject_data=subject_data,
            adhd_predictions=adhd_predictions,
            visualize=visualize_sample
        )
        
        # Paso 5: Análisis de cohorte
        if len(profiles) > 0:
            self.analyze_cohort(profiles)
        
        # Paso 6: Guardar resumen
        self._save_profiles_summary(profiles)
        
        print("\n" + "="*80)
        print(" PIPELINE DEL PASO 7 COMPLETADO")
        print("="*80)
        print(f"\n Perfiles creados: {len(profiles)}")
        print(f" Ubicación: {self.profiles_dir}")
        print(f"\nArchivos generados:")
        print(f"  • {len(profiles)} perfiles individuales (JSON + CSV)")
        print(f"  • Visualizaciones de muestra")
        print(f"  • Reporte de análisis de cohorte")
        print(f"  • Resumen consolidado")
        
        return profiles
    
    def _save_profiles_summary(self, profiles: List[IntegratedProfile]):
        """Guardar resumen consolidado de todos los perfiles"""
        summary_path = self.profiles_dir / 'profiles_summary.csv'
        
        summary_data = [p.to_dict() for p in profiles]
        df = pd.DataFrame(summary_data)
        df.to_csv(summary_path, index=False)
        
        print(f"\n    Resumen consolidado: {summary_path}")


def main():
    """
    Función principal
    """
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Paso 7: Sistema de Perfiles Integrados'
    )
    parser.add_argument(
        '--adhd-predictions',
        type=str,
        default=None,
        help='Archivo con predicciones ADHD del modelo DL'
    )
    parser.add_argument(
        '--no-viz',
        action='store_true',
        help='No generar visualizaciones de muestra'
    )
    parser.add_argument(
        '--base-dir',
        type=str,
        default='../EEG_ADHD_v5',
        help='Directorio base del proyecto'
    )
    
    args = parser.parse_args()
    
    # Crear pipeline
    pipeline = Step7IntegratedPipeline(base_dir=args.base_dir)
    
    # Ejecutar
    profiles = pipeline.run_full_pipeline(
        adhd_predictions_file=args.adhd_predictions,
        visualize_sample=not args.no_viz
    )
    
    if profiles and len(profiles) > 0:
        print("\n EJECUCIÓN COMPLETADA CON ÉXITO")
        return 0
    else:
        print("\n  No se pudieron crear perfiles")
        return 1


if __name__ == "__main__":
    sys.exit(main())
