"""
Módulo 1: Extractor de Features Microtemporales
================================================

Este módulo extrae features específicas para detectar patrones microtemporales
de atención en secuencias de ventanas EEG.

Features extraídas (~25 por secuencia):
- Nivel de atención estimado (TBR, alfa, beta/gamma)
- Ratio de tiempo en alta atención
- Estabilidad temporal
- Transiciones por minuto
- Tendencia temporal (declive/mejora)
- Capacidad de recuperación
- Métricas de complejidad
"""

import numpy as np
import h5py
import pandas as pd
from scipy import signal
from scipy.stats import linregress
from tqdm import tqdm
import warnings
from pathlib import Path
warnings.filterwarnings('ignore')


class MicrotemporalFeatureExtractor:
    """
    Extractor de features microtemporales para clasificación de perfiles
    """
    
    def __init__(self, sampling_rate=128, sequence_length=30):
        """
        Inicializar extractor
        
        Args:
            sampling_rate: Frecuencia de muestreo (Hz)
            sequence_length: Número de ventanas a analizar en secuencia
        """
        self.fs = sampling_rate
        self.sequence_length = sequence_length
        
        # Bandas de frecuencia para análisis espectral
        self.bands = {
            'delta': (0.5, 4),
            'theta': (4, 8),      # Biomarcador TDAH
            'alpha': (8, 13),     # Estado de alerta
            'beta': (13, 30),     # Atención sostenida
            'gamma': (30, 50)     # Procesamiento cognitivo
        }
        
        print(f"MicrotemporalFeatureExtractor inicializado")
        print(f"   Frecuencia de muestreo: {sampling_rate} Hz")
        print(f"   Longitud de secuencia: {sequence_length} ventanas")
    
    def estimate_attention_from_window(self, window):
        """
        Estimar nivel de atención de UNA ventana EEG
        
        Utiliza biomarcadores validados:
        - TBR (Theta/Beta Ratio): Principal indicador TDAH
        - Ratio alfa: Estado de alerta/relajación
        - Beta/Gamma: Actividad cognitiva
        - Variabilidad: Estabilidad de la señal
        
        Args:
            window: Array (n_channels, n_samples) o (n_samples, n_channels)
            
        Returns:
            attention_score: Score de atención [0, 1]
            features_dict: Diccionario con features intermedias
        """
        # Asegurar shape correcto
        if window.shape[0] == 19:  # (channels, samples)
            window = window.T  # → (samples, channels)
        
        features = {}
        
        # 1. ANÁLISIS ESPECTRAL
        try:
            freqs, psd = signal.welch(
                window, 
                fs=self.fs, 
                axis=0, 
                nperseg=min(256, window.shape[0])
            )
        except:
            # Si falla, retornar valores por defecto
            return 0.5, {'tbr': 2.0, 'alpha_ratio': 0.1, 'beta_gamma_ratio': 1.0, 
                        'signal_std': 50.0, 'attention_score': 0.5}
        
        # Calcular potencias por banda
        band_powers = {}
        for band_name, (low, high) in self.bands.items():
            idx = (freqs >= low) & (freqs < high)
            if np.sum(idx) > 0:
                band_powers[band_name] = np.mean(psd[idx, :])
            else:
                band_powers[band_name] = 0.0
        
        # 2. RATIO THETA/BETA (TBR) - Principal biomarcador TDAH
        tbr = band_powers['theta'] / (band_powers['beta'] + 1e-10)
        features['tbr'] = tbr
        
        # TBR alto (>2.5) → baja atención
        # TBR bajo (<1.5) → alta atención
        # TBR óptimo ≈ 1.5-2.0
        attention_from_tbr = 1.0 / (1.0 + np.exp(2.0 * (tbr - 2.0)))
        
        # 3. RATIO ALFA
        total_power = sum(band_powers.values()) + 1e-10
        alpha_ratio = band_powers['alpha'] / total_power
        features['alpha_ratio'] = alpha_ratio
        
        # Alfa moderado (8-12%) es óptimo para atención
        optimal_alpha = 0.10
        attention_from_alpha = 1.0 - min(abs(alpha_ratio - optimal_alpha) / optimal_alpha, 1.0)
        
        # 4. BETA/GAMMA RATIO
        beta_gamma_ratio = band_powers['beta'] / (band_powers['gamma'] + 1e-10)
        features['beta_gamma_ratio'] = beta_gamma_ratio
        
        # Beta alto relativo a gamma → buena atención
        attention_from_beta_gamma = beta_gamma_ratio / (beta_gamma_ratio + 2.0)
        
        # 5. VARIABILIDAD DE SEÑAL
        signal_std = np.mean(np.std(window, axis=0))
        features['signal_std'] = signal_std
        
        # Baja variabilidad → buena estabilidad atencional
        attention_from_stability = 1.0 / (1.0 + signal_std / 50.0)
        
        # 6. COMBINAR CON PESOS (basado en literatura TDAH)
        attention_score = (
            0.45 * attention_from_tbr +           # TBR es el más importante
            0.25 * attention_from_alpha +         # Estado de alerta
            0.20 * attention_from_beta_gamma +    # Actividad cognitiva
            0.10 * attention_from_stability       # Estabilidad
        )
        
        attention_score = np.clip(attention_score, 0, 1)
        features['attention_score'] = attention_score
        
        return attention_score, features
    
    def extract_sequence_features(self, attention_scores):
        """
        Extraer features de una secuencia temporal de scores de atención
        
        Calcula métricas que definen los perfiles:
        - Stable-High: >60% alta, estabilidad >0.7, <3 trans/min
        - Fluctuating: >5 trans/min, baja estabilidad
        - Low-Persistent: >50% baja, sin recuperación
        - Fatigable: declive gradual
        
        Args:
            attention_scores: Array de scores [0, 1]
            
        Returns:
            features: Dict con ~20 features de secuencia
        """
        if len(attention_scores) == 0:
            return self._default_sequence_features()
        
        features = {}
        
        # Binarizar atención usando mediana
        attention_scores = np.array(attention_scores)
        ATTENTION_THRESHOLD = 0.45
        attention_binary = (attention_scores > ATTENTION_THRESHOLD).astype(int)
        
        # ================================================================
        # 1. RATIO DE TIEMPO EN ALTA ATENCIÓN
        # ================================================================
        features['high_attention_ratio'] = np.mean(attention_binary)
        features['mean_attention'] = np.mean(attention_scores)
        features['std_attention'] = np.std(attention_scores)
        
        # ================================================================
        # 2. ESTABILIDAD TEMPORAL
        # ================================================================
        changes = np.where(np.diff(attention_binary) != 0)[0]
        
        if len(changes) > 0:
            # Longitudes de periodos continuos
            periods = np.diff(np.concatenate(([0], changes + 1, [len(attention_binary)])))
            features['stability'] = np.mean(periods) / len(attention_binary)
            features['max_stable_period'] = np.max(periods) / len(attention_binary)
            features['min_stable_period'] = np.min(periods) / len(attention_binary)
        else:
            # Sin cambios = máxima estabilidad
            features['stability'] = 1.0
            features['max_stable_period'] = 1.0
            features['min_stable_period'] = 1.0
        
        # ================================================================
        # 3. TRANSICIONES POR MINUTO (CRÍTICO PARA FLUCTUATING)
        # ================================================================
        n_transitions = len(changes)
        duration_minutes = len(attention_scores) / 60.0
        features['transitions_per_minute'] = n_transitions / (duration_minutes + 1e-10)
        features['total_transitions'] = n_transitions
        
        # ================================================================
        # 4. TENDENCIA TEMPORAL (CRÍTICO PARA FATIGABLE)
        # ================================================================
        if len(attention_scores) > 1:
            x = np.arange(len(attention_scores))
            slope, intercept, r_value, _, _ = linregress(x, attention_scores)
            
            features['temporal_slope'] = slope
            features['temporal_intercept'] = intercept
            features['temporal_r2'] = r_value ** 2
            
            # Comparar inicio vs final
            quarter = max(1, len(attention_scores) // 4)
            features['initial_attention'] = np.mean(attention_scores[:quarter])
            features['final_attention'] = np.mean(attention_scores[-quarter:])
            features['attention_decline'] = features['initial_attention'] - features['final_attention']
        else:
            features['temporal_slope'] = 0.0
            features['temporal_intercept'] = attention_scores[0] if len(attention_scores) > 0 else 0.5
            features['temporal_r2'] = 0.0
            features['initial_attention'] = attention_scores[0] if len(attention_scores) > 0 else 0.5
            features['final_attention'] = attention_scores[0] if len(attention_scores) > 0 else 0.5
            features['attention_decline'] = 0.0
        
        # ================================================================
        # 5. CAPACIDAD DE RECUPERACIÓN (CRÍTICO PARA LOW-PERSISTENT)
        # ================================================================
        low_periods = []
        recovery_periods = []
        in_low_period = False
        low_start = 0
        
        for i, val in enumerate(attention_binary):
            if val == 0 and not in_low_period:
                in_low_period = True
                low_start = i
            elif val == 1 and in_low_period:
                low_duration = i - low_start
                low_periods.append(low_duration)
                
                # ¿Hay recuperación sostenida? (al menos 3 puntos altos)
                if i + 3 <= len(attention_binary):
                    if np.mean(attention_binary[i:i+3]) > 0.66:
                        recovery_periods.append(low_duration)
                
                in_low_period = False
        
        if len(low_periods) > 0:
            features['avg_low_period_duration'] = np.mean(low_periods)
            features['max_low_period_duration'] = np.max(low_periods)
            features['num_low_periods'] = len(low_periods)
            
            if len(recovery_periods) > 0:
                features['recovery_rate'] = len(recovery_periods) / len(low_periods)
                features['avg_recovery_time'] = np.mean(recovery_periods)
            else:
                features['recovery_rate'] = 0.0
                features['avg_recovery_time'] = 0.0
        else:
            features['avg_low_period_duration'] = 0.0
            features['max_low_period_duration'] = 0.0
            features['num_low_periods'] = 0
            features['recovery_rate'] = 1.0  # Sin periodos bajos
            features['avg_recovery_time'] = 0.0
        
        # ================================================================
        # 6. VARIABILIDAD Y COMPLEJIDAD
        # ================================================================
        features['attention_variance'] = np.var(attention_scores)
        features['attention_range'] = np.ptp(attention_scores)
        
        # Complejidad: cambios de dirección
        if len(attention_scores) > 2:
            direction_changes = np.sum(np.diff(np.sign(np.diff(attention_scores))) != 0)
            features['complexity'] = direction_changes / max(1, len(attention_scores) - 2)
        else:
            features['complexity'] = 0.0
        
        # ================================================================
        # 7. PERCENTILES
        # ================================================================
        features['attention_p25'] = np.percentile(attention_scores, 25)
        features['attention_p50'] = np.percentile(attention_scores, 50)
        features['attention_p75'] = np.percentile(attention_scores, 75)
        features['attention_iqr'] = features['attention_p75'] - features['attention_p25']
        
        return features
    
    def _default_sequence_features(self):
        """Features por defecto para secuencias vacías"""
        return {
            'high_attention_ratio': 0.5,
            'mean_attention': 0.5,
            'std_attention': 0.0,
            'stability': 1.0,
            'max_stable_period': 1.0,
            'min_stable_period': 1.0,
            'transitions_per_minute': 0.0,
            'total_transitions': 0,
            'temporal_slope': 0.0,
            'temporal_intercept': 0.5,
            'temporal_r2': 0.0,
            'initial_attention': 0.5,
            'final_attention': 0.5,
            'attention_decline': 0.0,
            'avg_low_period_duration': 0.0,
            'max_low_period_duration': 0.0,
            'num_low_periods': 0,
            'recovery_rate': 1.0,
            'avg_recovery_time': 0.0,
            'attention_variance': 0.0,
            'attention_range': 0.0,
            'complexity': 0.0,
            'attention_p25': 0.5,
            'attention_p50': 0.5,
            'attention_p75': 0.5,
            'attention_iqr': 0.0
        }
    
    def extract_from_hdf5(self, input_file, output_file=None, time_scale=2):
        """
        Extraer features microtemporales de archivo HDF5
        
        Args:
            input_file: Ruta a preprocessed_data.h5
            output_file: Ruta de salida (CSV)
            time_scale: Escala temporal (segundos)
            
        Returns:
            output_file: Ruta del CSV generado
            features_df: DataFrame con features
        """
        print(f"\nEXTRACCIÓN DE FEATURES MICROTEMPORALES")
        print("=" * 80)
        print(f"   Input: {input_file}")
        print(f"   Escala: {time_scale}s")
        print(f"   Secuencia: {self.sequence_length} ventanas ({time_scale * self.sequence_length}s)")
        
        if output_file is None:
            output_file = str(Path(input_file).parent / 'microtemporal_features.csv')
        
        scale_key = f'scale_{time_scale}s'
        
        # Verificar archivo
        if not Path(input_file).exists():
            raise FileNotFoundError(f"No se encuentra: {input_file}")
        
        with h5py.File(input_file, 'r') as hf:
            if scale_key not in hf:
                raise ValueError(f"Escala {scale_key} no encontrada. Disponibles: {list(hf.keys())}")
            
            scale_group = hf[scale_key]
            subjects = list(scale_group.keys())
            
            print(f"   Sujetos: {len(subjects)}")
            
            # Contenedores para datos
            all_features = []
            all_labels = []
            all_subject_ids = []
            
            # Procesar cada sujeto
            for subject_id in tqdm(subjects, desc="Procesando sujetos"):
                subject_group = scale_group[subject_id]
                windows = subject_group['windows'][:]
                adhd_label = 1 if subject_group.attrs['class'] == 'ADHD' else 0
                
                n_windows = len(windows)
                
                # Procesar ventanas en secuencias
                for i in range(0, n_windows, self.sequence_length):
                    end_idx = min(i + self.sequence_length, n_windows)
                    sequence = windows[i:end_idx]
                    
                    if len(sequence) < 2:
                        continue  # Saltar secuencias muy cortas
                    
                    # Estimar atención para cada ventana
                    attention_scores = []
                    window_features_list = []
                    
                    for window in sequence:
                        att_score, win_feat = self.estimate_attention_from_window(window)
                        attention_scores.append(att_score)
                        window_features_list.append(win_feat)
                    
                    # Features de secuencia
                    sequence_features = self.extract_sequence_features(attention_scores)
                    
                    # Features promedio de ventanas individuales
                    window_avg_features = {
                        'mean_tbr': np.mean([f['tbr'] for f in window_features_list]),
                        'std_tbr': np.std([f['tbr'] for f in window_features_list]),
                        'mean_alpha_ratio': np.mean([f['alpha_ratio'] for f in window_features_list]),
                        'std_alpha_ratio': np.std([f['alpha_ratio'] for f in window_features_list]),
                        'mean_beta_gamma': np.mean([f['beta_gamma_ratio'] for f in window_features_list]),
                        'std_beta_gamma': np.std([f['beta_gamma_ratio'] for f in window_features_list]),
                        'mean_signal_std': np.mean([f['signal_std'] for f in window_features_list]),
                    }
                    
                    # Combinar todo
                    combined_features = {
                        **sequence_features,
                        **window_avg_features,
                        'sequence_length_actual': len(sequence),
                        'adhd_label': adhd_label,
                        'subject_id': subject_id
                    }
                    
                    all_features.append(combined_features)
                    all_labels.append(adhd_label)
                    all_subject_ids.append(subject_id)
        
        # Convertir a DataFrame
        features_df = pd.DataFrame(all_features)
        
        # Guardar
        features_df.to_csv(output_file, index=False)
        
        print(f"\nFeatures extraídas")
        print(f"   Shape: {features_df.shape}")
        print(f"   Features: {len(features_df.columns) - 2} (+ adhd_label + subject_id)")
        print(f"   Output: {output_file}")
        
        # Estadísticas básicas
        print(f"\nEstadísticas:")
        print(f"   Secuencias totales: {len(features_df):,}")
        print(f"   ADHD: {np.sum(features_df['adhd_label'] == 1):,}")
        print(f"   Control: {np.sum(features_df['adhd_label'] == 0):,}")
        
        return output_file, features_df


def main():
    """Ejemplo de uso"""
    
    print("\n" + "="*80)
    print("EXTRACTOR DE FEATURES MICROTEMPORALES")
    print("="*80 + "\n")
    
    # Configuración
    input_file = '../EEG_ADHD_v5/data/processed/preprocessed_data.h5'
    
    # Crear extractor
    extractor = MicrotemporalFeatureExtractor(
        sampling_rate=128,
        sequence_length=30 # 10 segundos de contexto con escala de 2s
    )
    
    # Extraer features
    output_file, features_df = extractor.extract_from_hdf5(
        input_file=input_file,
        time_scale=2
    )
    
    print(f"\nProceso completado")
    print(f"   Features guardadas: {output_file}")
    print(f"\nPróximo paso:")
    print(f"   python profile_classifier_trainer.py")


if __name__ == "__main__":
    main()
