"""
Fase 1
=================================================
1. Análisis Exploratorio
2. División por Escalas Temporales
3. Preprocesamiento
4. Extracción de Características microtemporales

"""
# Importar librerías
import pandas as pd
import h5py
from pathlib import Path
import warnings
warnings.filterwarnings('ignore')
# Importar modulos
from src.exploratory_analysis.exploratory_analysis import EEGExploratoryAnalysis
from src.temporal_scaling.temporal_scaler import TemporalScaler
from src.preprocessing.eeg_preprocessing import EEGPreprocessor
from microtemporal_feature_extractor import MicrotemporalFeatureExtractor

# Clase principal
class IntegratedEEGPipeline:
    """Pipeline integrado para análisis EEG-TDAH formato 10-20 de 19 canales"""
    
    def __init__(self, data_path: str, fs: int = 128):
        """
        Inicializar pipeline
        
        Args:
            data_path: Ruta al archivo CSV con datos EEG
            fs: Frecuencia de muestreo
        """
        base_dir='../EEG_ADHD_v5'
        self.data_path = data_path
        self.fs = fs
        self.channels = ['Fp1', 'Fp2', 'F3', 'F4', 'C3', 'C4', 'P3', 'P4', 
                        'O1', 'O2', 'F7', 'F8', 'T7', 'T8', 'P7', 'P8', 
                        'Fz', 'Cz', 'Pz']
        self.base_dir = Path(base_dir)
        self.data_dir = self.base_dir / 'data'
        self.processed_dir = self.data_dir / 'processed'
        self.models_dir = self.base_dir / 'models'
        self.results_dir = self.base_dir / 'results'
        
        # Crear directorios
        self.processed_dir.mkdir(parents=True, exist_ok=True)
        self.models_dir.mkdir(parents=True, exist_ok=True)
        self.results_dir.mkdir(parents=True, exist_ok=True)

        # Rutas de archivos intermedios
        self.scaled_data_path =  '../EEG_ADHD_v5/data/processed/multi_scale_data.h5'
        self.preprocessed_data_path = '../EEG_ADHD_v5/data/processed/preprocessed_data.h5'
        self.features_data_path = '../EEG_ADHD_v5/data/processed/features_data.h5'
        
        print(" Pipeline Integrado EEG-TDAH Inicializado")
        print(f"   Frecuencia de muestreo: {fs} Hz")
        print(f"   Canales: {len(self.channels)}")
    
    def run_full_pipeline(self, 
                         skip_exploratory: bool = True,
                         skip_scaling: bool =False,
                         skip_preprocessing: bool = False,
                         skip_features: bool = True ):
        """
        Ejecutar pipeline completo
        
        Args:
            skip_exploratory: Saltar análisis exploratorio
            skip_scaling: Saltar división por escalas
            skip_preprocessing: Saltar preprocesamiento
            skip_features: Saltar extracción de características
        """
        print("\n" + "="*80)
        print(" INICIANDO PIPELINE COMPLETO DE ANÁLISIS")
        print("="*80 + "\n")
        
        # Paso 1: Análisis Exploratorio
        if not skip_exploratory:
            print(" PASO 1: Análisis Exploratorio")
            print("-" * 80)
            self.step1_exploratory_analysis()
        else:
            print(" Saltando Paso 1: Análisis Exploratorio\n")
        
        # Paso 2: División por Escalas Temporales
        if not skip_scaling:
            print("\n PASO 2: División por Escalas Temporales")
            print("-" * 80)
            self.step2_temporal_scaling()
        else:
            print(" Saltando Paso 2: División por Escalas\n")
        
        # Paso 3: Preprocesamiento
        if not skip_preprocessing:
            print("\n PASO 3: Preprocesamiento de Señales")
            print("-" * 80)
            self.step3_preprocessing()
        else:
            print("  Saltando Paso 3: Preprocesamiento\n")
        
        # Paso 4: Extracción de Características (CORREGIDO)
        if not skip_features:
            print("\n PASO 4: Extracción de Características")
            print("-" * 80)
            self.step4_feature_extraction_fixed()
        else:
            print(" Saltando Paso 4: Extracción de Características\n")
        
        print("\n" + "="*80)
        print(" PIPELINE COMPLETADO EXITOSAMENTE")
        print("="*80)
        print("\n Archivos generados:")
        print(f"   • Datos escalados: {self.scaled_data_path}")
        print(f"   • Datos preprocesados: {self.preprocessed_data_path}")
        print(f"   • Características: {self.features_data_path}")
        
        
    
    def step1_exploratory_analysis(self):
        """Ejecutar análisis exploratorio"""
        
        analyzer = EEGExploratoryAnalysis(self.data_path, self.fs)
        
        try:
            analyzer.load_data()
            analyzer.basic_statistics()
            analyzer.analyze_signal_quality()
            
            # Solo generar visualizaciones si hay suficientes datos
            if len(analyzer.df) > 1000:
                analyzer.analyze_amplitude_distribution()
                analyzer.analyze_spectral_power()
                analyzer.analyze_temporal_patterns()
                analyzer.analyze_channel_correlations()
            
            analyzer.generate_summary_report()
            print(" Análisis exploratorio completado")
        except Exception as e:
            print(f"  Error en análisis exploratorio: {e}")
            print("   Continuando con el pipeline...")
    
    def step2_temporal_scaling(self):
        """Dividir por escalas temporales"""
        
        
        scaler = TemporalScaler(self.data_path, self.fs)
        
        try:
            scaled_data = scaler.process_all_scales(
                overlap=0.5,
                save_format='hdf5'
            )
            print(f" División por escalas completada")
            print(f"   Archivo guardado: {self.scaled_data_path}")
        except Exception as e:
            print(f" Error en división por escalas: {e}")
            raise
    
    def step3_preprocessing(self):
        """Preprocesar señales"""
        preprocessor = EEGPreprocessor(fs=self.fs)
        
        try:
            preprocessor.preprocess_dataset(
                input_file=str(self.scaled_data_path),
                output_file=str(self.preprocessed_data_path),
                apply_wavelet=True,
                apply_ica=True,  
                apply_car=True,
                normalize='zscore'
            )
            print(f" Preprocesamiento completado")
            print(f"   Archivo guardado: {self.preprocessed_data_path}")
        except Exception as e:
            print(f" Error en preprocesamiento: {e}")
            raise
    
    def step4_feature_extraction_fixed(self):
        
        print("   Extrayendo características de datos preprocesados...")
        
        try:
            extractor = MicrotemporalFeatureExtractor(
                        sampling_rate=128,
                        sequence_length=30
                    )
            features_file = self.processed_dir / 'microtemporal_features.csv'
            preprocessed_file = self.processed_dir / 'preprocessed_data.h5'
                    
            output_file, features_df = extractor.extract_from_hdf5(
                input_file=str(preprocessed_file),
                output_file=str(features_file),
                time_scale=2
            )
                    
            print(f"\nPASO 1 COMPLETADO")
            print(f"   Features: {output_file}")
            print(f"   Shape: {features_df.shape}")
                
        except Exception as e:
            print(f"\n Error en extracción de features: {e}")
            import traceback
            traceback.print_exc()
            return False
        
    
    def _generate_feature_statistics(self):
        """Generar estadísticas de características extraídas"""
        print("\n    Generando estadísticas de características...")
        
        stats = []
        
        with h5py.File(self.features_data_path, 'r') as hf:
            for scale_key in hf.keys():
                scale_group = hf[scale_key]
                
                n_subjects = len(scale_group.keys())
                
                # Obtener número de características del primer sujeto
                first_subject = list(scale_group.keys())[0]
                n_features = scale_group[first_subject].attrs.get('n_features', 0)
                
                # Contar ventanas por clase
                adhd_windows = 0
                control_windows = 0
                
                for subject_id in scale_group.keys():
                    subject_group = scale_group[subject_id]
                    class_label = subject_group.attrs['class']
                    n_windows = subject_group['features'].shape[0]
                    
                    if class_label == 'ADHD':
                        adhd_windows += n_windows
                    else:
                        control_windows += n_windows
                
                stats.append({
                    'Escala': scale_key,
                    'Sujetos': n_subjects,
                    'Características': n_features,
                    'Ventanas ADHD': adhd_windows,
                    'Ventanas Control': control_windows,
                    'Total Ventanas': adhd_windows + control_windows
                })
        
        stats_df = pd.DataFrame(stats)
        print(f"\n{stats_df.to_string(index=False)}")
        
        # Guardar estadísticas generales
        stats_df.to_csv('../EEG_ADHD_v5/results/feature_statistics.csv', index=False)
        print(f"\n    Estadísticas guardadas: {'../EEG_ADHD_v5/results/feature_statistics.csv'}")


def main():
    """Función principal"""
    print("\n" + "="*80)
    print(" SISTEMA INTEGRADO DE ANÁLISIS EEG")
    print("   Deep Learning Híbrido + Análisis Micro-Temporal + Machine Learning + Perfiles ")
    print("   + Recomendación de Estrategias Educativas")
    print("="*80 + "\n")
    
    # Configurar ruta de datos
    # IMPORTANTE: Ajustar esta ruta a donde estén los datos reales
    data_path = '../EEG_ADHD_v5/data/raw/adhdata.csv'
    
    # Crear pipeline
    pipeline = IntegratedEEGPipeline(str(data_path), fs=128)
    
    # Ejecutar pipeline completo
    try:
        pipeline.run_full_pipeline(
            skip_exploratory=False,  # Cambiar a True para saltar análisis exploratorio
            skip_scaling=False,      # Cambiar a True si ya se ejecutó
            skip_preprocessing=False, # Cambiar a True si ya se ejecutó
            skip_features=False      # Cambiar a True si ya se ejecutó
        )    
    except Exception as e:
        print(f"\n Error en pipeline: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n" + "="*80)
    print(" FASE 1PROCESO COMPLETADO")
    print("="*80)
    


if __name__ == "__main__":
    main()
