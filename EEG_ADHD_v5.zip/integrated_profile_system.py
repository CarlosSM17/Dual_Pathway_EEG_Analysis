"""
Módulo 7: Sistema de Perfiles Integrados ADHD
==============================================

Sistema de Perfiles:
1. Diagnóstico ADHD (probabilidad, clasificación binaria)
2. Perfil microtemporal dominante (0-4)
3. Distribución temporal de perfiles
4. Métricas de severidad clínica
5. Índices de funcionamiento cognitivo
6. Recomendaciones preliminares


"""

import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field
from pathlib import Path
import json
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Para visualización
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.patches import Rectangle


class NumpyEncoder(json.JSONEncoder):
    """
    Encoder JSON personalizado para tipos numpy
    
    Convierte automáticamente:
    - numpy.int64 → int
    - numpy.float64 → float
    - numpy.ndarray → list
    """
    def default(self, obj):
        if isinstance(obj, (np.integer, np.int64, np.int32, np.int16, np.int8)):
            return int(obj)
        elif isinstance(obj, (np.floating, np.float64, np.float32, np.float16)):
            return float(obj)
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, np.bool_):
            return bool(obj)
        return super(NumpyEncoder, self).default(obj)


@dataclass
class IntegratedProfile:
    """
    Perfil integrado completo de un sujeto
    
    Combina información diagnóstica y temporal para
    caracterización multidimensional del ADHD.
    """
    
    # Identificación
    subject_id: str
    
    # ===================================================================
    # DIAGNÓSTICO ADHD 
    # ===================================================================
    adhd_diagnosis: str  # "ADHD" o "Control"
    adhd_probability: float  # Probabilidad ADHD [0, 1]
    adhd_confidence: str  # "Alta", "Media", "Baja"
    
    # ===================================================================
    # PERFIL MICROTEMPORAL 
    # ===================================================================
    dominant_profile: int  # Perfil más frecuente (0-4)
    dominant_profile_name: str  # Nombre del perfil
    profile_distribution: Dict[int, float]  # % tiempo en cada perfil
    profile_stability: float  # Qué tan estable es el perfil [0, 1]
    
    # ===================================================================
    # MÉTRICAS DE SEVERIDAD CLÍNICA
    # ===================================================================
    severity_score: float  # Score global de severidad [0, 100]
    severity_category: str  # "Leve", "Moderado", "Severo", "Normal"
    
    # Componentes de severidad
    attention_deficit_score: float  # [0, 100]
    variability_score: float  # [0, 100]
    recovery_score: float  # [0, 100] (inverso: alto = buena recuperación)
    vigilance_score: float  # [0, 100]
    
    # ===================================================================
    # ÍNDICES DE FUNCIONAMIENTO
    # ===================================================================
    sustained_attention_index: float  # Capacidad de atención sostenida [0, 1]
    cognitive_flexibility_index: float  # Flexibilidad cognitiva [0, 1]
    self_regulation_index: float  # Autorregulación [0, 1]
    
    # ===================================================================
    # PATRONES TEMPORALES
    # ===================================================================
    time_on_task_pattern: str  # "Declive", "Estable", "Mejora"
    transition_frequency: str  # "Baja", "Moderada", "Alta"
    recovery_capacity: str  # "Excelente", "Buena", "Moderada", "Deficiente"
    
    # ===================================================================
    # RIESGO Y PRONÓSTICO
    # ===================================================================
    academic_impact_risk: str  # "Bajo", "Moderado", "Alto"
    intervention_urgency: str  # "Baja", "Media", "Alta", "Urgente"
    response_to_intervention_prediction: str  # "Favorable", "Moderada", "Limitada"
    
    # ===================================================================
    # DATOS RAW (para análisis posterior)
    # ===================================================================
    raw_metrics: Dict = field(default_factory=dict)
    sequence_data: Dict = field(default_factory=dict)
    
    # Metadata
    n_sequences: int = 0
    analysis_timestamp: str = ""
    
    def to_dict(self) -> Dict:
        """
        Convertir perfil a diccionario con tipos Python nativos
        
        Convierte numpy.int64, numpy.float64, etc. a int, float nativos
        para compatibilidad con JSON.
        """
        def convert_value(val):
            """Convertir valor a tipo Python nativo - Versión robusta"""
            # None se mantiene como None
            if val is None:
                return None
            
            # Tipos numpy integer
            if isinstance(val, (np.integer, np.int64, np.int32, np.int16, np.int8)):
                return int(val)
            
            # Tipos numpy float
            elif isinstance(val, (np.floating, np.float64, np.float32, np.float16)):
                return float(val)
            
            # Numpy bool
            elif isinstance(val, np.bool_):
                return bool(val)
            
            # Numpy array
            elif isinstance(val, np.ndarray):
                return val.tolist()
            
            # Diccionario - recursivo
            elif isinstance(val, dict):
                return {convert_value(k): convert_value(v) for k, v in val.items()}
            
            # Lista o tupla - recursivo
            elif isinstance(val, (list, tuple)):
                return [convert_value(item) for item in val]
            
            # Tipos Python nativos - pasar directo
            elif isinstance(val, (int, float, str, bool)):
                return val
            
            # Otros - intentar convertir a string
            else:
                try:
                    return str(val)
                except:
                    return None
        
        return {
            'subject_id': str(self.subject_id),
            'adhd_diagnosis': str(self.adhd_diagnosis),
            'adhd_probability': float(self.adhd_probability),
            'adhd_confidence': str(self.adhd_confidence),
            'dominant_profile': int(self.dominant_profile),
            'dominant_profile_name': str(self.dominant_profile_name),
            'profile_distribution': convert_value(self.profile_distribution),
            'profile_stability': float(self.profile_stability),
            'severity_score': float(self.severity_score),
            'severity_category': str(self.severity_category),
            'attention_deficit_score': float(self.attention_deficit_score),
            'variability_score': float(self.variability_score),
            'recovery_score': float(self.recovery_score),
            'vigilance_score': float(self.vigilance_score),
            'sustained_attention_index': float(self.sustained_attention_index),
            'cognitive_flexibility_index': float(self.cognitive_flexibility_index),
            'self_regulation_index': float(self.self_regulation_index),
            'time_on_task_pattern': str(self.time_on_task_pattern),
            'transition_frequency': str(self.transition_frequency),
            'recovery_capacity': str(self.recovery_capacity),
            'academic_impact_risk': str(self.academic_impact_risk),
            'intervention_urgency': str(self.intervention_urgency),
            'response_to_intervention_prediction': str(self.response_to_intervention_prediction),
            'n_sequences': int(self.n_sequences),
            'analysis_timestamp': str(self.analysis_timestamp)
        }
    
    def to_json(self, filepath: str):
        """Guardar perfil como JSON con soporte para tipos numpy"""
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(self.to_dict(), f, indent=2, ensure_ascii=False, cls=NumpyEncoder)
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'IntegratedProfile':
        """Crear perfil desde diccionario"""
        return cls(**data)


class ProfileIntegrator:
    """
    Integrador de perfiles ADHD
    
    Combina diagnóstico DL + perfiles microtemporales para
    generar perfil clínico completo por sujeto.
    """
    
    def __init__(self, base_dir: str = '../EEG_ADHD_v5'):
        """
        Inicializar integrador
        
        Args:
            base_dir: Directorio base del proyecto
        """
        self.base_dir = Path(base_dir)
        self.results_dir = self.base_dir / 'results'
        self.profiles_dir = self.base_dir / 'profiles'
        
        # Crear directorios
        self.profiles_dir.mkdir(parents=True, exist_ok=True)
        
        # Definiciones de perfiles (del Paso 6)
        self.profile_names = {
            0: "Atención Sostenida Estable",
            1: "Fluctuación Moderada Compensada",
            2: "Variabilidad Alta con Recuperación",
            3: "Lapsos Frecuentes de Atención",
            4: "Hipoactivación Sostenida"
        }
        
        print(" ProfileIntegrator Inicializado")
        print(f"   Directorio base: {base_dir}")
        print(f"   Perfiles guardados en: {self.profiles_dir}")
    
    def create_integrated_profile(self,
                                 subject_id: str,
                                 adhd_data: Dict,
                                 temporal_data: Dict,
                                 sequence_metrics: Dict) -> IntegratedProfile:
        """
        Crear perfil integrado para un sujeto
        
        Args:
            subject_id: ID del sujeto
            adhd_data: Datos del diagnóstico ADHD
                - diagnosis: "ADHD" o "Control"
                - probability: float [0, 1]
            temporal_data: Datos de perfiles temporales
                - profiles: array con perfiles por secuencia
                - dominant: perfil dominante
                - distribution: distribución de perfiles
            sequence_metrics: Métricas de análisis temporal
                - vigilance: análisis de vigilancia
                - recovery: análisis de recuperación
                - variability: análisis de variabilidad
                - time_on_task: análisis temporal
                
        Returns:
            IntegratedProfile: Perfil completo del sujeto
        """
        from datetime import datetime
        
        print(f"\n Creando perfil integrado para: {subject_id}")
        
        # ================================================================
        # 1. DIAGNÓSTICO ADHD
        # ================================================================
        adhd_diagnosis = adhd_data.get('diagnosis', 'Unknown')
        adhd_probability = adhd_data.get('probability', 0.5)
        
        # Calcular confianza del diagnóstico
        if adhd_probability > 0.80 or adhd_probability < 0.20:
            adhd_confidence = "Alta"
        elif adhd_probability > 0.65 or adhd_probability < 0.35:
            adhd_confidence = "Media"
        else:
            adhd_confidence = "Baja"
        
        # ================================================================
        # 2. PERFIL MICROTEMPORAL
        # ================================================================
        profiles = temporal_data.get('profiles', [])
        dominant_profile = int(temporal_data.get('dominant', 0))  # Convertir a int nativo
        
        # Calcular distribución
        if len(profiles) > 0:
            profile_counts = {}
            for p in profiles:
                # Convertir a int nativo para evitar int64
                p_int = int(p) if not isinstance(p, int) else p
                profile_counts[p_int] = profile_counts.get(p_int, 0) + 1
            
            profile_distribution = {
                int(p): float(count / len(profiles))  # Convertir explícitamente
                for p, count in profile_counts.items()
            }
        else:
            profile_distribution = {int(dominant_profile): 1.0}
        
        # Calcular estabilidad (concentración en perfil dominante)
        profile_stability = profile_distribution.get(dominant_profile, 0.0)
        
        # ================================================================
        # 3. MÉTRICAS DE SEVERIDAD CLÍNICA
        # ================================================================
        severity_metrics = self._calculate_severity_metrics(
            adhd_probability=adhd_probability,
            dominant_profile=dominant_profile,
            sequence_metrics=sequence_metrics
        )
        
        # ================================================================
        # 4. ÍNDICES DE FUNCIONAMIENTO
        # ================================================================
        functioning_indices = self._calculate_functioning_indices(
            sequence_metrics=sequence_metrics,
            profile_distribution=profile_distribution
        )
        
        # ================================================================
        # 5. PATRONES TEMPORALES
        # ================================================================
        temporal_patterns = self._classify_temporal_patterns(
            sequence_metrics=sequence_metrics
        )
        
        # ================================================================
        # 6. RIESGO Y PRONÓSTICO
        # ================================================================
        risk_assessment = self._assess_risk_and_prognosis(
            adhd_probability=adhd_probability,
            severity_score=severity_metrics['severity_score'],
            dominant_profile=dominant_profile,
            recovery_capacity=temporal_patterns['recovery_capacity']
        )
        
        # ================================================================
        # 7. CREAR PERFIL INTEGRADO
        # ================================================================
        profile = IntegratedProfile(
            subject_id=str(subject_id),
            
            # Diagnóstico ADHD
            adhd_diagnosis=str(adhd_diagnosis),
            adhd_probability=float(adhd_probability),
            adhd_confidence=str(adhd_confidence),
            
            # Perfil microtemporal
            dominant_profile=int(dominant_profile),
            dominant_profile_name=str(self.profile_names[int(dominant_profile)]),
            profile_distribution=profile_distribution,  # Ya convertido
            profile_stability=float(profile_stability),
            
            # Severidad
            severity_score=float(severity_metrics['severity_score']),
            severity_category=str(severity_metrics['severity_category']),
            attention_deficit_score=float(severity_metrics['attention_deficit_score']),
            variability_score=float(severity_metrics['variability_score']),
            recovery_score=float(severity_metrics['recovery_score']),
            vigilance_score=float(severity_metrics['vigilance_score']),
            
            # Funcionamiento
            sustained_attention_index=float(functioning_indices['sustained_attention_index']),
            cognitive_flexibility_index=float(functioning_indices['cognitive_flexibility_index']),
            self_regulation_index=float(functioning_indices['self_regulation_index']),
            
            # Patrones temporales
            time_on_task_pattern=str(temporal_patterns['time_on_task_pattern']),
            transition_frequency=str(temporal_patterns['transition_frequency']),
            recovery_capacity=str(temporal_patterns['recovery_capacity']),
            
            # Riesgo
            academic_impact_risk=str(risk_assessment['academic_impact_risk']),
            intervention_urgency=str(risk_assessment['intervention_urgency']),
            response_to_intervention_prediction=str(risk_assessment['response_to_intervention_prediction']),
            
            # Metadata
            n_sequences=int(len(profiles)) if len(profiles) > 0 else 0,
            analysis_timestamp=str(datetime.now().isoformat())
        )
        
        print(f"    Perfil creado")
        print(f"      Diagnóstico: {profile.adhd_diagnosis} ({profile.adhd_probability:.2f})")
        print(f"      Perfil: {profile.dominant_profile_name}")
        print(f"      Severidad: {profile.severity_category} ({profile.severity_score:.1f})")
        
        return profile
    
    def _calculate_severity_metrics(self,
                                    adhd_probability: float,
                                    dominant_profile: int,
                                    sequence_metrics: Dict) -> Dict:
        """
        Calcular métricas de severidad clínica
        
        Basado en:
        - Barkley (1997): Severidad multidimensional
        - DuPaul et al. (2016): Escalas de severidad ADHD
        """
        # Extraer métricas de secuencia
        if sequence_metrics:
            mean_attention = sequence_metrics.get('mean_attention', 0.35)
            variability_cv = sequence_metrics.get('coefficient_of_variation', 0.15)
            recovery_rate = sequence_metrics.get('recovery_rate', 0.5)
            vigilance_decline = abs(sequence_metrics.get('decrement_percentage', 0))
        else:
            # Valores por defecto conservadores
            mean_attention = 0.35
            variability_cv = 0.15
            recovery_rate = 0.5
            vigilance_decline = 10.0
        
        # 1. Score de déficit de atención (inverso de nivel medio)
        # Rango óptimo: 0.40-0.50, Problemático: <0.30
        attention_deficit_score = max(0, min(100, (1 - mean_attention / 0.50) * 100))
        
        # 2. Score de variabilidad (IIV)
        # CV normal: <0.15, ADHD: >0.20
        variability_score = min(100, (variability_cv / 0.30) * 100)
        
        # 3. Score de recuperación (inverso: bajo = problemático)
        # Recuperación buena: >0.75, Deficiente: <0.25
        recovery_score = max(0, min(100, (1 - recovery_rate) * 100))
        
        # 4. Score de vigilancia (declive)
        # Declive normal: <10%, ADHD: >20%
        vigilance_score = min(100, (vigilance_decline / 30.0) * 100)
        
        # Score global de severidad (promedio ponderado)
        # Pesos basados en importancia clínica (Barkley, 1997)
        severity_score = (
            0.30 * attention_deficit_score +
            0.25 * variability_score +
            0.25 * recovery_score +
            0.20 * vigilance_score
        )
        
        # Ajuste por perfil dominante (perfiles peores aumentan severidad)
        profile_severity_multiplier = {
            0: 0.5,   # Estable: reduce severidad
            1: 0.8,   # Compensada: leve reducción
            2: 1.0,   # Variable: sin cambio
            3: 1.3,   # Lapsos: aumenta severidad
            4: 1.5    # Hipoactivación: máximo aumento
        }
        
        severity_score *= profile_severity_multiplier.get(dominant_profile, 1.0)
        severity_score = min(100, severity_score)
        
        # Categorizar severidad
        if severity_score < 25:
            severity_category = "Normal"
        elif severity_score < 45:
            severity_category = "Leve"
        elif severity_score < 70:
            severity_category = "Moderado"
        else:
            severity_category = "Severo"
        
        return {
            'severity_score': severity_score,
            'severity_category': severity_category,
            'attention_deficit_score': attention_deficit_score,
            'variability_score': variability_score,
            'recovery_score': recovery_score,
            'vigilance_score': vigilance_score
        }
    
    def _calculate_functioning_indices(self,
                                      sequence_metrics: Dict,
                                      profile_distribution: Dict) -> Dict:
        """
        Calcular índices de funcionamiento cognitivo
        
        Basado en:
        - Fair et al. (2012): Redes cerebrales y función cognitiva
        - Castellanos et al. (2006): Caracterización dimensional
        """
        if sequence_metrics:
            mean_attention = sequence_metrics.get('mean_attention', 0.35)
            stability = sequence_metrics.get('stability', 0.5)
            recovery_rate = sequence_metrics.get('recovery_rate', 0.5)
            transitions_per_min = sequence_metrics.get('transitions_per_minute', 10)
        else:
            mean_attention = 0.35
            stability = 0.5
            recovery_rate = 0.5
            transitions_per_min = 10
        
        # 1. Índice de atención sostenida
        # Combina nivel medio y estabilidad
        sustained_attention = (0.7 * (mean_attention / 0.50) + 
                              0.3 * stability)
        sustained_attention = max(0, min(1, sustained_attention))
        
        # 2. Índice de flexibilidad cognitiva
        # Basado en diversidad de perfiles (entropía)
        # Alta flexibilidad = puede transitar entre estados efectivamente
        if len(profile_distribution) > 0:
            probs = list(profile_distribution.values())
            entropy = -sum(p * np.log2(p + 1e-10) for p in probs if p > 0)
            max_entropy = np.log2(5)  # 5 perfiles posibles
            cognitive_flexibility = entropy / max_entropy
        else:
            cognitive_flexibility = 0.5
        
        # Ajustar por transiciones (demasiadas = desregulación)
        if transitions_per_min > 20:  # Excesivo
            cognitive_flexibility *= 0.7
        
        # 3. Índice de autorregulación
        # Combina estabilidad y capacidad de recuperación
        self_regulation = (0.6 * stability + 0.4 * recovery_rate)
        self_regulation = max(0, min(1, self_regulation))
        
        return {
            'sustained_attention_index': sustained_attention,
            'cognitive_flexibility_index': cognitive_flexibility,
            'self_regulation_index': self_regulation
        }
    
    def _classify_temporal_patterns(self, sequence_metrics: Dict) -> Dict:
        """
        Clasificar patrones temporales
        """
        if not sequence_metrics:
            return {
                'time_on_task_pattern': "Desconocido",
                'transition_frequency': "Desconocida",
                'recovery_capacity': "Desconocida"
            }
        
        # 1. Patrón de tiempo en tarea
        decline_pct = sequence_metrics.get('decrement_percentage', 0)
        if decline_pct < -5:  # Mejora
            time_on_task = "Mejora"
        elif abs(decline_pct) < 10:  # Estable
            time_on_task = "Estable"
        elif decline_pct < 20:  # Declive moderado
            time_on_task = "Declive Moderado"
        else:  # Declive pronunciado
            time_on_task = "Declive Pronunciado"
        
        # 2. Frecuencia de transiciones
        transitions = sequence_metrics.get('transitions_per_minute', 10)
        if transitions < 6:
            transition_freq = "Baja"
        elif transitions < 15:
            transition_freq = "Moderada"
        else:
            transition_freq = "Alta"
        
        # 3. Capacidad de recuperación
        recovery_rate = sequence_metrics.get('recovery_rate', 0.5)
        if recovery_rate > 0.75:
            recovery_capacity = "Excelente"
        elif recovery_rate > 0.50:
            recovery_capacity = "Buena"
        elif recovery_rate > 0.25:
            recovery_capacity = "Moderada"
        else:
            recovery_capacity = "Deficiente"
        
        return {
            'time_on_task_pattern': time_on_task,
            'transition_frequency': transition_freq,
            'recovery_capacity': recovery_capacity
        }
    
    def _assess_risk_and_prognosis(self,
                                   adhd_probability: float,
                                   severity_score: float,
                                   dominant_profile: int,
                                   recovery_capacity: str) -> Dict:
        """
        Evaluar riesgo de impacto académico y pronóstico
        
        Basado en:
        - DuPaul et al. (2013): Impacto académico del ADHD
        - Loe & Feldman (2007): Outcomes académicos a largo plazo
        """
        # 1. Riesgo de impacto académico
        # Factores: probabilidad ADHD, severidad, perfil
        
        risk_score = (
            adhd_probability * 40 +  # Diagnóstico
            severity_score * 0.40 +  # Severidad
            (dominant_profile / 4.0) * 20  # Perfil (0-4 normalizado)
        )
        
        if risk_score < 30:
            academic_risk = "Bajo"
        elif risk_score < 55:
            academic_risk = "Moderado"
        else:
            academic_risk = "Alto"
        
        # 2. Urgencia de intervención
        if severity_score > 70 or dominant_profile == 4:
            urgency = "Urgente"
        elif severity_score > 50 or dominant_profile == 3:
            urgency = "Alta"
        elif severity_score > 30:
            urgency = "Media"
        else:
            urgency = "Baja"
        
        # 3. Predicción de respuesta a intervención
        # Factores protectores: buena recuperación, perfil no tan severo
        
        if recovery_capacity in ["Excelente", "Buena"] and dominant_profile <= 2:
            intervention_response = "Favorable"
        elif recovery_capacity == "Moderada" or dominant_profile == 2:
            intervention_response = "Moderada"
        else:
            intervention_response = "Limitada"
        
        return {
            'academic_impact_risk': academic_risk,
            'intervention_urgency': urgency,
            'response_to_intervention_prediction': intervention_response
        }
    
    def save_profile(self, profile: IntegratedProfile):
        """Guardar perfil integrado con manejo robusto de errores"""
        try:
            # JSON para procesamiento
            json_path = self.profiles_dir / f'{profile.subject_id}_profile.json'
            profile.to_json(str(json_path))
            
            # CSV para análisis
            csv_path = self.profiles_dir / f'{profile.subject_id}_profile.csv'
            df = pd.DataFrame([profile.to_dict()])
            df.to_csv(csv_path, index=False)
            
            print(f"    Perfil guardado:")
            print(f"      JSON: {json_path}")
            print(f"      CSV: {csv_path}")
            
        except Exception as e:
            print(f"     Error guardando perfil para {profile.subject_id}: {e}")
            
            # Diagnóstico: mostrar qué campos tienen problemas
            print(f"   Diagnóstico de tipos:")
            profile_dict = profile.to_dict()
            for key, value in profile_dict.items():
                value_type = type(value).__name__
                if 'int64' in value_type or 'float64' in value_type:
                    print(f"        {key}: {value_type}")
                    
            # Intentar guardar diccionario directamente con encoder
            try:
                with open(json_path, 'w', encoding='utf-8') as f:
                    json.dump(profile_dict, f, indent=2, ensure_ascii=False, cls=NumpyEncoder)
                print(f"    Guardado con NumpyEncoder como backup")
            except Exception as e2:
                print(f"    Error incluso con NumpyEncoder: {e2}")
                raise


def visualize_integrated_profile(profile: IntegratedProfile, 
                                save_path: str = None):
    """
    Visualización comprehensiva del perfil integrado
    """
    fig = plt.figure(figsize=(16, 10))
    gs = fig.add_gridspec(3, 3, hspace=0.3, wspace=0.3)
    
    # Título principal
    fig.suptitle(f'Perfil Integrado ADHD - Sujeto: {profile.subject_id}',
                fontsize=16, fontweight='bold', y=0.98)
    
    # ===================================================================
    # 1. Panel de Diagnóstico (Superior Izquierdo)
    # ===================================================================
    ax1 = fig.add_subplot(gs[0, 0])
    
    # Gauge de probabilidad ADHD
    prob = profile.adhd_probability
    colors = ['green' if prob < 0.3 else 'orange' if prob < 0.7 else 'red']
    
    ax1.barh(['ADHD'], [prob], color=colors[0], alpha=0.7)
    ax1.set_xlim([0, 1])
    ax1.set_xlabel('Probabilidad', fontsize=10)
    ax1.set_title('Diagnóstico ADHD', fontweight='bold', fontsize=11)
    ax1.text(prob, 0, f'{prob:.2f}', ha='left', va='center', 
            fontsize=12, fontweight='bold')
    ax1.axvline(x=0.5, color='gray', linestyle='--', alpha=0.5)
    
    # Texto de diagnóstico
    diag_text = f"{profile.adhd_diagnosis}\nConfianza: {profile.adhd_confidence}"
    ax1.text(0.5, -0.5, diag_text, ha='center', va='top',
            transform=ax1.transData, fontsize=10,
            bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
    
    # ===================================================================
    # 2. Distribución de Perfiles (Superior Centro)
    # ===================================================================
    ax2 = fig.add_subplot(gs[0, 1])
    
    profile_names_short = ["P0:Estable", "P1:Comp.", "P2:Var.", "P3:Lapsos", "P4:Hipo."]
    profile_values = [profile.profile_distribution.get(i, 0) * 100 for i in range(5)]
    colors = ['green', 'yellowgreen', 'yellow', 'orange', 'red']
    
    bars = ax2.bar(range(5), profile_values, color=colors, alpha=0.7)
    
    # Resaltar perfil dominante
    bars[profile.dominant_profile].set_edgecolor('black')
    bars[profile.dominant_profile].set_linewidth(3)
    
    ax2.set_xticks(range(5))
    ax2.set_xticklabels(profile_names_short, rotation=45, ha='right', fontsize=8)
    ax2.set_ylabel('% Tiempo', fontsize=10)
    ax2.set_title('Distribución de Perfiles Microtemporales', fontweight='bold', fontsize=11)
    ax2.set_ylim([0, 100])
    
    # ===================================================================
    # 3. Métricas de Severidad (Superior Derecho)
    # ===================================================================
    ax3 = fig.add_subplot(gs[0, 2])
    
    metrics = {
        'Atención': profile.attention_deficit_score,
        'Variabilidad': profile.variability_score,
        'Recuperación': profile.recovery_score,
        'Vigilancia': profile.vigilance_score
    }
    
    angles = np.linspace(0, 2 * np.pi, len(metrics), endpoint=False)
    values = list(metrics.values())
    values += values[:1]  # Cerrar el polígono
    angles = np.concatenate([angles, [angles[0]]])
    
    ax3 = plt.subplot(gs[0, 2], projection='polar')
    ax3.plot(angles, values, 'o-', linewidth=2, color='red', alpha=0.7)
    ax3.fill(angles, values, alpha=0.25, color='red')
    ax3.set_xticks(angles[:-1])
    ax3.set_xticklabels(metrics.keys(), fontsize=9)
    ax3.set_ylim([0, 100])
    ax3.set_title('Scores de Severidad', fontweight='bold', fontsize=11, pad=20)
    ax3.grid(True)
    
    # ===================================================================
    # 4. Índices de Funcionamiento (Centro Izquierdo)
    # ===================================================================
    ax4 = fig.add_subplot(gs[1, 0])
    
    functioning = {
        'Atención\nSostenida': profile.sustained_attention_index,
        'Flexibilidad\nCognitiva': profile.cognitive_flexibility_index,
        'Auto-\nregulación': profile.self_regulation_index
    }
    
    y_pos = np.arange(len(functioning))
    values = list(functioning.values())
    colors_func = ['red' if v < 0.4 else 'orange' if v < 0.7 else 'green' 
                   for v in values]
    
    ax4.barh(y_pos, values, color=colors_func, alpha=0.7)
    ax4.set_yticks(y_pos)
    ax4.set_yticklabels(functioning.keys(), fontsize=9)
    ax4.set_xlabel('Índice [0-1]', fontsize=10)
    ax4.set_xlim([0, 1])
    ax4.set_title('Índices de Funcionamiento', fontweight='bold', fontsize=11)
    
    for i, v in enumerate(values):
        ax4.text(v + 0.02, i, f'{v:.2f}', va='center', fontsize=9)
    
    # ===================================================================
    # 5. Resumen de Severidad (Centro Centro)
    # ===================================================================
    ax5 = fig.add_subplot(gs[1, 1])
    ax5.axis('off')
    
    # Gauge circular de severidad
    severity_norm = profile.severity_score / 100
    
    # Fondo
    circle_bg = plt.Circle((0.5, 0.5), 0.35, color='lightgray', alpha=0.3)
    ax5.add_patch(circle_bg)
    
    # Severidad
    color_severity = 'green' if severity_norm < 0.25 else 'yellow' if severity_norm < 0.45 else 'orange' if severity_norm < 0.70 else 'red'
    circle_severity = plt.Circle((0.5, 0.5), 0.35 * severity_norm, 
                                 color=color_severity, alpha=0.7)
    ax5.add_patch(circle_severity)
    
    # Texto
    ax5.text(0.5, 0.5, f'{profile.severity_score:.0f}', 
            ha='center', va='center', fontsize=36, fontweight='bold')
    ax5.text(0.5, 0.3, profile.severity_category,
            ha='center', va='center', fontsize=14, fontweight='bold')
    ax5.set_xlim([0, 1])
    ax5.set_ylim([0, 1])
    ax5.set_title('Severidad Global', fontweight='bold', fontsize=11, y=0.95)
    
    # ===================================================================
    # 6. Patrones Temporales (Centro Derecho)
    # ===================================================================
    ax6 = fig.add_subplot(gs[1, 2])
    ax6.axis('off')
    
    patterns_text = f"""
PATRONES TEMPORALES

Tiempo en Tarea:
  {profile.time_on_task_pattern}

Transiciones:
  {profile.transition_frequency}

Recuperación:
  {profile.recovery_capacity}

Estabilidad Perfil:
  {profile.profile_stability:.2%}
"""
    
    ax6.text(0.1, 0.9, patterns_text, fontsize=10, 
            verticalalignment='top', fontfamily='monospace',
            bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.3))
    
    # ===================================================================
    # 7. Evaluación de Riesgo (Inferior Izquierdo)
    # ===================================================================
    ax7 = fig.add_subplot(gs[2, 0])
    ax7.axis('off')
    
    risk_text = f"""
EVALUACIÓN DE RIESGO

Impacto Académico:
  {profile.academic_impact_risk}

Urgencia Intervención:
  {profile.intervention_urgency}

Respuesta a Intervención:
  {profile.response_to_intervention_prediction}
"""
    
    # Color de fondo según urgencia
    if profile.intervention_urgency == "Urgente":
        bgcolor = 'salmon'
    elif profile.intervention_urgency == "Alta":
        bgcolor = 'orange'
    elif profile.intervention_urgency == "Media":
        bgcolor = 'yellow'
    else:
        bgcolor = 'lightgreen'
    
    ax7.text(0.1, 0.9, risk_text, fontsize=10,
            verticalalignment='top', fontfamily='monospace',
            bbox=dict(boxstyle='round', facecolor=bgcolor, alpha=0.5))
    
    # ===================================================================
    # 8. Interpretación Clínica (Inferior Centro y Derecho)
    # ===================================================================
    ax8 = fig.add_subplot(gs[2, 1:])
    ax8.axis('off')
    
    interpretation = generate_clinical_interpretation(profile)
    
    ax8.text(0.05, 0.95, "INTERPRETACIÓN CLÍNICA:", fontsize=11, 
            fontweight='bold', verticalalignment='top')
    ax8.text(0.05, 0.85, interpretation, fontsize=9,
            verticalalignment='top', wrap=True,
            bbox=dict(boxstyle='round', facecolor='lightyellow', alpha=0.5))
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        print(f"    Visualización guardada: {save_path}")
    else:
        plt.show()
    
    plt.close()


def generate_clinical_interpretation(profile: IntegratedProfile) -> str:
    """
    Generar interpretación clínica textual del perfil
    """
    lines = []
    
    # Diagnóstico
    if profile.adhd_diagnosis == "ADHD":
        lines.append(f"El sujeto presenta un diagnóstico de TDAH con probabilidad {profile.adhd_probability:.0%} "
                    f"(confianza {profile.adhd_confidence.lower()}). ")
    else:
        lines.append(f"El perfil sugiere un patrón de control (probabilidad TDAH: {profile.adhd_probability:.0%}). ")
    
    # Perfil microtemporal
    lines.append(f"El perfil microtemporal dominante es '{profile.dominant_profile_name}' "
                f"({profile.profile_stability:.0%} del tiempo), ")
    
    if profile.dominant_profile <= 1:
        lines.append("indicando capacidad de atención sostenida relativamente preservada. ")
    elif profile.dominant_profile == 2:
        lines.append("caracterizado por variabilidad atencional significativa pero con capacidad de recuperación. ")
    elif profile.dominant_profile == 3:
        lines.append("mostrando lapsos atencionales frecuentes que impactan el funcionamiento. ")
    else:
        lines.append("evidenciando hipoactivación sostenida que requiere intervención inmediata. ")
    
    # Severidad
    lines.append(f"\n\nLa severidad global es {profile.severity_category.lower()} ({profile.severity_score:.0f}/100), ")
    
    if profile.severity_score < 30:
        lines.append("con impacto limitado en el funcionamiento diario. ")
    elif profile.severity_score < 55:
        lines.append("sugiriendo necesidad de monitoreo y estrategias de apoyo. ")
    elif profile.severity_score < 75:
        lines.append("requiriendo intervención estructurada y posible valoración farmacológica. ")
    else:
        lines.append("demandando intervención intensiva inmediata. ")
    
    # Funcionamiento
    if profile.sustained_attention_index < 0.4:
        lines.append("La atención sostenida está significativamente comprometida. ")
    
    if profile.self_regulation_index < 0.4:
        lines.append("Se observan dificultades marcadas en autorregulación. ")
    
    # Pronóstico
    lines.append(f"\n\nEl riesgo de impacto académico es {profile.academic_impact_risk.lower()}. ")
    
    if profile.response_to_intervention_prediction == "Favorable":
        lines.append("Se anticipa respuesta favorable a intervenciones bien implementadas, "
                    "especialmente considerando la capacidad de recuperación preservada.")
    elif profile.response_to_intervention_prediction == "Moderada":
        lines.append("Se espera respuesta moderada a intervenciones, requiriendo seguimiento cercano "
                    "y posibles ajustes en las estrategias.")
    else:
        lines.append("La respuesta a intervenciones puede ser limitada, sugiriendo necesidad de "
                    "enfoques multimodales intensivos y valoración multidisciplinaria.")
    
    return ''.join(lines)


if __name__ == "__main__":
    print("\n" + "="*80)
    print(" SISTEMA DE PERFILES INTEGRADOS - TEST")
    print("="*80)
    
    # Test con datos sintéticos
    integrator = ProfileIntegrator(base_dir='./test_profiles')
    
    # Datos de ejemplo
    adhd_data = {
        'diagnosis': 'ADHD',
        'probability': 0.85
    }
    
    temporal_data = {
        'profiles': [2, 2, 3, 2, 2, 1, 2, 3, 2, 2],
        'dominant': 2,
        'distribution': {2: 0.7, 3: 0.2, 1: 0.1}
    }
    
    sequence_metrics = {
        'mean_attention': 0.33,
        'coefficient_of_variation': 0.22,
        'recovery_rate': 0.35,
        'decrement_percentage': 18.5,
        'stability': 0.25,
        'transitions_per_minute': 16
    }
    
    # Crear perfil
    profile = integrator.create_integrated_profile(
        subject_id='test_001',
        adhd_data=adhd_data,
        temporal_data=temporal_data,
        sequence_metrics=sequence_metrics
    )
    
    # Guardar
    integrator.save_profile(profile)
    
    # Visualizar
    visualize_integrated_profile(profile, save_path='./test_profiles/test_001_visualization.png')
    
    print("\n Test completado")
    print(f"   Perfil guardado en: ./test_profiles/")
