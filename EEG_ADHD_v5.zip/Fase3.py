"""
FASE 3: Perfiles Microtemporales
============================================================

1. Clasificación de perfiles microtemporales
2. Predicción de evolución temporal (HMM)
3. Análisis avanzado de secuencias
4. Generación de reportes 
"""

import sys
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Dict, List, Tuple
import warnings
warnings.filterwarnings('ignore')

# Importar módulos del Paso 6
from microtemporal_profile_system import (
    MicrotemporalProfileClassifier,
    TemporalEvolutionPredictor
)
from temporal_sequence_analyzer import (
    TemporalSequenceAnalyzer,
    analyze_subject_sequence,
    visualize_temporal_analysis
)


class Step6IntegratedPipeline:
    
    
    def __init__(self, base_dir: str = '../EEG_ADHD_v5'):
        """
        Inicializar pipeline
        
        Args:
            base_dir: Directorio base del proyecto
        """
        self.base_dir = Path(base_dir)
        self.data_dir = self.base_dir / 'data' / 'processed'
        self.models_dir = self.base_dir / 'models'
        self.results_dir = self.base_dir / 'results'
        
        # Crear directorios si no existen
        self.models_dir.mkdir(parents=True, exist_ok=True)
        self.results_dir.mkdir(parents=True, exist_ok=True)
        
        # Archivos principales
        self.features_file = self.data_dir / 'microtemporal_features.csv'
        
        print("\n" + "="*80)
        print("PASO 6: SISTEMA DE PERFILES MICROTEMPORALES")
        print("   Pipeline Integrado - Clasificación y Predicción")
        print("="*80)
        print(f"\nDirectorio base: {base_dir}")
        print(f"Características: {self.features_file}")
    
    def verify_prerequisites(self) -> bool:
        """
        Verificar que existen los archivos necesarios y datos válidos
        
        Returns:
            success: True si todos los archivos existen
        """
        print("\nVerificando prerequisitos...")
        
        required_files = {
            'Características microtemporales': self.features_file
        }
        
        all_exist = True
        for name, path in required_files.items():
            if path.exists():
                size_mb = path.stat().st_size / (1024 * 1024)
                print(f"   {name}: {path.name} ({size_mb:.2f} MB)")
                
                # Verificar contenido del archivo
                try:
                    df = pd.read_csv(path)
                    print(f"  Registros: {len(df)}")
                    print(f"  Columnas: {len(df.columns)}")
                    
                    # Verificar columnas críticas
                    required_cols = ['mean_attention', 'stability', 'transitions_per_minute', 
                                   'recovery_rate', 'subject_id']
                    missing_cols = [col for col in required_cols if col not in df.columns]
                    
                    if missing_cols:
                        print(f"       Columnas faltantes: {missing_cols}")
                    else:
                        print(f"      Columnas críticas: ")
                    
                    # Verificar sujetos
                    n_subjects = df['subject_id'].nunique()
                    print(f"      Sujetos únicos: {n_subjects}")
                    
                    # Verificar secuencias por sujeto
                    seq_per_subject = df.groupby('subject_id').size()
                    print(f"      Secuencias/sujeto: {seq_per_subject.mean():.1f} (promedio)")
                    print(f"      Rango: [{seq_per_subject.min()}, {seq_per_subject.max()}]")
                    
                    # Advertencia si secuencias muy cortas
                    subjects_short = (seq_per_subject < 5).sum()
                    if subjects_short > 0:
                        print(f"        {subjects_short} sujetos con <5 secuencias (análisis temporal limitado)")
                    
                except Exception as e:
                    print(f"       Error leyendo archivo: {e}")
                    
            else:
                print(f"    {name}: {path} (NO EXISTE)")
                all_exist = False
        
        if not all_exist:
            print("\n  Faltan archivos necesarios. Ejecute primero:")
            print("   1. Fase 1 (extracción de características)")
            print("   2. Opcional: Fase 2 (modelo híbrido DL)")
        
        return all_exist
    
    def run_full_pipeline(self, 
                         skip_training: bool =True,
                         generate_reports: bool = True,
                         n_cv_folds: int = 5) -> Dict:
        """
        Ejecutar pipeline completo del Paso 6
        
        Args:
            skip_training: Si True, carga modelos existentes
            generate_reports: Si True, genera reportes detallados
            n_cv_folds: Número de folds para validación cruzada
            
        Returns:
            results: Diccionario con todos los resultados
        """
        print("\n" + "="*80)
        print("INICIANDO PIPELINE COMPLETO - PASO 6")
        print("="*80)
        
        # Verificar prerequisitos
        if not self.verify_prerequisites():
            return None
        
        results = {}
        
        # ====================================================================
        # PASO 6.1: CLASIFICADOR DE PERFILES
        # ====================================================================
        print("\n" + "="*80)
        print("PASO 6.1: CLASIFICADOR DE PERFILES MICROTEMPORALES")
        print("="*80)
        
        classifier = MicrotemporalProfileClassifier(base_dir=str(self.base_dir))
        
        # Cargar datos
        df, profile_labels = classifier.load_and_prepare_data(str(self.features_file))
        results['data'] = df
        results['profile_labels'] = profile_labels
        
        # **CRÍTICO**: Guardar DataFrame con columna 'profile' para Fase 4
        if 'profile' in df.columns:
            print(f"\n Guardando features con perfiles asignados...")
            df.to_csv(str(self.features_file), index=False)
            print(f"    Archivo actualizado: {self.features_file}")
            print(f"   Columnas guardadas: {', '.join(df.columns.tolist())}")
            print(f"   Distribución de perfiles guardada:")
            for i in range(5):
                count = (df['profile'] == i).sum()
                pct = count / len(df) * 100
                print(f"      Perfil {i}: {count} ({pct:.1f}%)")
        else:
            print(f"\n    ADVERTENCIA: Columna 'profile' no encontrada en DataFrame")
            print(f"   Fase 4 no podrá usar perfiles correctamente")
        
        if not skip_training:
            # Entrenar con validación cruzada sujeto-wise
            print("\n Entrenando clasificador...")
            classification_results = classifier.train_with_subject_wise_cv(
                df, n_folds=n_cv_folds
            )
            results['classification'] = classification_results
            
            # Guardar resultados
            self._save_classification_results(classification_results)
        else:
            print("\n  Saltando entrenamiento, cargando modelo existente...")
            classifier.load_model()
            results['classification'] = {'status': 'loaded_existing'}
        
        results['classifier'] = classifier
        
        # ====================================================================
        # PASO 6.2: PREDICTOR DE EVOLUCIÓN TEMPORAL (HMM)
        # ====================================================================
        print("\n" + "="*80)
        print(" PASO 6.2: PREDICTOR DE EVOLUCIÓN TEMPORAL (HMM)")
        print("="*80)
        
        predictor = TemporalEvolutionPredictor(n_states=5)
        
        # Crear secuencias por sujeto
        sequences, lengths, subject_ids = self._create_subject_sequences(df)
        
        if not skip_training:
            # Entrenar HMM
            predictor.fit_hmm(sequences, lengths)
            
            # Analizar patrones de transición
            transition_analysis = predictor.analyze_transition_patterns(sequences)
            results['transitions'] = transition_analysis
            
            # Guardar HMM
            hmm_path = self.models_dir / 'temporal_evolution_hmm.pkl'
            predictor.save_model(str(hmm_path))
        else:
            print("\n  Cargando HMM existente...")
            hmm_path = self.models_dir / 'temporal_evolution_hmm.pkl'
            if hmm_path.exists():
                predictor.load_model(str(hmm_path))
                transition_analysis = predictor.analyze_transition_patterns(sequences)
                results['transitions'] = transition_analysis
            else:
                print("     HMM no encontrado, entrenando nuevo modelo...")
                predictor.fit_hmm(sequences, lengths)
                transition_analysis = predictor.analyze_transition_patterns(sequences)
                results['transitions'] = transition_analysis
                predictor.save_model(str(hmm_path))
        
        results['predictor'] = predictor
        
        # ====================================================================
        # PASO 6.3: ANÁLISIS AVANZADO DE SECUENCIAS
        # ====================================================================
        print("\n" + "="*80)
        print(" PASO 6.3: ANÁLISIS AVANZADO DE SECUENCIAS TEMPORALES")
        print("="*80)
        
        # Analizar secuencias individuales
        # Usar df_loaded que tiene los perfiles asignados
        if 'data' in results:
            df_for_analysis = results['data']
        else:
            df_for_analysis = df
        
        # Si subject_ids está vacío o no se creó, obtener de df
        if 'subject_ids' not in locals() or not subject_ids:
            subject_ids = df_for_analysis['subject_id'].unique().tolist()
            print(f"   Obteniendo subject_ids del DataFrame: {len(subject_ids)} sujetos")

        subject_ids = df_for_analysis['subject_id'].unique().tolist()
        sequence_analyses = self._analyze_all_sequences(df_for_analysis, subject_ids)
        results['sequence_analyses'] = sequence_analyses
        
        # ====================================================================
        # PASO 6.4: GENERACIÓN DE REPORTES
        # ====================================================================
        if generate_reports:
            print("\n" + "="*80)
            print(" PASO 6.4: GENERACIÓN DE REPORTES CLÍNICOS")
            print("="*80)
            
            self._generate_comprehensive_reports(
                df=df,
                classification_results=results.get('classification'),
                transition_analysis=results.get('transitions'),
                sequence_analyses=sequence_analyses,
                subject_ids=subject_ids
            )
        
        print("\n" + "="*80)
        print(" PIPELINE DEL PASO 6 COMPLETADO EXITOSAMENTE")
        print("="*80)
        
        self._print_summary(results)
        
        return results
    
    def _create_subject_sequences(self, df: pd.DataFrame) -> Tuple[List, List, List]:
        """
        Crear secuencias temporales por sujeto
        
        Returns:
            sequences: Lista de secuencias de perfiles
            lengths: Longitudes de cada secuencia
            subject_ids: IDs de sujetos correspondientes
        """
        print("\n Creando secuencias temporales por sujeto...")
        
        sequences = []
        lengths = []
        subject_ids = []
        
        for subject_id in df['subject_id'].unique():
            subject_data = df[df['subject_id'] == subject_id].sort_index()
            sequence = subject_data['profile'].values
            
            if len(sequence) >= 5:  # Mínimo 5 ventanas
                sequences.append(sequence)
                lengths.append(len(sequence))
                subject_ids.append(subject_id)
        
        print(f"   Secuencias creadas: {len(sequences)}")
        print(f"   Longitud promedio: {np.mean(lengths):.1f} ventanas")
        print(f"   Rango: [{min(lengths)}, {max(lengths)}] ventanas")
        
        return sequences, lengths, subject_ids
    
    def _analyze_all_sequences(self, df: pd.DataFrame, 
                               subject_ids: List) -> Dict:
        """
        Analizar todas las secuencias individuales
        """
        print("\n Analizando secuencias temporales individuales...")
        
        analyzer = TemporalSequenceAnalyzer()
        analyses = {}
        
        # Obtener todos los sujetos únicos del DataFrame si subject_ids está vacío
        if not subject_ids or len(subject_ids) == 0:
            all_subjects = df['subject_id'].unique()
            print(f"   Usando todos los sujetos del DataFrame: {len(all_subjects)}")
        else:
            all_subjects = subject_ids
        
        # Analizar muestra de sujetos (primeros 10 o todos si hay menos)
        n_to_analyze = min(121, len(all_subjects))
        sample_subjects = all_subjects[:n_to_analyze]
        
        print(f"   Analizando muestra de {n_to_analyze} sujetos...")
        
        for subject_id in sample_subjects:
            subject_data = df[df['subject_id'] == subject_id].sort_index()
            
            # Extraer secuencia de atención
            if 'mean_attention' not in subject_data.columns:
                print(f"    Columna 'mean_attention' no encontrada para {subject_id}")
                continue
            
            attention_sequence = subject_data['mean_attention'].values
            
            # Requerir al menos 5 ventanas (reducido de 10 para mayor flexibilidad)
            if len(attention_sequence) >= 5:
                try:
                    analysis = analyze_subject_sequence(attention_sequence, subject_id)
                    analyses[subject_id] = analysis
                    print(f"   {subject_id}: {len(attention_sequence)} ventanas")
                except Exception as e:
                    print(f"    Error analizando {subject_id}: {e}")
            else:
                print(f"    {subject_id}: Solo {len(attention_sequence)} ventanas (mínimo 5)")
        
        print(f"\n   Analizados exitosamente: {len(analyses)} sujetos")
        
        if len(analyses) == 0:
            print(f"     No se pudo analizar ningún sujeto")
            print(f"   Verificar:")
            print(f"      - Columna 'mean_attention' existe en DataFrame")
            print(f"      - Sujetos tienen suficientes secuencias (≥5)")
            print(f"      - subject_id está correctamente definido")
            return analyses
        
        # Generar visualizaciones para muestra (primeros 3)
        print("\nGenerando visualizaciones de muestra...")
        n_viz = min(3, len(analyses))
        subjects_example = ['v10p','v131','v108','v12p','v246']
        for i, (subjects_example, analysis) in enumerate(list(analyses.items())):
            try:
                subject_data = df[df['subject_id'] == subjects_example]
                attention_seq = subject_data['mean_attention'].values
                
                save_path = self.results_dir / f'temporal_analysis_{subjects_example}.png'
                visualize_temporal_analysis(attention_seq, analysis, str(save_path))
                print(f"   Visualización {i+1}/{n_viz}: {save_path.name}")
            except Exception as e:
                print(f"    Error generando visualización para {subject_id}: {e}")
        
        return analyses
    
    def _save_classification_results(self, results: Dict):
        """Guardar resultados de clasificación"""
        results_df = pd.DataFrame([
            {
                'Model': model_name,
                'Accuracy_Mean': data['accuracy_mean'],
                'Accuracy_Std': data['accuracy_std']
            }
            for model_name, data in results.items()
        ])
        
        results_path = self.results_dir / 'step6_classification_results.csv'
        results_df.to_csv(results_path, index=False)
        print(f"\n Resultados guardados: {results_path}")
    
    def _generate_comprehensive_reports(self, **kwargs):
        """Generar reportes comprehensivos"""
        print("\n Generando reportes clínicos...")
        
        # Reporte de distribución de perfiles
        self._generate_profile_distribution_report(kwargs['df'])
        
        # Reporte de transiciones
        if 'transition_analysis' in kwargs and kwargs['transition_analysis']:
            self._generate_transition_report(kwargs['transition_analysis'])
        
        # Reporte de análisis temporal
        if 'sequence_analyses' in kwargs and kwargs['sequence_analyses']:
            self._generate_temporal_analysis_report(kwargs['sequence_analyses'])
        
        print("   Reportes generados")
    
    def _generate_profile_distribution_report(self, df: pd.DataFrame):
        """Generar reporte de distribución de perfiles"""
        report_path = self.results_dir / 'step6_profile_distribution.txt'
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("="*80 + "\n")
            f.write("REPORTE DE DISTRIBUCIÓN DE PERFILES MICROTEMPORALES\n")
            f.write("="*80 + "\n\n")
            
            f.write("DISTRIBUCIÓN GLOBAL:\n")
            f.write("-"*40 + "\n")
            
            profile_names = {
                0: "Atención Sostenida Estable",
                1: "Fluctuación Moderada Compensada",
                2: "Variabilidad Alta con Recuperación",
                3: "Lapsos Frecuentes de Atención",
                4: "Hipoactivación Sostenida"
            }
            
            for profile_id in range(5):
                count = (df['profile'] == profile_id).sum()
                pct = count / len(df) * 100
                f.write(f"\nPerfil {profile_id}: {profile_names[profile_id]}\n")
                f.write(f"   Frecuencia: {count} ({pct:.1f}%)\n")
            
            if 'adhd_label' in df.columns:
                f.write("\n\nDISTRIBUCIÓN POR DIAGNÓSTICO:\n")
                f.write("-"*40 + "\n")
                
                for adhd in [0, 1]:
                    adhd_name = "Control" if adhd == 0 else "ADHD"
                    subset = df[df['adhd_label'] == adhd]
                    
                    f.write(f"\n{adhd_name} (n={len(subset)}):\n")
                    for profile_id in range(5):
                        count = (subset['profile'] == profile_id).sum()
                        pct = count / len(subset) * 100 if len(subset) > 0 else 0
                        f.write(f"   Perfil {profile_id}: {count} ({pct:.1f}%)\n")
        
        print(f"   Reporte de distribución: {report_path}")
    
    def _generate_transition_report(self, transition_analysis: Dict):
        """Generar reporte de transiciones"""
        report_path = self.results_dir / 'step6_transition_analysis.txt'
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("="*80 + "\n")
            f.write("REPORTE DE ANÁLISIS DE TRANSICIONES TEMPORALES\n")
            f.write("="*80 + "\n\n")
            
            f.write("PROBABILIDADES DE RECUPERACIÓN:\n")
            f.write("-"*40 + "\n")
            for i, prob in enumerate(transition_analysis['recovery_probabilities']):
                f.write(f"Perfil {i} → Estados Mejores: {prob:.3f}\n")
            
            f.write("\n\nPROBABILIDADES DE DETERIORO:\n")
            f.write("-"*40 + "\n")
            for i, prob in enumerate(transition_analysis['deterioration_probabilities']):
                f.write(f"Perfil {i} → Estados Peores: {prob:.3f}\n")
            
            f.write("\n\nMATRIZ DE TRANSICIÓN EMPÍRICA:\n")
            f.write("-"*40 + "\n")
            matrix = transition_analysis['transition_matrix_empirical']
            
            f.write("\n   De/A:  ")
            for i in range(5):
                f.write(f"  P{i}   ")
            f.write("\n")
            
            for i in range(5):
                f.write(f"   P{i}: ")
                for j in range(5):
                    f.write(f" {matrix[i,j]:.3f} ")
                f.write("\n")
        
        print(f"   Reporte de transiciones: {report_path}")
    
    def _generate_temporal_analysis_report(self, sequence_analyses: Dict):
        """Generar reporte de análisis temporal"""
        report_path = self.results_dir / 'step6_temporal_patterns.txt'
        
        if not sequence_analyses or len(sequence_analyses) == 0:
            print(f"    No hay análisis de secuencias para generar reporte")
            # Crear reporte vacío indicando el problema
            with open(report_path, 'w', encoding='utf-8') as f:
                f.write("="*80 + "\n")
                f.write("REPORTE DE PATRONES TEMPORALES\n")
                f.write("="*80 + "\n\n")
                f.write("  NO SE PUDO GENERAR ANÁLISIS\n\n")
                f.write("Posibles causas:\n")
                f.write("- Secuencias muy cortas (< 5 ventanas)\n")
                f.write("- Columna 'mean_attention' ausente\n")
                f.write("- Datos insuficientes por sujeto\n")
            return
        
        with open(report_path, 'w', encoding='utf-8') as f:
            f.write("="*80 + "\n")
            f.write("REPORTE DE PATRONES TEMPORALES\n")
            f.write("="*80 + "\n")
            f.write(f"\nTotal de sujetos analizados: {len(sequence_analyses)}\n")
            f.write("\n" + "="*80 + "\n")
            
            for subject_id, analysis in sequence_analyses.items():
                f.write(f"\nSUJETO: {subject_id}\n")
                f.write("-"*40 + "\n")
                
                f.write(f"\nVigilancia:\n")
                f.write(f"   Patrón: {analysis['vigilance']['pattern']}\n")
                f.write(f"   Declive: {analysis['vigilance']['decrement_percentage']:.1f}%\n")
                f.write(f"   Severidad: {analysis['vigilance']['severity']}\n")
                
                f.write(f"\nRecuperación:\n")
                f.write(f"   Clasificación: {analysis['recovery']['recovery_classification']}\n")
                f.write(f"   Lapsos: {analysis['recovery']['n_lapses']}\n")
                f.write(f"   Tasa de éxito: {analysis['recovery']['recovery_success_rate']:.2f}\n")
                
                f.write(f"\nVariabilidad:\n")
                f.write(f"   Clasificación: {analysis['variability']['iiv_classification']}\n")
                f.write(f"   CV: {analysis['variability']['coefficient_of_variation']:.3f}\n")
                f.write(f"   MSSD: {analysis['variability']['mssd']:.5f}\n")
                
                f.write(f"\nTiempo en Tarea:\n")
                f.write(f"   Patrón: {analysis['time_on_task']['pattern']}\n")
                f.write(f"   Cambio Early-Late: {analysis['time_on_task']['early_vs_late_change_pct']:.1f}%\n")
                
                f.write("\n" + "="*80 + "\n")
        
        print(f"   Reporte de patrones: {report_path}")
    
    def _print_summary(self, results: Dict):
        """Imprimir resumen de resultados"""
        print("\n RESUMEN DE RESULTADOS:")
        print("-"*80)
        
        if 'classification' in results and 'status' not in results['classification']:
            best_model = max(results['classification'].keys(), 
                           key=lambda k: results['classification'][k]['accuracy_mean'])
            best_acc = results['classification'][best_model]['accuracy_mean']
            print(f"\nClasificación de Perfiles:")
            print(f"   Mejor modelo: {best_model}")
            print(f"   Accuracy: {best_acc:.3f}")
        
        if 'data' in results:
            df = results['data']
            print(f"\nDistribución de Perfiles:")
            for i in range(5):
                count = (df['profile'] == i).sum()
                pct = count / len(df) * 100
                print(f"   Perfil {i}: {count} ({pct:.1f}%)")
        
        print("\n Archivos generados:")
        print(f"   • {self.models_dir / 'profile_classifier.pkl'}")
        print(f"   • {self.models_dir / 'temporal_evolution_hmm.pkl'}")
        print(f"   • {self.results_dir / 'step6_*.txt'}")
        print(f"   • {self.results_dir / 'temporal_analysis_*.png'}")


def main():
    """
    Función principal de ejecución
    """
    import argparse
    
    parser = argparse.ArgumentParser(
        description='Paso 6: Sistema de Perfiles Microtemporales'
    )
    parser.add_argument(
        '--skip-training',
        action='store_true',
        help='Saltar entrenamiento y cargar modelos existentes'
    )
    parser.add_argument(
        '--no-reports',
        action='store_true',
        help='No generar reportes detallados'
    )
    parser.add_argument(
        '--cv-folds',
        type=int,
        default=5,
        help='Número de folds para validación cruzada (default: 5)'
    )
    parser.add_argument(
        '--base-dir',
        type=str,
        default='../EEG_ADHD_v5',
        help='Directorio base del proyecto'
    )
    
    args = parser.parse_args()
    
    # Crear pipeline
    pipeline = Step6IntegratedPipeline(base_dir=args.base_dir)
    
    # Ejecutar pipeline completo
    results = pipeline.run_full_pipeline(
        skip_training=args.skip_training,
        generate_reports=not args.no_reports,
        n_cv_folds=args.cv_folds
    )
    
    if results:
        print("\nEJECUCIÓN COMPLETADA CON ÉXITO")
        return 0
    else:
        print("\nEJECUCIÓN FALLIDA")
        return 1


if __name__ == "__main__":
    sys.exit(main())
